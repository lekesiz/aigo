package dev.aigo.intellij.highlighting;

import com.intellij.lexer.Lexer;
import com.intellij.openapi.editor.DefaultLanguageHighlighterColors;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.fileTypes.SyntaxHighlighterBase;
import com.intellij.psi.tree.IElementType;
import dev.aigo.intellij.lexer.AIGoLexer;
import dev.aigo.intellij.lexer.AIGoTokenTypes;
import org.jetbrains.annotations.NotNull;

import static com.intellij.openapi.editor.colors.TextAttributesKey.createTextAttributesKey;

/**
 * Syntax highlighter for AIGo language
 */
public class AIGoSyntaxHighlighter extends SyntaxHighlighterBase {
    
    public static final TextAttributesKey KEYWORD =
        createTextAttributesKey("AIGO_KEYWORD", DefaultLanguageHighlighterColors.KEYWORD);
    
    public static final TextAttributesKey STRING =
        createTextAttributesKey("AIGO_STRING", DefaultLanguageHighlighterColors.STRING);
    
    public static final TextAttributesKey NUMBER =
        createTextAttributesKey("AIGO_NUMBER", DefaultLanguageHighlighterColors.NUMBER);
    
    public static final TextAttributesKey COMMENT =
        createTextAttributesKey("AIGO_COMMENT", DefaultLanguageHighlighterColors.LINE_COMMENT);
    
    public static final TextAttributesKey OPERATOR =
        createTextAttributesKey("AIGO_OPERATOR", DefaultLanguageHighlighterColors.OPERATION_SIGN);
    
    public static final TextAttributesKey IDENTIFIER =
        createTextAttributesKey("AIGO_IDENTIFIER", DefaultLanguageHighlighterColors.IDENTIFIER);
    
    public static final TextAttributesKey FUNCTION_NAME =
        createTextAttributesKey("AIGO_FUNCTION_NAME", DefaultLanguageHighlighterColors.FUNCTION_DECLARATION);
    
    public static final TextAttributesKey TYPE_NAME =
        createTextAttributesKey("AIGO_TYPE_NAME", DefaultLanguageHighlighterColors.CLASS_NAME);
    
    public static final TextAttributesKey BRACES =
        createTextAttributesKey("AIGO_BRACES", DefaultLanguageHighlighterColors.BRACES);
    
    public static final TextAttributesKey PARENTHESES =
        createTextAttributesKey("AIGO_PARENTHESES", DefaultLanguageHighlighterColors.PARENTHESES);
    
    public static final TextAttributesKey BRACKETS =
        createTextAttributesKey("AIGO_BRACKETS", DefaultLanguageHighlighterColors.BRACKETS);
    
    private static final TextAttributesKey[] KEYWORD_KEYS = new TextAttributesKey[]{KEYWORD};
    private static final TextAttributesKey[] STRING_KEYS = new TextAttributesKey[]{STRING};
    private static final TextAttributesKey[] NUMBER_KEYS = new TextAttributesKey[]{NUMBER};
    private static final TextAttributesKey[] COMMENT_KEYS = new TextAttributesKey[]{COMMENT};
    private static final TextAttributesKey[] OPERATOR_KEYS = new TextAttributesKey[]{OPERATOR};
    private static final TextAttributesKey[] IDENTIFIER_KEYS = new TextAttributesKey[]{IDENTIFIER};
    private static final TextAttributesKey[] FUNCTION_NAME_KEYS = new TextAttributesKey[]{FUNCTION_NAME};
    private static final TextAttributesKey[] TYPE_NAME_KEYS = new TextAttributesKey[]{TYPE_NAME};
    private static final TextAttributesKey[] BRACES_KEYS = new TextAttributesKey[]{BRACES};
    private static final TextAttributesKey[] PARENTHESES_KEYS = new TextAttributesKey[]{PARENTHESES};
    private static final TextAttributesKey[] BRACKETS_KEYS = new TextAttributesKey[]{BRACKETS};
    private static final TextAttributesKey[] EMPTY_KEYS = new TextAttributesKey[0];
    
    @NotNull
    @Override
    public Lexer getHighlightingLexer() {
        return new AIGoLexer();
    }
    
    @NotNull
    @Override
    public TextAttributesKey[] getTokenHighlights(IElementType tokenType) {
        if (tokenType.equals(AIGoTokenTypes.KEYWORD)) {
            return KEYWORD_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.STRING_LITERAL)) {
            return STRING_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.NUMBER_LITERAL)) {
            return NUMBER_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.LINE_COMMENT) || 
                   tokenType.equals(AIGoTokenTypes.BLOCK_COMMENT)) {
            return COMMENT_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.OPERATOR)) {
            return OPERATOR_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.IDENTIFIER)) {
            return IDENTIFIER_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.FUNCTION_NAME)) {
            return FUNCTION_NAME_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.TYPE_NAME)) {
            return TYPE_NAME_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.LBRACE) || 
                   tokenType.equals(AIGoTokenTypes.RBRACE)) {
            return BRACES_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.LPAREN) || 
                   tokenType.equals(AIGoTokenTypes.RPAREN)) {
            return PARENTHESES_KEYS;
        } else if (tokenType.equals(AIGoTokenTypes.LBRACKET) || 
                   tokenType.equals(AIGoTokenTypes.RBRACKET)) {
            return BRACKETS_KEYS;
        }
        return EMPTY_KEYS;
    }
}

