import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card.jsx'
import { Button } from './ui/button.jsx'
import { Badge } from './ui/badge.jsx'
import { Input } from './ui/input.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.jsx'
import { 
  Package, 
  Download, 
  Star, 
  Search, 
  Filter, 
  ArrowUpDown,
  ExternalLink,
  Github,
  Eye,
  Heart,
  Clock,
  Users,
  TrendingUp,
  CheckCircle,
  AlertCircle
} from 'lucide-react'

const PackageManager = ({ searchQuery }) => {
  const [packages, setPackages] = useState([])
  const [loading, setLoading] = useState(true)
  const [sortBy, setSortBy] = useState('downloads')
  const [category, setCategory] = useState('')

  // Mock package data
  const mockPackages = [
    {
      id: 1,
      name: "aigo-http",
      version: "1.2.3",
      description: "HTTP client library for AIGo with async support and comprehensive error handling",
      author: "aigo-team",
      author_email: "team@aigo-lang.org",
      homepage: "https://aigo-lang.org/packages/http",
      repository: "https://github.com/aigo-lang/http",
      license: "MIT",
      keywords: ["http", "client", "async", "web"],
      downloads: 15420,
      stars: 234,
      created_at: "2024-01-15T10:30:00Z",
      updated_at: "2024-12-01T14:20:00Z",
      is_verified: true,
      is_deprecated: false
    },
    {
      id: 2,
      name: "aigo-json",
      version: "2.1.0",
      description: "Fast JSON parser and serializer for AIGo with streaming support",
      author: "json-dev",
      author_email: "dev@jsonlib.com",
      homepage: "https://jsonlib.com",
      repository: "https://github.com/json-dev/aigo-json",
      license: "Apache-2.0",
      keywords: ["json", "parser", "serializer", "streaming"],
      downloads: 28901,
      stars: 456,
      created_at: "2024-02-20T09:15:00Z",
      updated_at: "2024-11-28T16:45:00Z",
      is_verified: true,
      is_deprecated: false
    },
    {
      id: 3,
      name: "aigo-crypto",
      version: "1.0.5",
      description: "Cryptographic functions and utilities for secure AIGo applications",
      author: "crypto-team",
      author_email: "security@cryptolib.org",
      homepage: "https://cryptolib.org",
      repository: "https://github.com/crypto-team/aigo-crypto",
      license: "BSD-3-Clause",
      keywords: ["crypto", "security", "hash", "encryption"],
      downloads: 9876,
      stars: 189,
      created_at: "2024-03-10T11:00:00Z",
      updated_at: "2024-12-05T10:30:00Z",
      is_verified: true,
      is_deprecated: false
    },
    {
      id: 4,
      name: "aigo-db",
      version: "0.8.2",
      description: "Database abstraction layer with support for multiple backends",
      author: "db-team",
      author_email: "team@aigodblib.com",
      homepage: "https://aigodblib.com",
      repository: "https://github.com/db-team/aigo-db",
      license: "MIT",
      keywords: ["database", "orm", "sql", "nosql"],
      downloads: 7234,
      stars: 123,
      created_at: "2024-04-05T13:20:00Z",
      updated_at: "2024-11-30T12:15:00Z",
      is_verified: false,
      is_deprecated: false
    },
    {
      id: 5,
      name: "aigo-test",
      version: "1.5.1",
      description: "Testing framework for AIGo with assertion library and mocking support",
      author: "test-dev",
      author_email: "dev@aigotesting.org",
      homepage: "https://aigotesting.org",
      repository: "https://github.com/test-dev/aigo-test",
      license: "MIT",
      keywords: ["testing", "framework", "assertions", "mocking"],
      downloads: 12567,
      stars: 298,
      created_at: "2024-01-30T08:45:00Z",
      updated_at: "2024-12-03T09:30:00Z",
      is_verified: true,
      is_deprecated: false
    }
  ]

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      let filteredPackages = mockPackages

      // Apply search filter
      if (searchQuery) {
        filteredPackages = filteredPackages.filter(pkg =>
          pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          pkg.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          pkg.keywords.some(keyword => keyword.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      }

      // Apply category filter
      if (category) {
        filteredPackages = filteredPackages.filter(pkg =>
          pkg.keywords.includes(category)
        )
      }

      // Apply sorting
      filteredPackages.sort((a, b) => {
        switch (sortBy) {
          case 'downloads':
            return b.downloads - a.downloads
          case 'stars':
            return b.stars - a.stars
          case 'name':
            return a.name.localeCompare(b.name)
          case 'updated':
            return new Date(b.updated_at) - new Date(a.updated_at)
          default:
            return 0
        }
      })

      setPackages(filteredPackages)
      setLoading(false)
    }, 500)
  }, [searchQuery, sortBy, category])

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const copyInstallCommand = (packageName) => {
    navigator.clipboard.writeText(`aigo install ${packageName}`)
  }

  return (
    <div className="space-y-8">
      <Routes>
        <Route path="/" element={
          <div className="space-y-8">
            {/* Header */}
            <div className="space-y-4">
              <h1 className="text-4xl font-bold">Package Manager</h1>
              <p className="text-xl text-muted-foreground">
                Discover and install AIGo packages to accelerate your development
              </p>
            </div>

            {/* Filters and Sorting */}
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4" />
                  <select 
                    value={category} 
                    onChange={(e) => setCategory(e.target.value)}
                    className="border rounded-md px-3 py-2 text-sm"
                  >
                    <option value="">All Categories</option>
                    <option value="http">HTTP</option>
                    <option value="json">JSON</option>
                    <option value="crypto">Crypto</option>
                    <option value="database">Database</option>
                    <option value="testing">Testing</option>
                  </select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Sort className="h-4 w-4" />
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="border rounded-md px-3 py-2 text-sm"
                  >
                    <option value="downloads">Most Downloaded</option>
                    <option value="stars">Most Starred</option>
                    <option value="name">Name (A-Z)</option>
                    <option value="updated">Recently Updated</option>
                  </select>
                </div>
              </div>

              <div className="text-sm text-muted-foreground">
                {packages.length} packages found
              </div>
            </div>

            {/* Package List */}
            <div className="space-y-6">
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-4 text-muted-foreground">Loading packages...</p>
                </div>
              ) : packages.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No packages found</h3>
                  <p className="text-muted-foreground">Try adjusting your search or filters</p>
                </div>
              ) : (
                packages.map((pkg) => (
                  <Card key={pkg.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 space-y-4">
                          {/* Package Header */}
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="text-xl font-semibold">{pkg.name}</h3>
                                <Badge variant="secondary">v{pkg.version}</Badge>
                                {pkg.is_verified && (
                                  <Badge variant="default" className="bg-green-100 text-green-800">
                                    Verified
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                by <span className="font-medium">{pkg.author}</span>
                              </p>
                              <p className="text-muted-foreground">{pkg.description}</p>
                            </div>
                          </div>

                          {/* Keywords */}
                          <div className="flex flex-wrap gap-2">
                            {pkg.keywords.map((keyword, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                <Tag className="h-3 w-3 mr-1" />
                                {keyword}
                              </Badge>
                            ))}
                          </div>

                          {/* Stats and Actions */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                              <div className="flex items-center space-x-1">
                                <Download className="h-4 w-4" />
                                <span>{pkg.downloads.toLocaleString()}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Star className="h-4 w-4" />
                                <span>{pkg.stars}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-4 w-4" />
                                <span>Updated {formatDate(pkg.updated_at)}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <span className="text-xs bg-gray-100 px-2 py-1 rounded">{pkg.license}</span>
                              </div>
                            </div>

                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyInstallCommand(pkg.name)}
                                className="flex items-center space-x-2"
                              >
                                <Copy className="h-4 w-4" />
                                <span>Install</span>
                              </Button>
                              
                              {pkg.repository && (
                                <Button variant="outline" size="sm" asChild>
                                  <a href={pkg.repository} target="_blank" rel="noopener noreferrer">
                                    <Github className="h-4 w-4" />
                                  </a>
                                </Button>
                              )}
                              
                              {pkg.homepage && (
                                <Button variant="outline" size="sm" asChild>
                                  <a href={pkg.homepage} target="_blank" rel="noopener noreferrer">
                                    <Globe className="h-4 w-4" />
                                  </a>
                                </Button>
                              )}
                              
                              <Button size="sm">
                                View Details
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Load More */}
            {packages.length > 0 && (
              <div className="text-center">
                <Button variant="outline" size="lg">
                  Load More Packages
                </Button>
              </div>
            )}
          </div>
        } />
        
        <Route path="/popular" element={
          <div className="text-center py-16">
            <h1 className="text-4xl font-bold mb-4">Popular Packages</h1>
            <p className="text-xl text-muted-foreground">Most downloaded AIGo packages</p>
          </div>
        } />
        
        <Route path="/trending" element={
          <div className="text-center py-16">
            <h1 className="text-4xl font-bold mb-4">Trending Packages</h1>
            <p className="text-xl text-muted-foreground">Packages gaining popularity</p>
          </div>
        } />
      </Routes>
    </div>
  )
}

export default PackageManager

