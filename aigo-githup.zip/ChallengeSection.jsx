import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Trophy, 
  Play, 
  CheckCircle, 
  Clock, 
  Star,
  Target,
  Zap,
  Code,
  Award,
  TrendingUp
} from 'lucide-react'

const ChallengeSection = ({ userProgress }) => {
  const [selectedChallenge, setSelectedChallenge] = useState(null)
  const [userSolution, setUserSolution] = useState('')

  const challenges = [
    {
      id: 1,
      title: "FizzBuzz Classic",
      description: "Print numbers 1-100, but replace multiples of 3 with 'Fizz', multiples of 5 with 'Buzz', and multiples of both with 'FizzBuzz'",
      difficulty: "Easy",
      points: 100,
      completed: true,
      category: "Logic",
      timeLimit: "15 min",
      testCases: [
        { input: "15", expected: "1 2 Fizz 4 Buzz Fizz 7 8 Fizz Buzz 11 Fizz 13 14 FizzBuzz" }
      ],
      starterCode: `func fizzBuzz(n) {
    // Your code here
    for (i = 1; i <= n; i++) {
        // Implement FizzBuzz logic
    }
}

fizzBuzz(15);`,
      solution: `func fizzBuzz(n) {
    for (i = 1; i <= n; i++) {
        if (i % 15 == 0) {
            println("FizzBuzz");
        } else if (i % 3 == 0) {
            println("Fizz");
        } else if (i % 5 == 0) {
            println("Buzz");
        } else {
            println(i);
        }
    }
}

fizzBuzz(15);`
    },
    {
      id: 2,
      title: "Palindrome Checker",
      description: "Write a function that checks if a given string is a palindrome (reads the same forwards and backwards)",
      difficulty: "Easy",
      points: 150,
      completed: true,
      category: "Strings",
      timeLimit: "20 min",
      testCases: [
        { input: "racecar", expected: "true" },
        { input: "hello", expected: "false" }
      ],
      starterCode: `func isPalindrome(str) {
    // Your code here
    return false;
}

// Test cases
println(isPalindrome("racecar")); // Should print true
println(isPalindrome("hello"));   // Should print false`,
      solution: `func isPalindrome(str) {
    let len = length(str);
    for (i = 0; i < len / 2; i++) {
        if (str[i] != str[len - 1 - i]) {
            return false;
        }
    }
    return true;
}

println(isPalindrome("racecar"));
println(isPalindrome("hello"));`
    },
    {
      id: 3,
      title: "Binary Search",
      description: "Implement binary search algorithm to find an element in a sorted array",
      difficulty: "Medium",
      points: 250,
      completed: false,
      category: "Algorithms",
      timeLimit: "30 min",
      testCases: [
        { input: "[1,2,3,4,5,6,7,8,9], 5", expected: "4" },
        { input: "[1,3,5,7,9], 4", expected: "-1" }
      ],
      starterCode: `func binarySearch(arr, target) {
    // Your code here
    // Return the index of target, or -1 if not found
    return -1;
}

let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
println(binarySearch(numbers, 5)); // Should print 4
println(binarySearch(numbers, 10)); // Should print -1`,
      solution: `func binarySearch(arr, target) {
    let left = 0;
    let right = length(arr) - 1;
    
    while (left <= right) {
        let mid = (left + right) / 2;
        
        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    
    return -1;
}

let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
println(binarySearch(numbers, 5));
println(binarySearch(numbers, 10));`
    },
    {
      id: 4,
      title: "Merge Sort",
      description: "Implement the merge sort algorithm to sort an array of integers",
      difficulty: "Medium",
      points: 300,
      completed: false,
      category: "Algorithms",
      timeLimit: "45 min",
      testCases: [
        { input: "[64, 34, 25, 12, 22, 11, 90]", expected: "[11, 12, 22, 25, 34, 64, 90]" }
      ],
      starterCode: `func mergeSort(arr) {
    // Your code here
    return arr;
}

func merge(left, right) {
    // Helper function to merge two sorted arrays
    return [];
}

let numbers = [64, 34, 25, 12, 22, 11, 90];
let sorted = mergeSort(numbers);
println(sorted);`,
      solution: `func mergeSort(arr) {
    if (length(arr) <= 1) {
        return arr;
    }
    
    let mid = length(arr) / 2;
    let left = slice(arr, 0, mid);
    let right = slice(arr, mid, length(arr));
    
    return merge(mergeSort(left), mergeSort(right));
}

func merge(left, right) {
    let result = [];
    let i = 0, j = 0;
    
    while (i < length(left) && j < length(right)) {
        if (left[i] <= right[j]) {
            push(result, left[i]);
            i++;
        } else {
            push(result, right[j]);
            j++;
        }
    }
    
    while (i < length(left)) {
        push(result, left[i]);
        i++;
    }
    
    while (j < length(right)) {
        push(result, right[j]);
        j++;
    }
    
    return result;
}

let numbers = [64, 34, 25, 12, 22, 11, 90];
let sorted = mergeSort(numbers);
println(sorted);`
    },
    {
      id: 5,
      title: "Graph Traversal",
      description: "Implement depth-first search (DFS) to traverse a graph represented as an adjacency list",
      difficulty: "Hard",
      points: 400,
      completed: false,
      category: "Data Structures",
      timeLimit: "60 min",
      testCases: [
        { input: "graph = {A: [B, C], B: [D], C: [E], D: [], E: []}, start = A", expected: "A B D C E" }
      ],
      starterCode: `func dfs(graph, start, visited) {
    // Your code here
    // Implement depth-first search
}

// Example graph: A -> B, C; B -> D; C -> E
let graph = {
    "A": ["B", "C"],
    "B": ["D"],
    "C": ["E"],
    "D": [],
    "E": []
};

let visited = {};
dfs(graph, "A", visited);`,
      solution: `func dfs(graph, start, visited) {
    if (visited[start]) {
        return;
    }
    
    visited[start] = true;
    println(start);
    
    let neighbors = graph[start];
    for (i = 0; i < length(neighbors); i++) {
        dfs(graph, neighbors[i], visited);
    }
}

let graph = {
    "A": ["B", "C"],
    "B": ["D"],
    "C": ["E"],
    "D": [],
    "E": []
};

let visited = {};
dfs(graph, "A", visited);`
    }
  ]

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800'
      case 'Medium': return 'bg-yellow-100 text-yellow-800'
      case 'Hard': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'Logic': return <Target className="h-4 w-4" />
      case 'Strings': return <Code className="h-4 w-4" />
      case 'Algorithms': return <Zap className="h-4 w-4" />
      case 'Data Structures': return <TrendingUp className="h-4 w-4" />
      default: return <Code className="h-4 w-4" />
    }
  }

  const runChallenge = () => {
    // Simulate running the challenge
    console.log('Running challenge solution...')
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold">Coding Challenges</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Test your AIGo skills with programming challenges ranging from beginner to advanced levels.
        </p>
      </div>

      {/* Challenge Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span>Challenge Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{userProgress.completedChallenges}</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{userProgress.totalChallenges - userProgress.completedChallenges}</div>
              <div className="text-sm text-muted-foreground">Remaining</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{userProgress.totalPoints}</div>
              <div className="text-sm text-muted-foreground">Total Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{userProgress.currentStreak}</div>
              <div className="text-sm text-muted-foreground">Day Streak</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Challenge List and Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Challenge List */}
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Available Challenges</h3>
          {challenges.map((challenge) => (
            <Card 
              key={challenge.id} 
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedChallenge?.id === challenge.id ? 'ring-2 ring-blue-500' : ''
              }`}
              onClick={() => {
                setSelectedChallenge(challenge)
                setUserSolution(challenge.starterCode)
              }}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <CardTitle className="text-lg flex items-center space-x-2">
                      {challenge.completed ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <Trophy className="h-5 w-5 text-blue-600" />
                      )}
                      <span>{challenge.title}</span>
                    </CardTitle>
                    <CardDescription className="text-sm">
                      {challenge.description}
                    </CardDescription>
                  </div>
                  <div className="text-right space-y-1">
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm font-semibold">{challenge.points}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className={getDifficultyColor(challenge.difficulty)}>
                    {challenge.difficulty}
                  </Badge>
                  <Badge variant="outline" className="flex items-center space-x-1">
                    {getCategoryIcon(challenge.category)}
                    <span>{challenge.category}</span>
                  </Badge>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{challenge.timeLimit}</span>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>

        {/* Challenge Editor */}
        <div className="space-y-4">
          {selectedChallenge ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Code className="h-5 w-5" />
                    <span>{selectedChallenge.title}</span>
                  </CardTitle>
                  <CardDescription>
                    {selectedChallenge.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Test Cases:</h4>
                      <div className="space-y-2">
                        {selectedChallenge.testCases.map((testCase, index) => (
                          <div key={index} className="bg-gray-50 p-3 rounded-lg text-sm">
                            <div><strong>Input:</strong> {testCase.input}</div>
                            <div><strong>Expected:</strong> {testCase.expected}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Your Solution</CardTitle>
                  <CardDescription>
                    Write your code below and test it against the challenge requirements
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm">
                      <pre>{userSolution}</pre>
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={runChallenge} className="flex items-center space-x-2">
                        <Play className="h-4 w-4" />
                        <span>Run Tests</span>
                      </Button>
                      <Button variant="outline">
                        Submit Solution
                      </Button>
                      <Button variant="ghost">
                        Show Hint
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {selectedChallenge.completed && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-green-600">
                      <Award className="h-5 w-5" />
                      <span>Challenge Completed!</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span>Points Earned:</span>
                        <Badge className="bg-green-100 text-green-800">+{selectedChallenge.points}</Badge>
                      </div>
                      <Button variant="outline" size="sm">
                        View Solution
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Select a Challenge</h3>
                <p className="text-muted-foreground">
                  Choose a challenge from the list to start coding and earn points.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

export default ChallengeSection

