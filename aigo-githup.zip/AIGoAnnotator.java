package dev.aigo.intellij.annotator;

import com.intellij.lang.annotation.AnnotationHolder;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.annotation.HighlightSeverity;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import dev.aigo.intellij.psi.AIGoFile;
import dev.aigo.intellij.psi.AIGoFunction;
import dev.aigo.intellij.psi.AIGoVariable;
import dev.aigo.intellij.psi.AIGoType;
import org.jetbrains.annotations.NotNull;

import java.util.regex.Pattern;

/**
 * Real-time error detection and semantic highlighting for AIGo
 */
public class AIGoAnnotator implements Annotator {
    
    private static final Pattern FUNCTION_NAME_PATTERN = Pattern.compile("^[a-z][a-zA-Z0-9_]*$");
    private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("^[A-Z][a-zA-Z0-9_]*$");
    private static final Pattern VARIABLE_NAME_PATTERN = Pattern.compile("^[a-z_][a-zA-Z0-9_]*$");
    
    @Override
    public void annotate(@NotNull PsiElement element, @NotNull AnnotationHolder holder) {
        if (element instanceof AIGoFunction) {
            annotateFunction((AIGoFunction) element, holder);
        } else if (element instanceof AIGoVariable) {
            annotateVariable((AIGoVariable) element, holder);
        } else if (element instanceof AIGoType) {
            annotateType((AIGoType) element, holder);
        }
        
        // Check for common errors
        checkSyntaxErrors(element, holder);
        checkSemanticErrors(element, holder);
        checkStyleViolations(element, holder);
    }
    
    private void annotateFunction(@NotNull AIGoFunction function, @NotNull AnnotationHolder holder) {
        String functionName = function.getName();
        if (functionName != null) {
            TextRange range = function.getNameIdentifier().getTextRange();
            
            // Highlight function name
            holder.newSilentAnnotation(HighlightSeverity.INFORMATION)
                .range(range)
                .textAttributes(AIGoSyntaxHighlighter.FUNCTION_NAME)
                .create();
            
            // Check naming convention
            if (!FUNCTION_NAME_PATTERN.matcher(functionName).matches()) {
                holder.newAnnotation(HighlightSeverity.WARNING, 
                    "Function names should start with lowercase letter and use camelCase")
                    .range(range)
                    .withFix(new AIGoRenameFunctionQuickFix(functionName))
                    .create();
            }
            
            // Check for unused functions
            if (!isUsed(function)) {
                holder.newAnnotation(HighlightSeverity.WEAK_WARNING, 
                    "Function '" + functionName + "' is never used")
                    .range(range)
                    .withFix(new AIGoRemoveUnusedFunctionQuickFix())
                    .create();
            }
        }
    }
    
    private void annotateVariable(@NotNull AIGoVariable variable, @NotNull AnnotationHolder holder) {
        String variableName = variable.getName();
        if (variableName != null) {
            TextRange range = variable.getNameIdentifier().getTextRange();
            
            // Check naming convention
            if (!VARIABLE_NAME_PATTERN.matcher(variableName).matches()) {
                holder.newAnnotation(HighlightSeverity.WARNING, 
                    "Variable names should start with lowercase letter or underscore")
                    .range(range)
                    .withFix(new AIGoRenameVariableQuickFix(variableName))
                    .create();
            }
            
            // Check for unused variables
            if (!isUsed(variable)) {
                holder.newAnnotation(HighlightSeverity.WEAK_WARNING, 
                    "Variable '" + variableName + "' is never used")
                    .range(range)
                    .withFix(new AIGoRemoveUnusedVariableQuickFix())
                    .create();
            }
            
            // Check for uninitialized variables
            if (!isInitialized(variable)) {
                holder.newAnnotation(HighlightSeverity.ERROR, 
                    "Variable '" + variableName + "' may not be initialized")
                    .range(range)
                    .withFix(new AIGoInitializeVariableQuickFix())
                    .create();
            }
        }
    }
    
    private void annotateType(@NotNull AIGoType type, @NotNull AnnotationHolder holder) {
        String typeName = type.getName();
        if (typeName != null) {
            TextRange range = type.getTextRange();
            
            // Highlight type name
            holder.newSilentAnnotation(HighlightSeverity.INFORMATION)
                .range(range)
                .textAttributes(AIGoSyntaxHighlighter.TYPE_NAME)
                .create();
            
            // Check naming convention
            if (!TYPE_NAME_PATTERN.matcher(typeName).matches()) {
                holder.newAnnotation(HighlightSeverity.WARNING, 
                    "Type names should start with uppercase letter and use PascalCase")
                    .range(range)
                    .withFix(new AIGoRenameTypeQuickFix(typeName))
                    .create();
            }
        }
    }
    
    private void checkSyntaxErrors(@NotNull PsiElement element, @NotNull AnnotationHolder holder) {
        // Check for missing semicolons
        if (needsSemicolon(element) && !hasSemicolon(element)) {
            TextRange range = element.getTextRange();
            holder.newAnnotation(HighlightSeverity.ERROR, "Missing semicolon")
                .range(range.getEndOffset(), range.getEndOffset())
                .withFix(new AIGoAddSemicolonQuickFix())
                .create();
        }
        
        // Check for unmatched braces
        if (hasUnmatchedBraces(element)) {
            holder.newAnnotation(HighlightSeverity.ERROR, "Unmatched braces")
                .range(element.getTextRange())
                .withFix(new AIGoFixBracesQuickFix())
                .create();
        }
    }
    
    private void checkSemanticErrors(@NotNull PsiElement element, @NotNull AnnotationHolder holder) {
        // Type checking
        if (element instanceof AIGoVariable) {
            AIGoVariable variable = (AIGoVariable) element;
            if (hasTypeError(variable)) {
                holder.newAnnotation(HighlightSeverity.ERROR, 
                    "Type mismatch: cannot assign " + getActualType(variable) + 
                    " to " + getExpectedType(variable))
                    .range(variable.getTextRange())
                    .withFix(new AIGoFixTypeQuickFix())
                    .create();
            }
        }
        
        // Check for unreachable code
        if (isUnreachable(element)) {
            holder.newAnnotation(HighlightSeverity.WARNING, "Unreachable code")
                .range(element.getTextRange())
                .withFix(new AIGoRemoveUnreachableCodeQuickFix())
                .create();
        }
    }
    
    private void checkStyleViolations(@NotNull PsiElement element, @NotNull AnnotationHolder holder) {
        // Check line length
        if (isLineTooLong(element)) {
            holder.newAnnotation(HighlightSeverity.WEAK_WARNING, 
                "Line is too long (>100 characters)")
                .range(element.getTextRange())
                .withFix(new AIGoBreakLongLineQuickFix())
                .create();
        }
        
        // Check for missing documentation
        if (needsDocumentation(element) && !hasDocumentation(element)) {
            holder.newAnnotation(HighlightSeverity.WEAK_WARNING, 
                "Public function should have documentation")
                .range(element.getTextRange())
                .withFix(new AIGoAddDocumentationQuickFix())
                .create();
        }
    }
    
    // Helper methods for error detection
    private boolean isUsed(PsiElement element) {
        // Implementation for usage analysis
        return true; // Simplified for demo
    }
    
    private boolean isInitialized(AIGoVariable variable) {
        // Implementation for initialization analysis
        return true; // Simplified for demo
    }
    
    private boolean needsSemicolon(PsiElement element) {
        // Implementation for semicolon checking
        return false; // Simplified for demo
    }
    
    private boolean hasSemicolon(PsiElement element) {
        // Implementation for semicolon detection
        return true; // Simplified for demo
    }
    
    private boolean hasUnmatchedBraces(PsiElement element) {
        // Implementation for brace matching
        return false; // Simplified for demo
    }
    
    private boolean hasTypeError(AIGoVariable variable) {
        // Implementation for type checking
        return false; // Simplified for demo
    }
    
    private String getActualType(AIGoVariable variable) {
        return "int"; // Simplified for demo
    }
    
    private String getExpectedType(AIGoVariable variable) {
        return "string"; // Simplified for demo
    }
    
    private boolean isUnreachable(PsiElement element) {
        // Implementation for reachability analysis
        return false; // Simplified for demo
    }
    
    private boolean isLineTooLong(PsiElement element) {
        // Implementation for line length checking
        return false; // Simplified for demo
    }
    
    private boolean needsDocumentation(PsiElement element) {
        // Implementation for documentation requirement checking
        return false; // Simplified for demo
    }
    
    private boolean hasDocumentation(PsiElement element) {
        // Implementation for documentation detection
        return true; // Simplified for demo
    }
}

