package dev.aigo.intellij.debugger;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.ExecutionResult;
import com.intellij.execution.configurations.RunProfile;
import com.intellij.execution.configurations.RunProfileState;
import com.intellij.execution.executors.DefaultDebugExecutor;
import com.intellij.execution.runners.ExecutionEnvironment;
import com.intellij.execution.runners.GenericProgramRunner;
import com.intellij.execution.ui.RunContentDescriptor;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.xdebugger.XDebugProcess;
import com.intellij.xdebugger.XDebugProcessStarter;
import com.intellij.xdebugger.XDebugSession;
import com.intellij.xdebugger.XDebuggerManager;
import dev.aigo.intellij.run.AIGoRunConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * AIGo debugger runner for IntelliJ IDEA
 */
public class AIGoDebuggerRunner extends GenericProgramRunner {
    
    private static final String RUNNER_ID = "AIGoDebuggerRunner";
    
    @NotNull
    @Override
    public String getRunnerId() {
        return RUNNER_ID;
    }
    
    @Override
    public boolean canRun(@NotNull String executorId, @NotNull RunProfile profile) {
        return DefaultDebugExecutor.EXECUTOR_ID.equals(executorId) && 
               profile instanceof AIGoRunConfiguration;
    }
    
    @Nullable
    @Override
    protected RunContentDescriptor doExecute(@NotNull RunProfileState state, 
                                           @NotNull ExecutionEnvironment env) throws ExecutionException {
        FileDocumentManager.getInstance().saveAllDocuments();
        
        return XDebuggerManager.getInstance(env.getProject())
            .startSession(env, new XDebugProcessStarter() {
                @NotNull
                @Override
                public XDebugProcess start(@NotNull XDebugSession session) throws ExecutionException {
                    return new AIGoDebugProcess(session, state, env);
                }
            }).getRunContentDescriptor();
    }
    
    /**
     * AIGo debug process implementation
     */
    private static class AIGoDebugProcess extends XDebugProcess {
        private final RunProfileState state;
        private final ExecutionEnvironment environment;
        private ExecutionResult executionResult;
        
        public AIGoDebugProcess(@NotNull XDebugSession session, 
                               @NotNull RunProfileState state, 
                               @NotNull ExecutionEnvironment environment) {
            super(session);
            this.state = state;
            this.environment = environment;
        }
        
        @NotNull
        @Override
        public ExecutionResult start() throws ExecutionException {
            executionResult = state.execute(environment.getExecutor(), this);
            return executionResult;
        }
        
        @Override
        public void startStepOver() {
            // Implementation for step over debugging
            sendCommand("step_over");
        }
        
        @Override
        public void startStepInto() {
            // Implementation for step into debugging
            sendCommand("step_into");
        }
        
        @Override
        public void startStepOut() {
            // Implementation for step out debugging
            sendCommand("step_out");
        }
        
        @Override
        public void stop() {
            // Implementation for stopping debugger
            sendCommand("stop");
            if (executionResult != null) {
                executionResult.getProcessHandler().destroyProcess();
            }
        }
        
        @Override
        public void resume() {
            // Implementation for resuming execution
            sendCommand("continue");
        }
        
        @Override
        public void runToPosition(@NotNull XSourcePosition position) {
            // Implementation for run to cursor
            sendCommand("run_to_position", 
                position.getFile().getPath(), 
                String.valueOf(position.getLine()));
        }
        
        private void sendCommand(String command, String... args) {
            // Implementation for sending commands to AIGo debugger
            // This would communicate with the AIGo runtime debugger
            
            StringBuilder commandBuilder = new StringBuilder(command);
            for (String arg : args) {
                commandBuilder.append(" ").append(arg);
            }
            
            // Send command to debugger process
            if (executionResult != null && executionResult.getProcessHandler() != null) {
                try {
                    executionResult.getProcessHandler()
                        .getProcessInput()
                        .write((commandBuilder.toString() + "\n").getBytes());
                    executionResult.getProcessHandler()
                        .getProcessInput()
                        .flush();
                } catch (Exception e) {
                    // Handle communication error
                    getSession().reportError("Failed to send debugger command: " + e.getMessage());
                }
            }
        }
    }
}

