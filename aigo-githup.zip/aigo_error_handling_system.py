#!/usr/bin/env python3
"""
AIGo Error Handling System - Comprehensive Implementation

This module implements a robust error handling system for the AIGo programming language,
providing native error handling mechanisms, exception hierarchy, error propagation,
and debugging support.

Author: Manus AI
Version: 1.0.0
Date: June 4, 2025
"""

import traceback
import sys
import logging
import json
import time
from typing import Dict, List, Any, Optional, Union, Callable
from enum import Enum
from dataclasses import dataclass, field
from abc import ABC, abstractmethod

# Configure logging for error handling system
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('aigo_errors.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger('AIGoErrorSystem')

class ErrorSeverity(Enum):
    """Error severity levels for AIGo error handling system"""
    TRACE = "trace"
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
    FATAL = "fatal"

class ErrorCategory(Enum):
    """Categories of errors in AIGo language"""
    LEXICAL = "lexical"
    SYNTAX = "syntax"
    SEMANTIC = "semantic"
    TYPE = "type"
    RUNTIME = "runtime"
    MEMORY = "memory"
    CONCURRENCY = "concurrency"
    IO = "io"
    NETWORK = "network"
    SYSTEM = "system"

@dataclass
class ErrorLocation:
    """Represents the location of an error in source code"""
    file_path: str
    line: int
    column: int
    length: int = 1
    
    def __str__(self) -> str:
        return f"{self.file_path}:{self.line}:{self.column}"

@dataclass
class ErrorContext:
    """Additional context information for errors"""
    function_name: Optional[str] = None
    module_name: Optional[str] = None
    variable_scope: Dict[str, Any] = field(default_factory=dict)
    call_stack: List[str] = field(default_factory=list)
    source_snippet: Optional[str] = None

class AIGoError(Exception):
    """Base class for all AIGo language errors"""
    
    def __init__(
        self,
        message: str,
        error_code: str,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        category: ErrorCategory = ErrorCategory.RUNTIME,
        location: Optional[ErrorLocation] = None,
        context: Optional[ErrorContext] = None,
        cause: Optional[Exception] = None,
        suggestions: Optional[List[str]] = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.severity = severity
        self.category = category
        self.location = location
        self.context = context or ErrorContext()
        self.cause = cause
        self.suggestions = suggestions or []
        self.timestamp = time.time()
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary for serialization"""
        return {
            "message": self.message,
            "error_code": self.error_code,
            "severity": self.severity.value,
            "category": self.category.value,
            "location": {
                "file": self.location.file_path if self.location else None,
                "line": self.location.line if self.location else None,
                "column": self.location.column if self.location else None
            },
            "context": {
                "function": self.context.function_name,
                "module": self.context.module_name,
                "call_stack": self.context.call_stack
            },
            "suggestions": self.suggestions,
            "timestamp": self.timestamp,
            "cause": str(self.cause) if self.cause else None
        }
    
    def format_error(self) -> str:
        """Format error for display"""
        lines = []
        lines.append(f"AIGo {self.category.value.title()} Error [{self.error_code}]: {self.message}")
        
        if self.location:
            lines.append(f"  at {self.location}")
            if self.context.source_snippet:
                lines.append(f"  Source: {self.context.source_snippet}")
        
        if self.context.function_name:
            lines.append(f"  in function '{self.context.function_name}'")
        
        if self.context.call_stack:
            lines.append("  Call stack:")
            for frame in self.context.call_stack[-3:]:  # Show last 3 frames
                lines.append(f"    {frame}")
        
        if self.suggestions:
            lines.append("  Suggestions:")
            for suggestion in self.suggestions:
                lines.append(f"    • {suggestion}")
        
        if self.cause:
            lines.append(f"  Caused by: {self.cause}")
        
        return "\n".join(lines)

# Specific error types for different categories

class AIGoLexicalError(AIGoError):
    """Lexical analysis errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="LEX001",
            category=ErrorCategory.LEXICAL,
            **kwargs
        )

class AIGoSyntaxError(AIGoError):
    """Syntax parsing errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="SYN001",
            category=ErrorCategory.SYNTAX,
            **kwargs
        )

class AIGoSemanticError(AIGoError):
    """Semantic analysis errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="SEM001",
            category=ErrorCategory.SEMANTIC,
            **kwargs
        )

class AIGoTypeError(AIGoError):
    """Type system errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="TYP001",
            category=ErrorCategory.TYPE,
            **kwargs
        )

class AIGoRuntimeError(AIGoError):
    """Runtime execution errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="RUN001",
            category=ErrorCategory.RUNTIME,
            **kwargs
        )

class AIGoMemoryError(AIGoError):
    """Memory management errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="MEM001",
            category=ErrorCategory.MEMORY,
            **kwargs
        )

class AIGoConcurrencyError(AIGoError):
    """Concurrency and threading errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="CON001",
            category=ErrorCategory.CONCURRENCY,
            **kwargs
        )

class AIGoIOError(AIGoError):
    """Input/Output errors"""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            error_code="IO001",
            category=ErrorCategory.IO,
            **kwargs
        )

class ErrorHandler:
    """Central error handling and reporting system"""
    
    def __init__(self):
        self.error_history: List[AIGoError] = []
        self.error_callbacks: Dict[ErrorCategory, List[Callable]] = {}
        self.max_history_size = 1000
        self.recovery_strategies: Dict[str, Callable] = {}
        
    def register_callback(self, category: ErrorCategory, callback: Callable):
        """Register a callback for specific error categories"""
        if category not in self.error_callbacks:
            self.error_callbacks[category] = []
        self.error_callbacks[category].append(callback)
    
    def register_recovery_strategy(self, error_code: str, strategy: Callable):
        """Register a recovery strategy for specific error codes"""
        self.recovery_strategies[error_code] = strategy
    
    def handle_error(self, error: AIGoError) -> bool:
        """Handle an error and attempt recovery"""
        # Log the error
        logger.log(
            getattr(logging, error.severity.value.upper(), logging.ERROR),
            error.format_error()
        )
        
        # Add to history
        self.error_history.append(error)
        if len(self.error_history) > self.max_history_size:
            self.error_history.pop(0)
        
        # Execute callbacks
        if error.category in self.error_callbacks:
            for callback in self.error_callbacks[error.category]:
                try:
                    callback(error)
                except Exception as e:
                    logger.error(f"Error in callback: {e}")
        
        # Attempt recovery
        if error.error_code in self.recovery_strategies:
            try:
                return self.recovery_strategies[error.error_code](error)
            except Exception as e:
                logger.error(f"Recovery strategy failed: {e}")
                return False
        
        # Default behavior based on severity
        if error.severity in [ErrorSeverity.FATAL, ErrorSeverity.CRITICAL]:
            return False  # Cannot recover
        
        return True  # Can continue execution
    
    def get_error_statistics(self) -> Dict[str, Any]:
        """Get statistics about errors"""
        if not self.error_history:
            return {"total_errors": 0}
        
        stats = {
            "total_errors": len(self.error_history),
            "by_category": {},
            "by_severity": {},
            "recent_errors": len([e for e in self.error_history if time.time() - e.timestamp < 3600])
        }
        
        for error in self.error_history:
            # Count by category
            cat = error.category.value
            stats["by_category"][cat] = stats["by_category"].get(cat, 0) + 1
            
            # Count by severity
            sev = error.severity.value
            stats["by_severity"][sev] = stats["by_severity"].get(sev, 0) + 1
        
        return stats
    
    def export_error_report(self, file_path: str):
        """Export error history to JSON file"""
        report = {
            "generated_at": time.time(),
            "statistics": self.get_error_statistics(),
            "errors": [error.to_dict() for error in self.error_history]
        }
        
        with open(file_path, 'w') as f:
            json.dump(report, f, indent=2)

class ResultType:
    """Result type for error handling without exceptions"""
    
    def __init__(self, value: Any = None, error: Optional[AIGoError] = None):
        self.value = value
        self.error = error
        self.is_ok = error is None
    
    @classmethod
    def ok(cls, value: Any) -> 'ResultType':
        """Create a successful result"""
        return cls(value=value)
    
    @classmethod
    def err(cls, error: AIGoError) -> 'ResultType':
        """Create an error result"""
        return cls(error=error)
    
    def unwrap(self) -> Any:
        """Get the value or raise the error"""
        if self.is_ok:
            return self.value
        else:
            raise self.error
    
    def unwrap_or(self, default: Any) -> Any:
        """Get the value or return default"""
        return self.value if self.is_ok else default
    
    def map(self, func: Callable) -> 'ResultType':
        """Apply function to value if ok"""
        if self.is_ok:
            try:
                return ResultType.ok(func(self.value))
            except Exception as e:
                return ResultType.err(AIGoRuntimeError(f"Error in map operation: {e}"))
        else:
            return self
    
    def and_then(self, func: Callable) -> 'ResultType':
        """Chain operations that return Results"""
        if self.is_ok:
            return func(self.value)
        else:
            return self

# Global error handler instance
global_error_handler = ErrorHandler()

def handle_aigo_error(func):
    """Decorator for handling AIGo errors in functions"""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except AIGoError as e:
            if not global_error_handler.handle_error(e):
                raise
            return None
        except Exception as e:
            aigo_error = AIGoRuntimeError(
                f"Unexpected error in {func.__name__}: {str(e)}",
                cause=e
            )
            if not global_error_handler.handle_error(aigo_error):
                raise aigo_error
            return None
    return wrapper

# Error recovery strategies
def default_recovery_strategy(error: AIGoError) -> bool:
    """Default recovery strategy"""
    logger.info(f"Attempting default recovery for {error.error_code}")
    return error.severity not in [ErrorSeverity.FATAL, ErrorSeverity.CRITICAL]

def memory_error_recovery(error: AIGoError) -> bool:
    """Recovery strategy for memory errors"""
    logger.info("Attempting memory cleanup and recovery")
    # Implement garbage collection or memory cleanup
    import gc
    gc.collect()
    return True

def io_error_recovery(error: AIGoError) -> bool:
    """Recovery strategy for I/O errors"""
    logger.info("Attempting I/O error recovery")
    # Implement retry logic or alternative I/O methods
    return True

# Register default recovery strategies
global_error_handler.register_recovery_strategy("MEM001", memory_error_recovery)
global_error_handler.register_recovery_strategy("IO001", io_error_recovery)

# Example usage and testing
if __name__ == "__main__":
    print("AIGo Error Handling System - Testing")
    
    # Test error creation and handling
    location = ErrorLocation("test.aigo", 10, 5)
    context = ErrorContext(
        function_name="test_function",
        module_name="test_module",
        call_stack=["main()", "test_function()"]
    )
    
    # Test different error types
    errors_to_test = [
        AIGoSyntaxError(
            "Unexpected token ';'",
            location=location,
            context=context,
            suggestions=["Check for missing parentheses", "Verify syntax structure"]
        ),
        AIGoTypeError(
            "Cannot assign string to integer variable",
            location=location,
            suggestions=["Use type conversion", "Check variable declaration"]
        ),
        AIGoRuntimeError(
            "Division by zero",
            location=location,
            suggestions=["Add zero check before division"]
        )
    ]
    
    # Test error handling
    for error in errors_to_test:
        print(f"\n{'='*60}")
        print("Testing error:")
        print(error.format_error())
        
        # Handle the error
        can_continue = global_error_handler.handle_error(error)
        print(f"Can continue execution: {can_continue}")
    
    # Test Result type
    print(f"\n{'='*60}")
    print("Testing Result type:")
    
    def divide(a: float, b: float) -> ResultType:
        if b == 0:
            return ResultType.err(AIGoRuntimeError("Division by zero"))
        return ResultType.ok(a / b)
    
    result1 = divide(10, 2)
    result2 = divide(10, 0)
    
    print(f"10 / 2 = {result1.unwrap_or('Error')}")
    print(f"10 / 0 = {result2.unwrap_or('Error')}")
    
    # Test chaining
    result3 = divide(20, 4).map(lambda x: x * 2)
    print(f"(20 / 4) * 2 = {result3.unwrap_or('Error')}")
    
    # Export error report
    global_error_handler.export_error_report("aigo_error_report.json")
    print(f"\nError report exported to aigo_error_report.json")
    
    # Print statistics
    stats = global_error_handler.get_error_statistics()
    print(f"\nError Statistics:")
    print(json.dumps(stats, indent=2))

