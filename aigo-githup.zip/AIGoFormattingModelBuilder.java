package dev.aigo.intellij.formatter;

import com.intellij.formatting.*;
import com.intellij.lang.ASTNode;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import dev.aigo.intellij.AIGoLanguage;
import dev.aigo.intellij.lexer.AIGoTokenTypes;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Code formatting model builder for AIGo language
 */
public class AIGoFormattingModelBuilder implements FormattingModelBuilder {
    
    @NotNull
    @Override
    public FormattingModel createModel(@NotNull FormattingContext formattingContext) {
        PsiElement element = formattingContext.getPsiElement();
        CodeStyleSettings settings = formattingContext.getCodeStyleSettings();
        
        return FormattingModelProvider.createFormattingModelForPsiFile(
            element.getContainingFile(),
            new AIGoBlock(element.getNode(), null, Indent.getNoneIndent(), null, settings),
            settings
        );
    }
    
    @Nullable
    @Override
    public TextRange getRangeAffectingIndent(PsiFile file, int offset, ASTNode elementAtOffset) {
        return null;
    }
    
    /**
     * AIGo formatting block implementation
     */
    private static class AIGoBlock implements Block {
        private final ASTNode node;
        private final Alignment alignment;
        private final Indent indent;
        private final Wrap wrap;
        private final CodeStyleSettings settings;
        
        public AIGoBlock(ASTNode node, Alignment alignment, Indent indent, Wrap wrap, CodeStyleSettings settings) {
            this.node = node;
            this.alignment = alignment;
            this.indent = indent;
            this.wrap = wrap;
            this.settings = settings;
        }
        
        @Override
        public ASTNode getNode() {
            return node;
        }
        
        @NotNull
        @Override
        public TextRange getTextRange() {
            return node.getTextRange();
        }
        
        @NotNull
        @Override
        public List<Block> getSubBlocks() {
            List<Block> blocks = new ArrayList<>();
            ASTNode child = node.getFirstChildNode();
            
            while (child != null) {
                if (child.getElementType() != TokenType.WHITE_SPACE) {
                    Block block = new AIGoBlock(
                        child,
                        null,
                        getChildIndent(child),
                        null,
                        settings
                    );
                    blocks.add(block);
                }
                child = child.getTreeNext();
            }
            
            return blocks;
        }
        
        @Nullable
        @Override
        public Wrap getWrap() {
            return wrap;
        }
        
        @Nullable
        @Override
        public Indent getIndent() {
            return indent;
        }
        
        @Nullable
        @Override
        public Alignment getAlignment() {
            return alignment;
        }
        
        @Nullable
        @Override
        public Spacing getSpacing(@Nullable Block child1, @NotNull Block child2) {
            if (child1 == null) {
                return null;
            }
            
            ASTNode node1 = ((AIGoBlock) child1).getNode();
            ASTNode node2 = ((AIGoBlock) child2).getNode();
            
            return getSpacing(node1, node2);
        }
        
        @NotNull
        @Override
        public ChildAttributes getChildAttributes(int newChildIndex) {
            return new ChildAttributes(getChildIndent(null), null);
        }
        
        @Override
        public boolean isIncomplete() {
            return false;
        }
        
        @Override
        public boolean isLeaf() {
            return node.getFirstChildNode() == null;
        }
        
        private Indent getChildIndent(ASTNode child) {
            IElementType parentType = node.getElementType();
            IElementType childType = child != null ? child.getElementType() : null;
            
            // Indent function bodies
            if (parentType == AIGoTokenTypes.FUNCTION_BODY) {
                return Indent.getNormalIndent();
            }
            
            // Indent block contents
            if (parentType == AIGoTokenTypes.BLOCK) {
                if (childType == AIGoTokenTypes.LBRACE || childType == AIGoTokenTypes.RBRACE) {
                    return Indent.getNoneIndent();
                }
                return Indent.getNormalIndent();
            }
            
            // Indent array/object literals
            if (parentType == AIGoTokenTypes.ARRAY_LITERAL || parentType == AIGoTokenTypes.OBJECT_LITERAL) {
                return Indent.getNormalIndent();
            }
            
            return Indent.getNoneIndent();
        }
        
        private Spacing getSpacing(ASTNode node1, ASTNode node2) {
            IElementType type1 = node1.getElementType();
            IElementType type2 = node2.getElementType();
            
            // No space around dots
            if (type1 == AIGoTokenTypes.DOT || type2 == AIGoTokenTypes.DOT) {
                return Spacing.createSpacing(0, 0, 0, false, 0);
            }
            
            // Space around operators
            if (isOperator(type1) || isOperator(type2)) {
                return Spacing.createSpacing(1, 1, 0, true, 0);
            }
            
            // Space after commas
            if (type1 == AIGoTokenTypes.COMMA) {
                return Spacing.createSpacing(1, 1, 0, true, 0);
            }
            
            // Space after keywords
            if (isKeyword(type1)) {
                return Spacing.createSpacing(1, 1, 0, true, 0);
            }
            
            // New line after opening brace
            if (type1 == AIGoTokenTypes.LBRACE) {
                return Spacing.createSpacing(0, 0, 1, true, 0);
            }
            
            // New line before closing brace
            if (type2 == AIGoTokenTypes.RBRACE) {
                return Spacing.createSpacing(0, 0, 1, true, 0);
            }
            
            // Default spacing
            return Spacing.createSpacing(0, 1, 0, true, 0);
        }
        
        private boolean isOperator(IElementType type) {
            return type == AIGoTokenTypes.PLUS ||
                   type == AIGoTokenTypes.MINUS ||
                   type == AIGoTokenTypes.MULTIPLY ||
                   type == AIGoTokenTypes.DIVIDE ||
                   type == AIGoTokenTypes.ASSIGN ||
                   type == AIGoTokenTypes.EQUALS ||
                   type == AIGoTokenTypes.NOT_EQUALS ||
                   type == AIGoTokenTypes.LESS_THAN ||
                   type == AIGoTokenTypes.GREATER_THAN;
        }
        
        private boolean isKeyword(IElementType type) {
            return type == AIGoTokenTypes.FUNC ||
                   type == AIGoTokenTypes.LET ||
                   type == AIGoTokenTypes.MUT ||
                   type == AIGoTokenTypes.IF ||
                   type == AIGoTokenTypes.ELSE ||
                   type == AIGoTokenTypes.FOR ||
                   type == AIGoTokenTypes.WHILE ||
                   type == AIGoTokenTypes.RETURN;
        }
    }
}

