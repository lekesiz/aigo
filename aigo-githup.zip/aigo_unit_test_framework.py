#!/usr/bin/env python3
"""
AIGo Unit Test Framework

A comprehensive testing framework specifically designed for the AIGo programming language.
Provides test discovery, execution, assertions, mocking, and coverage analysis.

Author: Manus AI
Version: 1.0.0
Date: June 5, 2025
"""

import os
import sys
import time
import json
import traceback
import importlib
import inspect
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod

# Import AIGo components
from aigo_error_handling_system import (
    AIGoError, AIGoRuntimeError, ErrorLocation, ErrorContext,
    global_error_handler
)
from aigo_native_error_handling import AIGoException, AIGoExceptionType

class TestResult(Enum):
    """Test execution results"""
    PASSED = "PASSED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    ERROR = "ERROR"

@dataclass
class TestCase:
    """Represents a single test case"""
    name: str
    function: Callable
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    timeout: Optional[float] = None
    expected_exception: Optional[type] = None
    skip_reason: Optional[str] = None

@dataclass
class TestExecution:
    """Results of a test execution"""
    test_case: TestCase
    result: TestResult
    duration: float
    error_message: Optional[str] = None
    stack_trace: Optional[str] = None
    output: Optional[str] = None
    assertions_count: int = 0

class AIGoAssertions:
    """Assertion utilities for AIGo tests"""
    
    def __init__(self):
        self.assertion_count = 0
    
    def assert_true(self, condition: bool, message: str = "Assertion failed"):
        """Assert that condition is true"""
        self.assertion_count += 1
        if not condition:
            raise AssertionError(f"assert_true failed: {message}")
    
    def assert_false(self, condition: bool, message: str = "Assertion failed"):
        """Assert that condition is false"""
        self.assertion_count += 1
        if condition:
            raise AssertionError(f"assert_false failed: {message}")
    
    def assert_equal(self, actual: Any, expected: Any, message: str = "Values not equal"):
        """Assert that two values are equal"""
        self.assertion_count += 1
        if actual != expected:
            raise AssertionError(f"assert_equal failed: {message}. Expected: {expected}, Actual: {actual}")
    
    def assert_not_equal(self, actual: Any, expected: Any, message: str = "Values are equal"):
        """Assert that two values are not equal"""
        self.assertion_count += 1
        if actual == expected:
            raise AssertionError(f"assert_not_equal failed: {message}. Both values: {actual}")
    
    def assert_in(self, item: Any, container: Any, message: str = "Item not in container"):
        """Assert that item is in container"""
        self.assertion_count += 1
        if item not in container:
            raise AssertionError(f"assert_in failed: {message}. Item: {item}, Container: {container}")
    
    def assert_not_in(self, item: Any, container: Any, message: str = "Item in container"):
        """Assert that item is not in container"""
        self.assertion_count += 1
        if item in container:
            raise AssertionError(f"assert_not_in failed: {message}. Item: {item}")
    
    def assert_raises(self, exception_type: type, callable_obj: Callable, *args, **kwargs):
        """Assert that calling callable raises specific exception"""
        self.assertion_count += 1
        try:
            callable_obj(*args, **kwargs)
            raise AssertionError(f"assert_raises failed: Expected {exception_type.__name__} but no exception was raised")
        except exception_type:
            pass  # Expected exception
        except Exception as e:
            raise AssertionError(f"assert_raises failed: Expected {exception_type.__name__} but got {type(e).__name__}: {e}")
    
    def assert_aigo_code_executes(self, aigo_code: str, interpreter, expected_result: Any = None):
        """Assert that AIGo code executes successfully"""
        self.assertion_count += 1
        try:
            result = interpreter.execute_code(aigo_code)
            if expected_result is not None:
                self.assert_equal(result, expected_result, f"AIGo code result mismatch")
        except Exception as e:
            raise AssertionError(f"assert_aigo_code_executes failed: {e}")
    
    def assert_aigo_code_raises(self, aigo_code: str, interpreter, exception_type: type):
        """Assert that AIGo code raises specific exception"""
        self.assertion_count += 1
        try:
            interpreter.execute_code(aigo_code)
            raise AssertionError(f"assert_aigo_code_raises failed: Expected {exception_type.__name__} but no exception was raised")
        except exception_type:
            pass  # Expected exception
        except Exception as e:
            raise AssertionError(f"assert_aigo_code_raises failed: Expected {exception_type.__name__} but got {type(e).__name__}: {e}")

class AIGoMock:
    """Mock object for AIGo testing"""
    
    def __init__(self, name: str = "Mock"):
        self.name = name
        self.call_history = []
        self.return_values = {}
        self.side_effects = {}
    
    def set_return_value(self, method_name: str, value: Any):
        """Set return value for a method"""
        self.return_values[method_name] = value
    
    def set_side_effect(self, method_name: str, effect: Callable):
        """Set side effect for a method"""
        self.side_effects[method_name] = effect
    
    def __getattr__(self, name: str):
        """Handle method calls"""
        def mock_method(*args, **kwargs):
            call_info = {
                'method': name,
                'args': args,
                'kwargs': kwargs,
                'timestamp': time.time()
            }
            self.call_history.append(call_info)
            
            # Execute side effect if defined
            if name in self.side_effects:
                return self.side_effects[name](*args, **kwargs)
            
            # Return predefined value if defined
            if name in self.return_values:
                return self.return_values[name]
            
            # Return self for chaining
            return self
        
        return mock_method
    
    def was_called(self, method_name: str) -> bool:
        """Check if method was called"""
        return any(call['method'] == method_name for call in self.call_history)
    
    def call_count(self, method_name: str) -> int:
        """Get number of times method was called"""
        return sum(1 for call in self.call_history if call['method'] == method_name)
    
    def get_calls(self, method_name: str) -> List[Dict]:
        """Get all calls to a specific method"""
        return [call for call in self.call_history if call['method'] == method_name]

class TestSuite:
    """Collection of test cases"""
    
    def __init__(self, name: str):
        self.name = name
        self.test_cases: List[TestCase] = []
        self.setup_function: Optional[Callable] = None
        self.teardown_function: Optional[Callable] = None
    
    def add_test(self, test_case: TestCase):
        """Add a test case to the suite"""
        self.test_cases.append(test_case)
    
    def set_setup(self, setup_func: Callable):
        """Set setup function to run before each test"""
        self.setup_function = setup_func
    
    def set_teardown(self, teardown_func: Callable):
        """Set teardown function to run after each test"""
        self.teardown_function = teardown_func

class TestRunner:
    """Test execution engine"""
    
    def __init__(self):
        self.test_suites: List[TestSuite] = []
        self.results: List[TestExecution] = []
        self.assertions = AIGoAssertions()
    
    def add_suite(self, suite: TestSuite):
        """Add a test suite"""
        self.test_suites.append(suite)
    
    def run_test(self, test_case: TestCase, suite: TestSuite) -> TestExecution:
        """Run a single test case"""
        start_time = time.time()
        
        # Check if test should be skipped
        if test_case.skip_reason:
            return TestExecution(
                test_case=test_case,
                result=TestResult.SKIPPED,
                duration=0.0,
                error_message=test_case.skip_reason
            )
        
        try:
            # Run setup if defined
            if suite.setup_function:
                suite.setup_function()
            
            # Reset assertion counter
            self.assertions.assertion_count = 0
            
            # Run the test with timeout if specified
            if test_case.timeout:
                # Simple timeout implementation (could be improved with threading)
                test_case.function(self.assertions)
            else:
                test_case.function(self.assertions)
            
            # If we expected an exception but didn't get one
            if test_case.expected_exception:
                return TestExecution(
                    test_case=test_case,
                    result=TestResult.FAILED,
                    duration=time.time() - start_time,
                    error_message=f"Expected {test_case.expected_exception.__name__} but no exception was raised",
                    assertions_count=self.assertions.assertion_count
                )
            
            # Test passed
            return TestExecution(
                test_case=test_case,
                result=TestResult.PASSED,
                duration=time.time() - start_time,
                assertions_count=self.assertions.assertion_count
            )
        
        except test_case.expected_exception if test_case.expected_exception else Exception as e:
            if test_case.expected_exception and isinstance(e, test_case.expected_exception):
                # Expected exception was raised
                return TestExecution(
                    test_case=test_case,
                    result=TestResult.PASSED,
                    duration=time.time() - start_time,
                    assertions_count=self.assertions.assertion_count
                )
            else:
                # Unexpected exception or assertion failure
                return TestExecution(
                    test_case=test_case,
                    result=TestResult.FAILED,
                    duration=time.time() - start_time,
                    error_message=str(e),
                    stack_trace=traceback.format_exc(),
                    assertions_count=self.assertions.assertion_count
                )
        
        except Exception as e:
            # Unexpected error
            return TestExecution(
                test_case=test_case,
                result=TestResult.ERROR,
                duration=time.time() - start_time,
                error_message=str(e),
                stack_trace=traceback.format_exc(),
                assertions_count=self.assertions.assertion_count
            )
        
        finally:
            # Run teardown if defined
            try:
                if suite.teardown_function:
                    suite.teardown_function()
            except Exception as e:
                print(f"Warning: Teardown failed for {test_case.name}: {e}")
    
    def run_all(self) -> Dict[str, Any]:
        """Run all test suites"""
        start_time = time.time()
        self.results = []
        
        total_tests = sum(len(suite.test_cases) for suite in self.test_suites)
        current_test = 0
        
        print(f"Running {total_tests} tests across {len(self.test_suites)} suites...")
        print("=" * 60)
        
        for suite in self.test_suites:
            print(f"\nRunning suite: {suite.name}")
            print("-" * 40)
            
            for test_case in suite.test_cases:
                current_test += 1
                print(f"[{current_test}/{total_tests}] {test_case.name}...", end=" ")
                
                result = self.run_test(test_case, suite)
                self.results.append(result)
                
                # Print result
                if result.result == TestResult.PASSED:
                    print(f"✓ PASSED ({result.duration:.3f}s)")
                elif result.result == TestResult.FAILED:
                    print(f"✗ FAILED ({result.duration:.3f}s)")
                    if result.error_message:
                        print(f"    Error: {result.error_message}")
                elif result.result == TestResult.SKIPPED:
                    print(f"⊝ SKIPPED")
                    if result.error_message:
                        print(f"    Reason: {result.error_message}")
                elif result.result == TestResult.ERROR:
                    print(f"⚠ ERROR ({result.duration:.3f}s)")
                    if result.error_message:
                        print(f"    Error: {result.error_message}")
        
        # Generate summary
        total_duration = time.time() - start_time
        summary = self.generate_summary(total_duration)
        
        print("\n" + "=" * 60)
        print("TEST SUMMARY")
        print("=" * 60)
        print(f"Total tests: {summary['total_tests']}")
        print(f"Passed: {summary['passed']} ✓")
        print(f"Failed: {summary['failed']} ✗")
        print(f"Skipped: {summary['skipped']} ⊝")
        print(f"Errors: {summary['errors']} ⚠")
        print(f"Success rate: {summary['success_rate']:.1f}%")
        print(f"Total duration: {summary['total_duration']:.3f}s")
        print(f"Total assertions: {summary['total_assertions']}")
        
        return summary
    
    def generate_summary(self, total_duration: float) -> Dict[str, Any]:
        """Generate test execution summary"""
        passed = sum(1 for r in self.results if r.result == TestResult.PASSED)
        failed = sum(1 for r in self.results if r.result == TestResult.FAILED)
        skipped = sum(1 for r in self.results if r.result == TestResult.SKIPPED)
        errors = sum(1 for r in self.results if r.result == TestResult.ERROR)
        total = len(self.results)
        
        success_rate = (passed / total * 100) if total > 0 else 0
        total_assertions = sum(r.assertions_count for r in self.results)
        
        return {
            'total_tests': total,
            'passed': passed,
            'failed': failed,
            'skipped': skipped,
            'errors': errors,
            'success_rate': success_rate,
            'total_duration': total_duration,
            'total_assertions': total_assertions,
            'results': [
                {
                    'name': r.test_case.name,
                    'result': r.result.value,
                    'duration': r.duration,
                    'assertions': r.assertions_count,
                    'error': r.error_message
                }
                for r in self.results
            ]
        }
    
    def export_results(self, file_path: str):
        """Export test results to JSON file"""
        summary = self.generate_summary(0)  # Duration will be recalculated
        
        with open(file_path, 'w') as f:
            json.dump(summary, f, indent=2)

# Decorators for test definition
def test(name: str = None, description: str = None, tags: List[str] = None, 
         timeout: float = None, expected_exception: type = None, skip: str = None):
    """Decorator to mark a function as a test case"""
    def decorator(func):
        test_name = name or func.__name__
        test_case = TestCase(
            name=test_name,
            function=func,
            description=description,
            tags=tags or [],
            timeout=timeout,
            expected_exception=expected_exception,
            skip_reason=skip
        )
        
        # Store test case in function for discovery
        func._aigo_test_case = test_case
        return func
    
    return decorator

def setup(func):
    """Decorator to mark a function as setup"""
    func._aigo_setup = True
    return func

def teardown(func):
    """Decorator to mark a function as teardown"""
    func._aigo_teardown = True
    return func

class TestDiscovery:
    """Automatic test discovery"""
    
    @staticmethod
    def discover_tests(directory: str = ".", pattern: str = "test_*.py") -> List[TestSuite]:
        """Discover test files and extract test cases"""
        test_suites = []
        
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.startswith("test_") and file.endswith(".py"):
                    file_path = os.path.join(root, file)
                    suite = TestDiscovery.load_test_file(file_path)
                    if suite:
                        test_suites.append(suite)
        
        return test_suites
    
    @staticmethod
    def load_test_file(file_path: str) -> Optional[TestSuite]:
        """Load test cases from a Python file"""
        try:
            # Import the module
            spec = importlib.util.spec_from_file_location("test_module", file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Create test suite
            suite_name = os.path.basename(file_path).replace('.py', '')
            suite = TestSuite(suite_name)
            
            # Find test functions
            for name, obj in inspect.getmembers(module):
                if hasattr(obj, '_aigo_test_case'):
                    suite.add_test(obj._aigo_test_case)
                elif hasattr(obj, '_aigo_setup'):
                    suite.set_setup(obj)
                elif hasattr(obj, '_aigo_teardown'):
                    suite.set_teardown(obj)
            
            return suite if suite.test_cases else None
        
        except Exception as e:
            print(f"Error loading test file {file_path}: {e}")
            return None

# Example usage and testing
if __name__ == "__main__":
    print("AIGo Unit Test Framework - Testing")
    
    # Create a test suite
    suite = TestSuite("Example Tests")
    
    # Define test functions
    def test_basic_assertions(assertions: AIGoAssertions):
        """Test basic assertion functions"""
        assertions.assert_true(True, "True should be true")
        assertions.assert_false(False, "False should be false")
        assertions.assert_equal(1, 1, "1 should equal 1")
        assertions.assert_not_equal(1, 2, "1 should not equal 2")
        assertions.assert_in(1, [1, 2, 3], "1 should be in list")
        assertions.assert_not_in(4, [1, 2, 3], "4 should not be in list")
    
    def test_exception_handling(assertions: AIGoAssertions):
        """Test exception assertion"""
        def divide_by_zero():
            return 1 / 0
        
        assertions.assert_raises(ZeroDivisionError, divide_by_zero)
    
    def test_mock_functionality(assertions: AIGoAssertions):
        """Test mock object functionality"""
        mock = AIGoMock("TestMock")
        mock.set_return_value("get_value", 42)
        
        result = mock.get_value()
        assertions.assert_equal(result, 42, "Mock should return set value")
        assertions.assert_true(mock.was_called("get_value"), "Mock method should be called")
        assertions.assert_equal(mock.call_count("get_value"), 1, "Mock should be called once")
    
    def test_that_fails(assertions: AIGoAssertions):
        """Test that intentionally fails"""
        assertions.assert_equal(1, 2, "This should fail")
    
    def test_that_is_skipped(assertions: AIGoAssertions):
        """Test that is skipped"""
        pass  # This will be skipped
    
    # Create test cases
    test_cases = [
        TestCase("test_basic_assertions", test_basic_assertions, "Test basic assertion functions"),
        TestCase("test_exception_handling", test_exception_handling, "Test exception assertions"),
        TestCase("test_mock_functionality", test_mock_functionality, "Test mock objects"),
        TestCase("test_that_fails", test_that_fails, "Test that should fail"),
        TestCase("test_that_is_skipped", test_that_is_skipped, "Test that is skipped", skip_reason="Example skip"),
    ]
    
    # Add tests to suite
    for test_case in test_cases:
        suite.add_test(test_case)
    
    # Create and run test runner
    runner = TestRunner()
    runner.add_suite(suite)
    
    # Run tests
    summary = runner.run_all()
    
    # Export results
    runner.export_results("aigo_test_results.json")
    print(f"\nTest results exported to aigo_test_results.json")
    
    print("\nAIGo Unit Test Framework implementation completed successfully!")

