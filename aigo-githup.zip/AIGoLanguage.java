package dev.aigo.intellij;

import com.intellij.lang.Language;

/**
 * AIGo language definition for IntelliJ IDEA
 */
public class AIGoLanguage extends Language {
    public static final AIGoLanguage INSTANCE = new AIGoLanguage();
    
    private AIGoLanguage() {
        super("AIGo");
    }
    
    @Override
    public String getDisplayName() {
        return "AIGo";
    }
    
    @Override
    public boolean isCaseSensitive() {
        return true;
    }
}

