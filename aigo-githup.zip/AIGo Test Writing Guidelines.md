# AIGo Test Writing Guidelines

## Overview

This guide provides comprehensive guidelines for writing effective tests for AIGo programming language projects. Following these guidelines ensures consistent, maintainable, and reliable test suites.

## Test Organization

### Directory Structure

```
project/
├── src/
│   ├── aigo_interpreter.py
│   ├── aigo_lexer.py
│   └── aigo_parser.py
├── tests/
│   ├── unit/
│   │   ├── test_interpreter.py
│   │   ├── test_lexer.py
│   │   └── test_parser.py
│   ├── integration/
│   │   ├── test_end_to_end.py
│   │   └── test_performance.py
│   ├── fixtures/
│   │   ├── sample_code.aigo
│   │   └── test_data.json
│   └── conftest.py
├── requirements.txt
└── pytest.ini
```

### Test File Naming

- **Unit tests:** `test_<module_name>.py`
- **Integration tests:** `test_<feature_name>_integration.py`
- **Performance tests:** `test_<feature_name>_performance.py`
- **End-to-end tests:** `test_<workflow_name>_e2e.py`

## Test Function Guidelines

### Naming Conventions

Use descriptive names that clearly indicate:
1. What is being tested
2. Under what conditions
3. What the expected outcome is

**Good examples:**
```python
def test_lexer_tokenizes_valid_identifier()
def test_parser_raises_error_on_missing_semicolon()
def test_interpreter_executes_fibonacci_correctly()
def test_error_handler_recovers_from_division_by_zero()
```

**Avoid:**
```python
def test_lexer()  # Too vague
def test_error()  # Not specific
def test_1()      # Meaningless
```

### Test Structure (AAA Pattern)

Every test should follow the Arrange-Act-Assert pattern:

```python
@test(name="test_user_creation_with_valid_data")
def test_user_creation_with_valid_data(assertions: AIGoAssertions):
    # Arrange - Set up test data and conditions
    username = "testuser"
    email = "test@example.com"
    age = 25
    
    # Act - Execute the code under test
    result = create_user(username, email, age)
    
    # Assert - Verify the expected outcomes
    assertions.assert_equal(result.username, username)
    assertions.assert_equal(result.email, email)
    assertions.assert_equal(result.age, age)
    assertions.assert_true(result.is_valid)
```

### Test Data Management

#### 1. Use Fixtures for Reusable Data

```python
@fixture
def valid_user_data():
    return {
        "username": "testuser",
        "email": "test@example.com",
        "age": 25,
        "preferences": {
            "theme": "dark",
            "notifications": True
        }
    }

@fixture
def invalid_user_data():
    return [
        {"username": "", "email": "test@example.com", "age": 25},
        {"username": "test", "email": "invalid-email", "age": 25},
        {"username": "test", "email": "test@example.com", "age": -5}
    ]
```

#### 2. Parameterized Tests

```python
@test(name="test_validation_with_multiple_inputs")
def test_validation_with_multiple_inputs(assertions: AIGoAssertions):
    test_cases = [
        ("valid@email.com", True),
        ("invalid-email", False),
        ("", False),
        ("user@domain.co.uk", True)
    ]
    
    for email, expected_valid in test_cases:
        result = validate_email(email)
        assertions.assert_equal(result.is_valid, expected_valid, 
                               f"Email validation failed for: {email}")
```

#### 3. External Test Data

```python
import json

@fixture
def load_test_scenarios():
    with open("tests/fixtures/validation_scenarios.json") as f:
        return json.load(f)

@test(name="test_validation_scenarios")
def test_validation_scenarios(assertions: AIGoAssertions, load_test_scenarios):
    for scenario in load_test_scenarios:
        input_data = scenario["input"]
        expected_result = scenario["expected"]
        
        result = validate_data(input_data)
        assertions.assert_equal(result, expected_result, 
                               f"Scenario failed: {scenario['description']}")
```

## AIGo-Specific Testing

### Testing AIGo Code Execution

```python
@test(name="test_fibonacci_implementation")
def test_fibonacci_implementation(assertions: AIGoAssertions):
    aigo_code = """
    func fibonacci(n) {
        if (n <= 1) {
            return n;
        }
        return fibonacci(n-1) + fibonacci(n-2);
    }
    
    fibonacci(6);
    """
    
    interpreter = AIGoTestAdapter()
    assertions.assert_aigo_code_executes(aigo_code, interpreter, expected_result=8)
```

### Testing Error Handling

```python
@test(name="test_division_by_zero_handling")
def test_division_by_zero_handling(assertions: AIGoAssertions):
    aigo_code = """
    try {
        let result = 10 / 0;
        println(result);
    } catch (DivisionError e) {
        println("Caught division error: " + e.message);
    }
    """
    
    interpreter = AIGoTestAdapter()
    # Should not raise exception, should handle gracefully
    assertions.assert_aigo_code_executes(aigo_code, interpreter)
```

### Testing Syntax Validation

```python
@test(name="test_invalid_syntax_detection")
def test_invalid_syntax_detection(assertions: AIGoAssertions):
    invalid_code = """
    func incomplete_function( {
        // Missing closing parenthesis and function body
    """
    
    interpreter = AIGoTestAdapter()
    assertions.assert_aigo_code_raises(invalid_code, interpreter, SyntaxError)
```

## Mock and Stub Usage

### When to Use Mocks

1. **External dependencies** (databases, APIs, file systems)
2. **Slow operations** that would make tests run slowly
3. **Non-deterministic behavior** (random numbers, current time)
4. **Error conditions** that are hard to reproduce

### Mock Implementation

```python
@test(name="test_database_integration")
def test_database_integration(assertions: AIGoAssertions):
    # Create mock database
    mock_db = AIGoMock("Database")
    mock_db.set_return_value("connect", True)
    mock_db.set_return_value("execute", {"rows_affected": 1})
    mock_db.set_return_value("close", True)
    
    # Test the service that uses the database
    service = UserService(database=mock_db)
    result = service.create_user("testuser", "test@example.com")
    
    # Verify interactions
    assertions.assert_true(result.success)
    assertions.assert_true(mock_db.was_called("connect"))
    assertions.assert_true(mock_db.was_called("execute"))
    assertions.assert_true(mock_db.was_called("close"))
    assertions.assert_equal(mock_db.call_count("execute"), 1)
```

### Mock Side Effects

```python
@test(name="test_retry_mechanism")
def test_retry_mechanism(assertions: AIGoAssertions):
    mock_api = AIGoMock("APIService")
    
    # First call fails, second succeeds
    call_count = 0
    def api_side_effect(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise ConnectionError("Network timeout")
        return {"status": "success", "data": "test"}
    
    mock_api.set_side_effect("fetch_data", api_side_effect)
    
    # Test retry logic
    service = APIService(api_client=mock_api)
    result = service.fetch_with_retry("test_endpoint")
    
    assertions.assert_equal(result["status"], "success")
    assertions.assert_equal(mock_api.call_count("fetch_data"), 2)
```

## Error Testing Patterns

### Testing Expected Exceptions

```python
@test(name="test_validation_error_on_empty_input", expected_exception=ValidationError)
def test_validation_error_on_empty_input(assertions: AIGoAssertions):
    # This test expects a ValidationError to be raised
    validate_user_input("")  # Should raise ValidationError
```

### Testing Error Messages

```python
@test(name="test_specific_error_message")
def test_specific_error_message(assertions: AIGoAssertions):
    try:
        validate_age(-5)
        assertions.assert_true(False, "Expected ValidationError was not raised")
    except ValidationError as e:
        assertions.assert_in("must be positive", e.message)
        assertions.assert_equal(e.field, "age")
        assertions.assert_equal(e.value, -5)
```

### Testing Error Recovery

```python
@test(name="test_error_recovery_mechanism")
def test_error_recovery_mechanism(assertions: AIGoAssertions):
    # Setup error condition
    mock_service = AIGoMock("ExternalService")
    mock_service.set_side_effect("process", ConnectionError("Service unavailable"))
    
    # Test recovery
    processor = DataProcessor(external_service=mock_service)
    result = processor.process_with_fallback(test_data)
    
    # Should use fallback mechanism
    assertions.assert_true(result.used_fallback)
    assertions.assert_equal(result.status, "completed_with_fallback")
```

## Performance Testing

### Execution Time Testing

```python
@test(name="test_algorithm_performance", timeout=5.0)
def test_algorithm_performance(assertions: AIGoAssertions):
    import time
    
    large_dataset = generate_test_data(size=10000)
    
    start_time = time.time()
    result = sort_algorithm(large_dataset)
    execution_time = time.time() - start_time
    
    assertions.assert_true(execution_time < 1.0, 
                          f"Algorithm too slow: {execution_time:.3f}s")
    assertions.assert_true(is_sorted(result), "Result not properly sorted")
```

### Memory Usage Testing

```python
@test(name="test_memory_efficiency")
def test_memory_efficiency(assertions: AIGoAssertions):
    import psutil
    import gc
    
    process = psutil.Process()
    initial_memory = process.memory_info().rss / 1024 / 1024  # MB
    
    # Execute memory-intensive operation
    large_data = process_large_dataset(size=100000)
    
    # Force garbage collection
    del large_data
    gc.collect()
    
    final_memory = process.memory_info().rss / 1024 / 1024  # MB
    memory_increase = final_memory - initial_memory
    
    assertions.assert_true(memory_increase < 100, 
                          f"Memory leak detected: {memory_increase:.1f}MB increase")
```

### Benchmark Testing

```python
@test(name="test_performance_benchmark")
def test_performance_benchmark(assertions: AIGoAssertions):
    from aigo_developer_tools import AIGoProfiler
    
    profiler = AIGoProfiler()
    profiler.start_profiling()
    
    # Execute code to benchmark
    for i in range(1000):
        result = complex_calculation(i)
    
    profile_results = profiler.stop_profiling()
    
    # Check performance metrics
    assertions.assert_true(profile_results['total_time'] < 2.0, 
                          "Benchmark exceeded time limit")
    
    # Check function call efficiency
    if 'complex_calculation' in profile_results['function_calls']:
        avg_time = profile_results['function_calls']['complex_calculation']['avg_time']
        assertions.assert_true(avg_time < 0.001, 
                              f"Function too slow: {avg_time:.6f}s average")
```

## Integration Testing Guidelines

### End-to-End Workflow Testing

```python
@test(name="test_complete_user_workflow")
def test_complete_user_workflow(assertions: AIGoAssertions):
    # Test complete workflow from start to finish
    
    # Step 1: User registration
    user_data = {
        "username": "newuser",
        "email": "newuser@example.com",
        "password": "securepassword"
    }
    
    registration_result = register_user(user_data)
    assertions.assert_true(registration_result.success)
    
    # Step 2: Email verification
    verification_token = registration_result.verification_token
    verification_result = verify_email(verification_token)
    assertions.assert_true(verification_result.success)
    
    # Step 3: User login
    login_result = login_user(user_data["username"], user_data["password"])
    assertions.assert_true(login_result.success)
    assertions.assert_not_equal(login_result.session_token, None)
    
    # Step 4: Profile update
    profile_data = {"display_name": "New User", "bio": "Test user bio"}
    update_result = update_profile(login_result.session_token, profile_data)
    assertions.assert_true(update_result.success)
    
    # Step 5: Verify profile
    profile = get_profile(login_result.session_token)
    assertions.assert_equal(profile.display_name, "New User")
    assertions.assert_equal(profile.bio, "Test user bio")
```

### Cross-Component Integration

```python
@test(name="test_lexer_parser_interpreter_integration")
def test_lexer_parser_interpreter_integration(assertions: AIGoAssertions):
    aigo_source = """
    func factorial(n) {
        if (n <= 1) {
            return 1;
        }
        return n * factorial(n - 1);
    }
    
    let result = factorial(5);
    println("Factorial of 5 is: " + result);
    """
    
    # Test complete pipeline
    lexer = AIGoLexer(aigo_source)
    tokens = lexer.tokenize()
    assertions.assert_true(len(tokens) > 0, "Lexer produced no tokens")
    
    parser = AIGoParser(tokens)
    ast = parser.parse()
    assertions.assert_not_equal(ast, None, "Parser produced no AST")
    
    interpreter = AIGoInterpreter()
    result = interpreter.execute(ast)
    assertions.assert_equal(result, 120, "Interpreter produced incorrect result")
```

## Test Maintenance

### Keeping Tests Updated

1. **Review tests when code changes**
2. **Update test data when business rules change**
3. **Refactor tests to reduce duplication**
4. **Remove obsolete tests**

### Test Documentation

```python
@test(
    name="test_complex_business_logic",
    description="""
    Tests the complex business logic for calculating user discounts.
    
    This test verifies:
    1. Base discount calculation based on user tier
    2. Additional discounts for loyalty program members
    3. Maximum discount cap enforcement
    4. Seasonal promotion adjustments
    
    Test data includes edge cases for:
    - New users (no tier)
    - Premium users with loyalty status
    - Users at discount cap boundaries
    """,
    tags=["business_logic", "discounts", "integration"]
)
def test_complex_business_logic(assertions: AIGoAssertions):
    # Test implementation...
    pass
```

### Test Debugging

```python
@test(name="test_with_debugging_info")
def test_with_debugging_info(assertions: AIGoAssertions):
    # Enable detailed logging for debugging
    import logging
    logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        result = complex_operation(test_data)
        assertions.assert_equal(result.status, "success")
    except Exception as e:
        # Provide detailed error information
        print(f"Test failed with error: {e}")
        print(f"Test data: {test_data}")
        print(f"System state: {get_system_state()}")
        raise
```

## Best Practices Summary

### Do's

1. **Write descriptive test names** that explain the scenario
2. **Follow the AAA pattern** (Arrange, Act, Assert)
3. **Test one thing at a time** - keep tests focused
4. **Use fixtures** for reusable test data
5. **Mock external dependencies** to isolate units under test
6. **Test edge cases** and error conditions
7. **Include performance tests** for critical paths
8. **Document complex test scenarios**
9. **Keep tests independent** - no test should depend on another
10. **Clean up resources** in teardown methods

### Don'ts

1. **Don't write tests that depend on external services** without mocking
2. **Don't ignore failing tests** - fix them immediately
3. **Don't test implementation details** - focus on behavior
4. **Don't write overly complex tests** - simplify when possible
5. **Don't skip error testing** - errors are important scenarios
6. **Don't hardcode values** - use constants or fixtures
7. **Don't write tests without assertions** - every test must verify something
8. **Don't duplicate test logic** - extract common patterns
9. **Don't test third-party code** - focus on your own logic
10. **Don't write slow tests** without good reason

### Test Quality Checklist

Before committing tests, verify:

- [ ] Test name clearly describes the scenario
- [ ] Test follows AAA pattern
- [ ] All assertions have meaningful error messages
- [ ] External dependencies are mocked
- [ ] Test data is realistic but minimal
- [ ] Edge cases are covered
- [ ] Error conditions are tested
- [ ] Test runs quickly (< 1 second for unit tests)
- [ ] Test is independent of other tests
- [ ] Cleanup is performed in teardown

---

Following these guidelines will help create a robust, maintainable test suite that provides confidence in your AIGo applications and catches issues early in the development process.

