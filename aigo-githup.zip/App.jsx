import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert.jsx'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { Activity, Thermometer, Zap, Gauge, AlertTriangle, CheckCircle, XCircle } from 'lucide-react'
import './App.css'

function App() {
  const [sensorData, setSensorData] = useState([])
  const [anomalies, setAnomalies] = useState([])
  const [systemStatus, setSystemStatus] = useState('operational')
  const [edgeNodes, setEdgeNodes] = useState([
    { id: 'edge_node_001', status: 'online', sensors: 15, lastUpdate: new Date() },
    { id: 'edge_node_002', status: 'online', sensors: 12, lastUpdate: new Date() },
    { id: 'edge_node_003', status: 'warning', sensors: 8, lastUpdate: new Date() }
  ])

  // Simulate real-time data
  useEffect(() => {
    const interval = setInterval(() => {
      const newDataPoint = {
        timestamp: new Date().toLocaleTimeString(),
        temperature: 75 + (Math.random() - 0.5) * 20,
        vibration: 2.5 + (Math.random() - 0.5) * 3,
        pressure: 6.5 + (Math.random() - 0.5) * 2,
      }
      
      setSensorData(prev => [...prev.slice(-19), newDataPoint])
      
      // Simulate anomaly detection
      if (Math.random() < 0.1) {
        const anomaly = {
          id: Date.now(),
          type: ['temperature', 'vibration', 'pressure'][Math.floor(Math.random() * 3)],
          severity: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)],
          message: 'Threshold exceeded',
          timestamp: new Date().toLocaleTimeString(),
          nodeId: 'edge_node_001'
        }
        setAnomalies(prev => [anomaly, ...prev.slice(0, 9)])
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  const currentValues = sensorData.length > 0 ? sensorData[sensorData.length - 1] : {
    temperature: 0,
    vibration: 0,
    pressure: 0
  }

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'destructive'
      case 'medium': return 'default'
      case 'low': return 'secondary'
      default: return 'default'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'online': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'offline': return <XCircle className="h-4 w-4 text-red-500" />
      default: return <CheckCircle className="h-4 w-4 text-green-500" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Smart Factory IoT Dashboard</h1>
            <p className="text-gray-600">AIGo-powered Edge Computing System</p>
          </div>
          <Badge variant={systemStatus === 'operational' ? 'default' : 'destructive'} className="text-sm">
            System {systemStatus}
          </Badge>
        </div>

        {/* Real-time Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Temperature</CardTitle>
              <Thermometer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentValues.temperature.toFixed(1)}°C</div>
              <p className="text-xs text-muted-foreground">
                Normal range: 70-80°C
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Vibration</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentValues.vibration.toFixed(1)} mm/s</div>
              <p className="text-xs text-muted-foreground">
                Normal range: 1-4 mm/s
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pressure</CardTitle>
              <Gauge className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentValues.pressure.toFixed(1)} bar</div>
              <p className="text-xs text-muted-foreground">
                Normal range: 5-8 bar
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Real-time Sensor Data</CardTitle>
              <CardDescription>Live data from edge computing nodes</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={sensorData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="timestamp" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="temperature" stroke="#8884d8" strokeWidth={2} />
                  <Line type="monotone" dataKey="vibration" stroke="#82ca9d" strokeWidth={2} />
                  <Line type="monotone" dataKey="pressure" stroke="#ffc658" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Edge Node Performance</CardTitle>
              <CardDescription>AIGo runtime performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={[
                  { name: 'Operations/sec', value: 546915 },
                  { name: 'Function calls', value: 1017 },
                  { name: 'Execution time (ms)', value: 11.104 },
                  { name: 'Memory usage (MB)', value: 45 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Edge Nodes Status */}
        <Card>
          <CardHeader>
            <CardTitle>Edge Computing Nodes</CardTitle>
            <CardDescription>AIGo-powered edge devices status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {edgeNodes.map(node => (
                <div key={node.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(node.status)}
                    <div>
                      <p className="font-medium">{node.id}</p>
                      <p className="text-sm text-gray-500">{node.sensors} sensors</p>
                    </div>
                  </div>
                  <Badge variant={node.status === 'online' ? 'default' : 'secondary'}>
                    {node.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Anomalies */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Anomalies</CardTitle>
            <CardDescription>AI-powered anomaly detection results</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {anomalies.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No anomalies detected</p>
              ) : (
                anomalies.map(anomaly => (
                  <Alert key={anomaly.id}>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle className="flex items-center justify-between">
                      <span>{anomaly.type.toUpperCase()} Anomaly</span>
                      <Badge variant={getSeverityColor(anomaly.severity)}>
                        {anomaly.severity}
                      </Badge>
                    </AlertTitle>
                    <AlertDescription>
                      {anomaly.message} at {anomaly.timestamp} on {anomaly.nodeId}
                    </AlertDescription>
                  </Alert>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500">
          <p>Powered by AIGo Programming Language | Edge Computing Performance: 546,915 ops/sec</p>
        </div>
      </div>
    </div>
  )
}

export default App

