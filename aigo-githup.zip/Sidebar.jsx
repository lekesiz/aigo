import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { 
  BookOpen, 
  Code, 
  Search, 
  ChevronRight, 
  ChevronDown,
  Home,
  Zap,
  Users,
  Settings,
  FileText,
  Layers,
  Database,
  Shield,
  Cpu,
  Globe
} from 'lucide-react'

const Sidebar = ({ isOpen, onClose, searchQuery, setSearchQuery }) => {
  const location = useLocation()
  const [expandedSections, setExpandedSections] = useState({
    'getting-started': true,
    'language': true,
    'api': false,
    'examples': false,
    'community': false
  })

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const navigationItems = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: <Home className="h-4 w-4" />,
      items: [
        { title: 'Introduction', href: '/docs/introduction' },
        { title: 'Installation', href: '/docs/installation' },
        { title: 'Quick Start', href: '/docs/quick-start' },
        { title: 'Your First Program', href: '/docs/first-program' },
        { title: 'IDE Setup', href: '/docs/ide-setup' }
      ]
    },
    {
      id: 'language',
      title: 'Language Guide',
      icon: <BookOpen className="h-4 w-4" />,
      items: [
        { title: 'Syntax Overview', href: '/docs/syntax' },
        { title: 'Variables & Types', href: '/docs/variables' },
        { title: 'Functions', href: '/docs/functions' },
        { title: 'Control Flow', href: '/docs/control-flow' },
        { title: 'Error Handling', href: '/docs/error-handling' },
        { title: 'Data Structures', href: '/docs/data-structures' },
        { title: 'Modules & Packages', href: '/docs/modules' },
        { title: 'Memory Management', href: '/docs/memory' },
        { title: 'Concurrency', href: '/docs/concurrency' }
      ]
    },
    {
      id: 'api',
      title: 'API Reference',
      icon: <Code className="h-4 w-4" />,
      items: [
        { title: 'Standard Library', href: '/api/stdlib' },
        { title: 'Built-in Functions', href: '/api/builtins' },
        { title: 'Core Types', href: '/api/types' },
        { title: 'Collections', href: '/api/collections' },
        { title: 'I/O Operations', href: '/api/io' },
        { title: 'String Utilities', href: '/api/strings' },
        { title: 'Math Functions', href: '/api/math' },
        { title: 'Time & Date', href: '/api/time' }
      ]
    },
    {
      id: 'examples',
      title: 'Examples',
      icon: <FileText className="h-4 w-4" />,
      items: [
        { title: 'Basic Programs', href: '/examples/basic' },
        { title: 'Algorithms', href: '/examples/algorithms' },
        { title: 'Data Processing', href: '/examples/data' },
        { title: 'Web Development', href: '/examples/web' },
        { title: 'CLI Applications', href: '/examples/cli' },
        { title: 'AI Integration', href: '/examples/ai' },
        { title: 'Performance', href: '/examples/performance' }
      ]
    },
    {
      id: 'community',
      title: 'Community',
      icon: <Users className="h-4 w-4" />,
      items: [
        { title: 'Contributing', href: '/community/contributing' },
        { title: 'Code of Conduct', href: '/community/code-of-conduct' },
        { title: 'Style Guide', href: '/community/style-guide' },
        { title: 'Best Practices', href: '/community/best-practices' },
        { title: 'FAQ', href: '/community/faq' },
        { title: 'Troubleshooting', href: '/community/troubleshooting' }
      ]
    }
  ]

  const filteredItems = navigationItems.map(section => ({
    ...section,
    items: section.items.filter(item => 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      section.title.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(section => section.items.length > 0 || searchQuery === '')

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden" 
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-80 bg-background border-r transform transition-transform duration-200 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="p-4 border-b">
            <div className="flex items-center justify-between mb-4">
              <Link to="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Zap className="h-4 w-4 text-white" />
                </div>
                <span className="font-bold">AIGo Docs</span>
              </Link>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search docs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 p-4">
            <nav className="space-y-2">
              {filteredItems.map((section) => (
                <div key={section.id} className="space-y-1">
                  <Button
                    variant="ghost"
                    className="w-full justify-between p-2 h-auto font-medium"
                    onClick={() => toggleSection(section.id)}
                  >
                    <div className="flex items-center space-x-2">
                      {section.icon}
                      <span>{section.title}</span>
                    </div>
                    {expandedSections[section.id] ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>

                  {expandedSections[section.id] && (
                    <div className="ml-6 space-y-1">
                      {section.items.map((item) => (
                        <Link
                          key={item.href}
                          to={item.href}
                          className={`
                            block px-3 py-2 text-sm rounded-md transition-colors
                            ${location.pathname === item.href 
                              ? 'bg-primary text-primary-foreground' 
                              : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                            }
                          `}
                          onClick={onClose}
                        >
                          {item.title}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </nav>
          </ScrollArea>

          {/* Sidebar Footer */}
          <div className="p-4 border-t">
            <div className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Globe className="h-4 w-4 mr-2" />
                Language: English
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Sidebar

