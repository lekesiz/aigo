package dev.aigo.intellij.highlighting;

import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.options.colors.AttributesDescriptor;
import com.intellij.openapi.options.colors.ColorDescriptor;
import com.intellij.openapi.options.colors.ColorSettingsPage;
import dev.aigo.intellij.AIGoFileType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.Map;

/**
 * Color settings page for AIGo language
 */
public class AIGoColorSettingsPage implements ColorSettingsPage {
    
    private static final AttributesDescriptor[] DESCRIPTORS = new AttributesDescriptor[]{
        new AttributesDescriptor("Keywords", AIGoSyntaxHighlighter.KEYWORD),
        new AttributesDescriptor("Strings", AIGoSyntaxHighlighter.STRING),
        new AttributesDescriptor("Numbers", AIGoSyntaxHighlighter.NUMBER),
        new AttributesDescriptor("Comments", AIGoSyntaxHighlighter.COMMENT),
        new AttributesDescriptor("Operators", AIGoSyntaxHighlighter.OPERATOR),
        new AttributesDescriptor("Identifiers", AIGoSyntaxHighlighter.IDENTIFIER),
        new AttributesDescriptor("Function Names", AIGoSyntaxHighlighter.FUNCTION_NAME),
        new AttributesDescriptor("Type Names", AIGoSyntaxHighlighter.TYPE_NAME),
        new AttributesDescriptor("Braces", AIGoSyntaxHighlighter.BRACES),
        new AttributesDescriptor("Parentheses", AIGoSyntaxHighlighter.PARENTHESES),
        new AttributesDescriptor("Brackets", AIGoSyntaxHighlighter.BRACKETS),
    };
    
    @Nullable
    @Override
    public Icon getIcon() {
        return AIGoFileType.INSTANCE.getIcon();
    }
    
    @NotNull
    @Override
    public SyntaxHighlighter getHighlighter() {
        return new AIGoSyntaxHighlighter();
    }
    
    @NotNull
    @Override
    public String getDemoText() {
        return """
            // AIGo Language Demo
            /* Multi-line comment
               demonstrating syntax highlighting */
            
            import "std/io"
            import "std/math"
            
            // Function definition with type annotations
            func fibonacci(n: int) -> int {
                if (n <= 1) {
                    return n;
                }
                return fibonacci(n-1) + fibonacci(n-2);
            }
            
            // Struct definition
            struct Point {
                x: float,
                y: float
            }
            
            // Implementation block
            impl Point {
                func new(x: float, y: float) -> Point {
                    return Point { x: x, y: y };
                }
                
                func distance(&self, other: &Point) -> float {
                    let dx = self.x - other.x;
                    let dy = self.y - other.y;
                    return math.sqrt(dx*dx + dy*dy);
                }
            }
            
            // Main function with error handling
            func main() -> Result<(), Error> {
                let numbers = [1, 2, 3, 4, 5];
                let mut sum = 0;
                
                // For loop with pattern matching
                for num in numbers {
                    sum += num;
                }
                
                // String interpolation
                println("Sum: {sum}");
                
                // Error handling with try-catch
                try {
                    let result = fibonacci(10);
                    println("Fibonacci(10) = {result}");
                } catch (e: Error) {
                    println("Error: {e.message}");
                    return Err(e);
                }
                
                // Pattern matching
                let point = Point.new(3.0, 4.0);
                match point {
                    Point { x: 0.0, y: 0.0 } => println("Origin"),
                    Point { x, y } if x > 0.0 && y > 0.0 => println("First quadrant"),
                    _ => println("Other quadrant")
                }
                
                return Ok(());
            }
            """;
    }
    
    @Nullable
    @Override
    public Map<String, TextAttributesKey> getAdditionalHighlightingTagToDescriptorMap() {
        return null;
    }
    
    @NotNull
    @Override
    public AttributesDescriptor[] getAttributeDescriptors() {
        return DESCRIPTORS;
    }
    
    @NotNull
    @Override
    public ColorDescriptor[] getColorDescriptors() {
        return ColorDescriptor.EMPTY_ARRAY;
    }
    
    @NotNull
    @Override
    public String getDisplayName() {
        return "AIGo";
    }
}

