from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Package(db.Model):
    __tablename__ = 'packages'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    version = db.Column(db.String(20), nullable=False)
    description = db.Column(db.Text, nullable=True)
    author = db.Column(db.String(100), nullable=False)
    author_email = db.Column(db.String(120), nullable=True)
    homepage = db.Column(db.String(200), nullable=True)
    repository = db.Column(db.String(200), nullable=True)
    license = db.Column(db.String(50), nullable=True)
    keywords = db.Column(db.Text, nullable=True)  # JSON string
    dependencies = db.Column(db.Text, nullable=True)  # JSON string
    download_url = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.Integer, nullable=True)
    checksum = db.Column(db.String(64), nullable=True)
    downloads = db.Column(db.Integer, default=0)
    stars = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_verified = db.Column(db.Boolean, default=False)
    is_deprecated = db.Column(db.Boolean, default=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'version': self.version,
            'description': self.description,
            'author': self.author,
            'author_email': self.author_email,
            'homepage': self.homepage,
            'repository': self.repository,
            'license': self.license,
            'keywords': self.keywords,
            'dependencies': self.dependencies,
            'download_url': self.download_url,
            'file_size': self.file_size,
            'checksum': self.checksum,
            'downloads': self.downloads,
            'stars': self.stars,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_verified': self.is_verified,
            'is_deprecated': self.is_deprecated
        }

class PackageVersion(db.Model):
    __tablename__ = 'package_versions'
    
    id = db.Column(db.Integer, primary_key=True)
    package_id = db.Column(db.Integer, db.ForeignKey('packages.id'), nullable=False)
    version = db.Column(db.String(20), nullable=False)
    changelog = db.Column(db.Text, nullable=True)
    download_url = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.Integer, nullable=True)
    checksum = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_stable = db.Column(db.Boolean, default=True)
    
    package = db.relationship('Package', backref=db.backref('versions', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'package_id': self.package_id,
            'version': self.version,
            'changelog': self.changelog,
            'download_url': self.download_url,
            'file_size': self.file_size,
            'checksum': self.checksum,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_stable': self.is_stable
        }

class PackageReview(db.Model):
    __tablename__ = 'package_reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    package_id = db.Column(db.Integer, db.ForeignKey('packages.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    package = db.relationship('Package', backref=db.backref('reviews', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'package_id': self.package_id,
            'user_id': self.user_id,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

