#!/usr/bin/env python3
"""
AIGo Developer Tools Suite

Comprehensive developer tools for AIGo programming language including:
- Code formatter
- Syntax highlighter  
- Debugger
- Profiler
- REPL (Read-Eval-Print Loop)
- Language server features

Author: Manus AI
Version: 1.0.0
Date: June 5, 2025
"""

import os
import sys
import cmd
import json
import time
import traceback
import readline
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

# Import AIGo components
from aigo_test_adapter import AIGoTestAdapter
from aigo_error_handling_system import (
    AIGoError, ErrorLocation, ErrorContext, global_error_handler
)

class AIGoFormatter:
    """Code formatter for AIGo language"""
    
    def __init__(self):
        self.indent_size = 4
        self.max_line_length = 100
    
    def format_code(self, code: str) -> str:
        """Format AIGo code with proper indentation and style"""
        lines = code.split('\n')
        formatted_lines = []
        indent_level = 0
        
        for line in lines:
            stripped = line.strip()
            if not stripped:
                formatted_lines.append('')
                continue
            
            # Decrease indent for closing braces
            if stripped.startswith('}'):
                indent_level = max(0, indent_level - 1)
            
            # Add indentation
            formatted_line = ' ' * (indent_level * self.indent_size) + stripped
            formatted_lines.append(formatted_line)
            
            # Increase indent for opening braces
            if stripped.endswith('{'):
                indent_level += 1
        
        return '\n'.join(formatted_lines)
    
    def format_file(self, file_path: str) -> bool:
        """Format an AIGo file in place"""
        try:
            with open(file_path, 'r') as f:
                original_code = f.read()
            
            formatted_code = self.format_code(original_code)
            
            with open(file_path, 'w') as f:
                f.write(formatted_code)
            
            return True
        except Exception as e:
            print(f"Error formatting file {file_path}: {e}")
            return False

class AIGoSyntaxHighlighter:
    """Syntax highlighter for AIGo language"""
    
    KEYWORDS = {
        'let', 'func', 'if', 'else', 'for', 'while', 'return', 'break', 'continue',
        'try', 'catch', 'finally', 'throw', 'error_type', 'match', 'true', 'false'
    }
    
    OPERATORS = {
        '+', '-', '*', '/', '%', '=', '==', '!=', '<', '>', '<=', '>=',
        '&&', '||', '!', '&', '|', '^', '<<', '>>', '?'
    }
    
    DELIMITERS = {
        '(', ')', '[', ']', '{', '}', ';', ',', '.', ':'
    }
    
    def __init__(self):
        self.colors = {
            'keyword': '\033[94m',      # Blue
            'string': '\033[92m',       # Green
            'number': '\033[93m',       # Yellow
            'comment': '\033[90m',      # Gray
            'operator': '\033[95m',     # Magenta
            'delimiter': '\033[96m',    # Cyan
            'reset': '\033[0m'          # Reset
        }
    
    def highlight(self, code: str) -> str:
        """Apply syntax highlighting to AIGo code"""
        if not sys.stdout.isatty():
            return code  # No colors for non-terminal output
        
        tokens = self._tokenize(code)
        highlighted = []
        
        for token_type, token_value in tokens:
            color = self.colors.get(token_type, '')
            reset = self.colors['reset'] if color else ''
            highlighted.append(f"{color}{token_value}{reset}")
        
        return ''.join(highlighted)
    
    def _tokenize(self, code: str) -> List[Tuple[str, str]]:
        """Simple tokenizer for syntax highlighting"""
        tokens = []
        i = 0
        
        while i < len(code):
            char = code[i]
            
            # Skip whitespace
            if char.isspace():
                tokens.append(('whitespace', char))
                i += 1
                continue
            
            # Comments
            if char == '/' and i + 1 < len(code) and code[i + 1] == '/':
                comment_end = code.find('\n', i)
                if comment_end == -1:
                    comment_end = len(code)
                tokens.append(('comment', code[i:comment_end]))
                i = comment_end
                continue
            
            # Strings
            if char in ['"', "'"]:
                string_end = code.find(char, i + 1)
                if string_end == -1:
                    string_end = len(code)
                else:
                    string_end += 1
                tokens.append(('string', code[i:string_end]))
                i = string_end
                continue
            
            # Numbers
            if char.isdigit():
                num_end = i
                while num_end < len(code) and (code[num_end].isdigit() or code[num_end] == '.'):
                    num_end += 1
                tokens.append(('number', code[i:num_end]))
                i = num_end
                continue
            
            # Identifiers and keywords
            if char.isalpha() or char == '_':
                id_end = i
                while id_end < len(code) and (code[id_end].isalnum() or code[id_end] == '_'):
                    id_end += 1
                identifier = code[i:id_end]
                token_type = 'keyword' if identifier in self.KEYWORDS else 'identifier'
                tokens.append((token_type, identifier))
                i = id_end
                continue
            
            # Operators
            if char in self.OPERATORS:
                # Check for multi-character operators
                if i + 1 < len(code):
                    two_char = code[i:i+2]
                    if two_char in self.OPERATORS:
                        tokens.append(('operator', two_char))
                        i += 2
                        continue
                tokens.append(('operator', char))
                i += 1
                continue
            
            # Delimiters
            if char in self.DELIMITERS:
                tokens.append(('delimiter', char))
                i += 1
                continue
            
            # Unknown character
            tokens.append(('unknown', char))
            i += 1
        
        return tokens

@dataclass
class BreakPoint:
    """Represents a debugger breakpoint"""
    file_path: str
    line_number: int
    condition: Optional[str] = None
    enabled: bool = True

class AIGoDebugger:
    """Interactive debugger for AIGo language"""
    
    def __init__(self):
        self.breakpoints: List[BreakPoint] = []
        self.current_frame = None
        self.call_stack = []
        self.variables = {}
        self.step_mode = False
    
    def add_breakpoint(self, file_path: str, line_number: int, condition: str = None) -> int:
        """Add a breakpoint"""
        bp = BreakPoint(file_path, line_number, condition)
        self.breakpoints.append(bp)
        return len(self.breakpoints) - 1
    
    def remove_breakpoint(self, bp_id: int) -> bool:
        """Remove a breakpoint"""
        if 0 <= bp_id < len(self.breakpoints):
            self.breakpoints[bp_id].enabled = False
            return True
        return False
    
    def list_breakpoints(self) -> List[BreakPoint]:
        """List all active breakpoints"""
        return [bp for bp in self.breakpoints if bp.enabled]
    
    def should_break(self, file_path: str, line_number: int) -> bool:
        """Check if execution should break at this location"""
        if self.step_mode:
            return True
        
        for bp in self.breakpoints:
            if (bp.enabled and 
                bp.file_path == file_path and 
                bp.line_number == line_number):
                
                if bp.condition:
                    # Evaluate condition (simplified)
                    try:
                        return eval(bp.condition, {}, self.variables)
                    except:
                        return True
                return True
        
        return False
    
    def debug_session(self, code: str):
        """Start an interactive debug session"""
        print("AIGo Debugger - Interactive Session")
        print("Commands: step, continue, break <line>, vars, stack, quit")
        print("-" * 50)
        
        interpreter = AIGoTestAdapter()
        
        while True:
            try:
                command = input("(aigo-debug) ").strip().split()
                if not command:
                    continue
                
                cmd = command[0].lower()
                
                if cmd == 'quit' or cmd == 'q':
                    break
                elif cmd == 'step' or cmd == 's':
                    self.step_mode = True
                    print("Stepping...")
                elif cmd == 'continue' or cmd == 'c':
                    self.step_mode = False
                    print("Continuing...")
                elif cmd == 'break' or cmd == 'b':
                    if len(command) > 1:
                        try:
                            line = int(command[1])
                            bp_id = self.add_breakpoint("<debug>", line)
                            print(f"Breakpoint {bp_id} set at line {line}")
                        except ValueError:
                            print("Invalid line number")
                    else:
                        print("Usage: break <line_number>")
                elif cmd == 'vars' or cmd == 'v':
                    print("Variables:")
                    for name, value in self.variables.items():
                        print(f"  {name} = {value}")
                elif cmd == 'stack':
                    print("Call stack:")
                    for i, frame in enumerate(self.call_stack):
                        print(f"  {i}: {frame}")
                elif cmd == 'run' or cmd == 'r':
                    try:
                        result = interpreter.execute_code(code)
                        print(f"Result: {result}")
                    except Exception as e:
                        print(f"Error: {e}")
                else:
                    print(f"Unknown command: {cmd}")
                    
            except KeyboardInterrupt:
                print("\nUse 'quit' to exit debugger")
            except EOFError:
                break
        
        print("Debug session ended")

class AIGoProfiler:
    """Performance profiler for AIGo language"""
    
    def __init__(self):
        self.profile_data = {}
        self.start_time = None
        self.function_calls = {}
        self.memory_usage = {}
    
    def start_profiling(self):
        """Start profiling session"""
        self.start_time = time.time()
        self.profile_data = {}
        self.function_calls = {}
        self.memory_usage = {}
    
    def stop_profiling(self) -> Dict[str, Any]:
        """Stop profiling and return results"""
        if self.start_time:
            total_time = time.time() - self.start_time
            
            return {
                'total_time': total_time,
                'function_calls': self.function_calls,
                'memory_usage': self.memory_usage,
                'profile_data': self.profile_data
            }
        return {}
    
    def record_function_call(self, function_name: str, duration: float):
        """Record a function call"""
        if function_name not in self.function_calls:
            self.function_calls[function_name] = {
                'count': 0,
                'total_time': 0.0,
                'avg_time': 0.0
            }
        
        self.function_calls[function_name]['count'] += 1
        self.function_calls[function_name]['total_time'] += duration
        self.function_calls[function_name]['avg_time'] = (
            self.function_calls[function_name]['total_time'] / 
            self.function_calls[function_name]['count']
        )
    
    def generate_report(self) -> str:
        """Generate profiling report"""
        if not self.profile_data:
            return "No profiling data available"
        
        report = ["AIGo Profiling Report", "=" * 30, ""]
        
        # Function call statistics
        if self.function_calls:
            report.append("Function Call Statistics:")
            report.append("-" * 25)
            for func_name, stats in sorted(
                self.function_calls.items(), 
                key=lambda x: x[1]['total_time'], 
                reverse=True
            ):
                report.append(
                    f"{func_name}: {stats['count']} calls, "
                    f"{stats['total_time']:.3f}s total, "
                    f"{stats['avg_time']:.3f}s avg"
                )
            report.append("")
        
        return "\n".join(report)

class AIGoREPL(cmd.Cmd):
    """Read-Eval-Print Loop for AIGo language"""
    
    intro = """
    ╔══════════════════════════════════════╗
    ║           AIGo REPL v1.0             ║
    ║     Interactive AIGo Environment     ║
    ╚══════════════════════════════════════╝
    
    Type 'help' for available commands.
    Type 'exit' or Ctrl+D to quit.
    """
    
    prompt = 'aigo> '
    
    def __init__(self):
        super().__init__()
        self.interpreter = AIGoTestAdapter()
        self.highlighter = AIGoSyntaxHighlighter()
        self.formatter = AIGoFormatter()
        self.debugger = AIGoDebugger()
        self.profiler = AIGoProfiler()
        self.variables = {}
        self.history = []
    
    def do_eval(self, line):
        """Evaluate AIGo expression: eval <expression>"""
        if not line:
            print("Usage: eval <expression>")
            return
        
        try:
            result = self.interpreter.execute_code(line)
            print(f"=> {result}")
            self.history.append(('eval', line, result))
        except Exception as e:
            print(f"Error: {e}")
    
    def do_format(self, line):
        """Format AIGo code: format <code>"""
        if not line:
            print("Usage: format <code>")
            return
        
        formatted = self.formatter.format_code(line)
        print("Formatted code:")
        print(self.highlighter.highlight(formatted))
    
    def do_highlight(self, line):
        """Apply syntax highlighting: highlight <code>"""
        if not line:
            print("Usage: highlight <code>")
            return
        
        highlighted = self.highlighter.highlight(line)
        print(highlighted)
    
    def do_debug(self, line):
        """Start debug session: debug <code>"""
        if not line:
            print("Usage: debug <code>")
            return
        
        self.debugger.debug_session(line)
    
    def do_profile(self, line):
        """Profile code execution: profile <code>"""
        if not line:
            print("Usage: profile <code>")
            return
        
        self.profiler.start_profiling()
        try:
            result = self.interpreter.execute_code(line)
            profile_results = self.profiler.stop_profiling()
            print(f"Result: {result}")
            print(f"Execution time: {profile_results.get('total_time', 0):.3f}s")
        except Exception as e:
            print(f"Error: {e}")
    
    def do_vars(self, line):
        """Show variables: vars"""
        if self.variables:
            print("Variables:")
            for name, value in self.variables.items():
                print(f"  {name} = {value}")
        else:
            print("No variables defined")
    
    def do_history(self, line):
        """Show command history: history"""
        if self.history:
            print("Command History:")
            for i, (cmd_type, cmd, result) in enumerate(self.history[-10:], 1):
                print(f"  {i}: {cmd_type} {cmd}")
        else:
            print("No command history")
    
    def do_clear(self, line):
        """Clear screen: clear"""
        os.system('clear' if os.name == 'posix' else 'cls')
    
    def do_exit(self, line):
        """Exit REPL: exit"""
        print("Goodbye!")
        return True
    
    def do_EOF(self, line):
        """Handle Ctrl+D"""
        print("\nGoodbye!")
        return True
    
    def default(self, line):
        """Handle default input (treat as AIGo code)"""
        if line.strip():
            self.do_eval(line)
    
    def emptyline(self):
        """Handle empty line"""
        pass

class AIGoLanguageServer:
    """Language server features for AIGo"""
    
    def __init__(self):
        self.symbols = {}
        self.diagnostics = []
    
    def analyze_file(self, file_path: str) -> Dict[str, Any]:
        """Analyze AIGo file and provide diagnostics"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Simple analysis (can be extended)
            lines = content.split('\n')
            diagnostics = []
            
            for i, line in enumerate(lines, 1):
                # Check for common issues
                if line.strip().endswith(';') and 'func' in line:
                    diagnostics.append({
                        'line': i,
                        'column': len(line),
                        'severity': 'warning',
                        'message': 'Unnecessary semicolon after function declaration'
                    })
                
                if 'println(' in line and not line.strip().endswith(';'):
                    diagnostics.append({
                        'line': i,
                        'column': len(line),
                        'severity': 'error',
                        'message': 'Missing semicolon'
                    })
            
            return {
                'file_path': file_path,
                'diagnostics': diagnostics,
                'symbols': self._extract_symbols(content)
            }
            
        except Exception as e:
            return {
                'file_path': file_path,
                'error': str(e),
                'diagnostics': [],
                'symbols': {}
            }
    
    def _extract_symbols(self, content: str) -> Dict[str, List[Dict]]:
        """Extract symbols from AIGo code"""
        symbols = {'functions': [], 'variables': []}
        
        lines = content.split('\n')
        for i, line in enumerate(lines, 1):
            # Extract function definitions
            if line.strip().startswith('func '):
                func_name = line.split('func ')[1].split('(')[0].strip()
                symbols['functions'].append({
                    'name': func_name,
                    'line': i,
                    'type': 'function'
                })
            
            # Extract variable declarations
            if line.strip().startswith('let '):
                var_name = line.split('let ')[1].split('=')[0].strip()
                symbols['variables'].append({
                    'name': var_name,
                    'line': i,
                    'type': 'variable'
                })
        
        return symbols

def main():
    """Main entry point for developer tools"""
    if len(sys.argv) < 2:
        print("AIGo Developer Tools Suite")
        print("Usage: python aigo_developer_tools.py <command> [args]")
        print("\nCommands:")
        print("  repl          - Start interactive REPL")
        print("  format <file> - Format AIGo file")
        print("  analyze <file>- Analyze AIGo file")
        print("  debug <file>  - Debug AIGo file")
        return
    
    command = sys.argv[1].lower()
    
    if command == 'repl':
        repl = AIGoREPL()
        try:
            repl.cmdloop()
        except KeyboardInterrupt:
            print("\nGoodbye!")
    
    elif command == 'format':
        if len(sys.argv) < 3:
            print("Usage: format <file>")
            return
        
        formatter = AIGoFormatter()
        file_path = sys.argv[2]
        
        if formatter.format_file(file_path):
            print(f"Formatted {file_path}")
        else:
            print(f"Failed to format {file_path}")
    
    elif command == 'analyze':
        if len(sys.argv) < 3:
            print("Usage: analyze <file>")
            return
        
        language_server = AIGoLanguageServer()
        file_path = sys.argv[2]
        
        analysis = language_server.analyze_file(file_path)
        print(json.dumps(analysis, indent=2))
    
    elif command == 'debug':
        if len(sys.argv) < 3:
            print("Usage: debug <file>")
            return
        
        file_path = sys.argv[2]
        try:
            with open(file_path, 'r') as f:
                code = f.read()
            
            debugger = AIGoDebugger()
            debugger.debug_session(code)
        except FileNotFoundError:
            print(f"File not found: {file_path}")
    
    else:
        print(f"Unknown command: {command}")

if __name__ == "__main__":
    main()

