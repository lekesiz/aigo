import * as vscode from 'vscode';

export class AIGoCompletionProvider implements vscode.CompletionItemProvider {
    
    provideCompletionItems(
        document: vscode.TextDocument,
        position: vscode.Position,
        token: vscode.CancellationToken,
        context: vscode.CompletionContext
    ): vscode.ProviderResult<vscode.CompletionItem[] | vscode.CompletionList> {
        
        const linePrefix = document.lineAt(position).text.substr(0, position.character);
        
        // Keywords completion
        const keywords = this.getKeywordCompletions();
        
        // Function completion
        const functions = this.getFunctionCompletions();
        
        // Type completion
        const types = this.getTypeCompletions();
        
        // Snippet completion
        const snippets = this.getSnippetCompletions();
        
        // Context-aware completions
        const contextual = this.getContextualCompletions(linePrefix, document, position);
        
        return [...keywords, ...functions, ...types, ...snippets, ...contextual];
    }

    private getKeywordCompletions(): vscode.CompletionItem[] {
        const keywords = [
            'func', 'let', 'const', 'var', 'if', 'else', 'for', 'while', 
            'break', 'continue', 'return', 'try', 'catch', 'finally', 
            'throw', 'match', 'case', 'default', 'import', 'export',
            'struct', 'enum', 'interface', 'trait', 'async', 'await',
            'true', 'false', 'null', 'undefined'
        ];

        return keywords.map(keyword => {
            const item = new vscode.CompletionItem(keyword, vscode.CompletionItemKind.Keyword);
            item.detail = `AIGo keyword: ${keyword}`;
            item.documentation = this.getKeywordDocumentation(keyword);
            return item;
        });
    }

    private getFunctionCompletions(): vscode.CompletionItem[] {
        const functions = [
            {
                name: 'println',
                signature: 'println(message: string)',
                description: 'Print a message to the console with a newline',
                insertText: 'println(${1:message})'
            },
            {
                name: 'print',
                signature: 'print(message: string)',
                description: 'Print a message to the console',
                insertText: 'print(${1:message})'
            },
            {
                name: 'input',
                signature: 'input(prompt: string) -> string',
                description: 'Read input from the user',
                insertText: 'input(${1:prompt})'
            },
            {
                name: 'len',
                signature: 'len(collection: Array<T>) -> int',
                description: 'Get the length of a collection',
                insertText: 'len(${1:collection})'
            },
            {
                name: 'push',
                signature: 'push(array: Array<T>, item: T)',
                description: 'Add an item to the end of an array',
                insertText: 'push(${1:array}, ${2:item})'
            },
            {
                name: 'pop',
                signature: 'pop(array: Array<T>) -> T',
                description: 'Remove and return the last item from an array',
                insertText: 'pop(${1:array})'
            }
        ];

        return functions.map(func => {
            const item = new vscode.CompletionItem(func.name, vscode.CompletionItemKind.Function);
            item.detail = func.signature;
            item.documentation = new vscode.MarkdownString(func.description);
            item.insertText = new vscode.SnippetString(func.insertText);
            return item;
        });
    }

    private getTypeCompletions(): vscode.CompletionItem[] {
        const types = [
            { name: 'int', description: 'Integer type' },
            { name: 'float', description: 'Floating point number type' },
            { name: 'string', description: 'String type' },
            { name: 'bool', description: 'Boolean type' },
            { name: 'char', description: 'Character type' },
            { name: 'byte', description: 'Byte type' },
            { name: 'void', description: 'Void type' },
            { name: 'Array', description: 'Array collection type' },
            { name: 'Map', description: 'Map collection type' },
            { name: 'Set', description: 'Set collection type' },
            { name: 'Result', description: 'Result type for error handling' },
            { name: 'Option', description: 'Optional value type' }
        ];

        return types.map(type => {
            const item = new vscode.CompletionItem(type.name, vscode.CompletionItemKind.TypeParameter);
            item.detail = `AIGo type: ${type.name}`;
            item.documentation = type.description;
            return item;
        });
    }

    private getSnippetCompletions(): vscode.CompletionItem[] {
        const snippets = [
            {
                name: 'func',
                label: 'func - Function declaration',
                insertText: 'func ${1:name}(${2:params}) -> ${3:return_type} {\n\t${4:// body}\n\treturn ${5:value};\n}',
                description: 'Create a new function'
            },
            {
                name: 'if',
                label: 'if - If statement',
                insertText: 'if (${1:condition}) {\n\t${2:// body}\n}',
                description: 'Create an if statement'
            },
            {
                name: 'ifelse',
                label: 'ifelse - If-else statement',
                insertText: 'if (${1:condition}) {\n\t${2:// if body}\n} else {\n\t${3:// else body}\n}',
                description: 'Create an if-else statement'
            },
            {
                name: 'for',
                label: 'for - For loop',
                insertText: 'for (${1:i} = 0; ${1:i} < ${2:length}; ${1:i}++) {\n\t${3:// body}\n}',
                description: 'Create a for loop'
            },
            {
                name: 'while',
                label: 'while - While loop',
                insertText: 'while (${1:condition}) {\n\t${2:// body}\n}',
                description: 'Create a while loop'
            },
            {
                name: 'try',
                label: 'try - Try-catch block',
                insertText: 'try {\n\t${1:// risky code}\n} catch (${2:Error} e) {\n\t${3:// handle error}\n}',
                description: 'Create a try-catch block'
            },
            {
                name: 'struct',
                label: 'struct - Struct definition',
                insertText: 'struct ${1:Name} {\n\t${2:field}: ${3:type};\n}',
                description: 'Create a struct definition'
            },
            {
                name: 'enum',
                label: 'enum - Enum definition',
                insertText: 'enum ${1:Name} {\n\t${2:Variant1},\n\t${3:Variant2}\n}',
                description: 'Create an enum definition'
            }
        ];

        return snippets.map(snippet => {
            const item = new vscode.CompletionItem(snippet.label, vscode.CompletionItemKind.Snippet);
            item.insertText = new vscode.SnippetString(snippet.insertText);
            item.documentation = snippet.description;
            item.sortText = '0' + snippet.name; // Prioritize snippets
            return item;
        });
    }

    private getContextualCompletions(
        linePrefix: string, 
        document: vscode.TextDocument, 
        position: vscode.Position
    ): vscode.CompletionItem[] {
        const completions: vscode.CompletionItem[] = [];

        // Function parameter completion
        if (linePrefix.includes('(') && !linePrefix.includes(')')) {
            completions.push(...this.getFunctionParameterCompletions());
        }

        // Import completion
        if (linePrefix.trim().startsWith('import')) {
            completions.push(...this.getImportCompletions());
        }

        // Error type completion
        if (linePrefix.includes('catch (')) {
            completions.push(...this.getErrorTypeCompletions());
        }

        // Variable completion from current scope
        completions.push(...this.getVariableCompletions(document, position));

        return completions;
    }

    private getFunctionParameterCompletions(): vscode.CompletionItem[] {
        const params = [
            { name: 'name: string', description: 'String parameter' },
            { name: 'value: int', description: 'Integer parameter' },
            { name: 'flag: bool', description: 'Boolean parameter' },
            { name: 'items: Array<T>', description: 'Array parameter' }
        ];

        return params.map(param => {
            const item = new vscode.CompletionItem(param.name, vscode.CompletionItemKind.Variable);
            item.documentation = param.description;
            return item;
        });
    }

    private getImportCompletions(): vscode.CompletionItem[] {
        const modules = [
            { name: 'std.io', description: 'Standard I/O module' },
            { name: 'std.collections', description: 'Collections module' },
            { name: 'std.string', description: 'String utilities module' },
            { name: 'std.math', description: 'Math functions module' },
            { name: 'std.time', description: 'Time utilities module' },
            { name: 'std.json', description: 'JSON parsing module' }
        ];

        return modules.map(module => {
            const item = new vscode.CompletionItem(module.name, vscode.CompletionItemKind.Module);
            item.documentation = module.description;
            return item;
        });
    }

    private getErrorTypeCompletions(): vscode.CompletionItem[] {
        const errorTypes = [
            'RuntimeError', 'TypeError', 'ValueError', 'IndexError',
            'KeyError', 'IOError', 'NetworkError', 'ParseError'
        ];

        return errorTypes.map(errorType => {
            const item = new vscode.CompletionItem(errorType, vscode.CompletionItemKind.Class);
            item.detail = `Error type: ${errorType}`;
            return item;
        });
    }

    private getVariableCompletions(document: vscode.TextDocument, position: vscode.Position): vscode.CompletionItem[] {
        const variables: vscode.CompletionItem[] = [];
        const text = document.getText();
        
        // Simple regex to find variable declarations
        const variableRegex = /(?:let|var|const)\s+([a-zA-Z_][a-zA-Z0-9_]*)/g;
        let match;
        
        while ((match = variableRegex.exec(text)) !== null) {
            const varName = match[1];
            const item = new vscode.CompletionItem(varName, vscode.CompletionItemKind.Variable);
            item.detail = 'Local variable';
            variables.push(item);
        }

        // Find function names
        const functionRegex = /func\s+([a-zA-Z_][a-zA-Z0-9_]*)/g;
        while ((match = functionRegex.exec(text)) !== null) {
            const funcName = match[1];
            const item = new vscode.CompletionItem(funcName, vscode.CompletionItemKind.Function);
            item.detail = 'User-defined function';
            variables.push(item);
        }

        return variables;
    }

    private getKeywordDocumentation(keyword: string): vscode.MarkdownString {
        const docs: { [key: string]: string } = {
            'func': 'Declares a function\n\n```aigo\nfunc name(params) -> return_type {\n    // body\n}\n```',
            'let': 'Declares a mutable variable\n\n```aigo\nlet variable = value;\n```',
            'const': 'Declares an immutable constant\n\n```aigo\nconst CONSTANT = value;\n```',
            'if': 'Conditional statement\n\n```aigo\nif (condition) {\n    // body\n}\n```',
            'try': 'Error handling block\n\n```aigo\ntry {\n    // risky code\n} catch (Error e) {\n    // handle error\n}\n```'
        };

        return new vscode.MarkdownString(docs[keyword] || `AIGo keyword: ${keyword}`);
    }
}

