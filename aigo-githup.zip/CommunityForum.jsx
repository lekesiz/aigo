import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card.jsx'
import { Button } from './ui/button.jsx'
import { Badge } from './ui/badge.jsx'
import { Input } from './ui/input.jsx'
import { Textarea } from './ui/textarea.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.jsx'
import { 
  MessageSquare, 
  ThumbsUp, 
  ThumbsDown, 
  Eye, 
  Clock, 
  User,
  Plus,
  Filter,
  ArrowUpDown,
  Pin,
  CheckCircle,
  HelpCircle,
  BookOpen,
  Lightbulb,
  Tag,
  Reply,
  Edit,
  Trash2
} from 'lucide-react'

const CommunityForum = ({ searchQuery }) => {
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [category, setCategory] = useState('')
  const [sortBy, setSortBy] = useState('created_at')

  // Mock forum data
  const mockPosts = [
    {
      id: 1,
      title: "Best practices for error handling in AIGo",
      content: "I'm working on a large AIGo project and wondering about the best approaches for error handling. Should I use try-catch blocks everywhere or rely more on Result types?",
      author_id: 1,
      author_name: "alice_dev",
      category: "discussion",
      tags: ["error-handling", "best-practices", "patterns"],
      upvotes: 23,
      downvotes: 2,
      views: 234,
      is_pinned: false,
      is_solved: false,
      created_at: "2024-12-05T10:30:00Z",
      updated_at: "2024-12-05T14:20:00Z",
      comments_count: 12
    },
    {
      id: 2,
      title: "How to implement async/await patterns?",
      content: "I'm coming from JavaScript and trying to understand how async/await works in AIGo. Are there any gotchas I should be aware of?",
      author_id: 2,
      author_name: "bob_coder",
      category: "question",
      tags: ["async", "await", "concurrency", "beginner"],
      upvotes: 15,
      downvotes: 0,
      views: 156,
      is_pinned: false,
      is_solved: true,
      created_at: "2024-12-05T08:15:00Z",
      updated_at: "2024-12-05T12:45:00Z",
      comments_count: 8
    },
    {
      id: 3,
      title: "Building a web server with AIGo - Complete Tutorial",
      content: "In this tutorial, I'll walk you through building a complete web server using AIGo's HTTP library. We'll cover routing, middleware, and database integration.",
      author_id: 3,
      author_name: "charlie_dev",
      category: "tutorial",
      tags: ["web-server", "http", "tutorial", "database"],
      upvotes: 45,
      downvotes: 1,
      views: 567,
      is_pinned: true,
      is_solved: false,
      created_at: "2024-12-04T16:00:00Z",
      updated_at: "2024-12-05T09:30:00Z",
      comments_count: 15
    },
    {
      id: 4,
      title: "My AIGo CLI tool for package management",
      content: "I've built a CLI tool that makes it easier to manage AIGo packages. It includes features like dependency resolution, version management, and more. Check it out!",
      author_id: 4,
      author_name: "diana_builder",
      category: "showcase",
      tags: ["cli", "tools", "package-management", "open-source"],
      upvotes: 32,
      downvotes: 0,
      views: 289,
      is_pinned: false,
      is_solved: false,
      created_at: "2024-12-04T14:20:00Z",
      updated_at: "2024-12-04T18:45:00Z",
      comments_count: 9
    },
    {
      id: 5,
      title: "Memory management in AIGo vs Rust",
      content: "Can someone explain the differences between AIGo's memory management and Rust's ownership system? I'm trying to understand when to use manual memory management in AIGo.",
      author_id: 5,
      author_name: "eve_systems",
      category: "discussion",
      tags: ["memory-management", "rust", "comparison", "performance"],
      upvotes: 18,
      downvotes: 3,
      views: 178,
      is_pinned: false,
      is_solved: false,
      created_at: "2024-12-04T11:30:00Z",
      updated_at: "2024-12-04T15:20:00Z",
      comments_count: 6
    }
  ]

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      let filteredPosts = mockPosts

      // Apply search filter
      if (searchQuery) {
        filteredPosts = filteredPosts.filter(post =>
          post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
          post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      }

      // Apply category filter
      if (category) {
        filteredPosts = filteredPosts.filter(post => post.category === category)
      }

      // Apply sorting
      filteredPosts.sort((a, b) => {
        switch (sortBy) {
          case 'upvotes':
            return b.upvotes - a.upvotes
          case 'views':
            return b.views - a.views
          case 'comments':
            return b.comments_count - a.comments_count
          case 'created_at':
          default:
            return new Date(b.created_at) - new Date(a.created_at)
        }
      })

      // Pinned posts first
      filteredPosts.sort((a, b) => {
        if (a.is_pinned && !b.is_pinned) return -1
        if (!a.is_pinned && b.is_pinned) return 1
        return 0
      })

      setPosts(filteredPosts)
      setLoading(false)
    }, 500)
  }, [searchQuery, category, sortBy])

  const formatDate = (dateString) => {
    const now = new Date()
    const date = new Date(dateString)
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return 'Just now'
    if (diffInHours < 24) return `${diffInHours} hours ago`
    if (diffInHours < 48) return 'Yesterday'
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'question':
        return <HelpCircle className="h-4 w-4" />
      case 'tutorial':
        return <BookOpen className="h-4 w-4" />
      case 'showcase':
        return <Lightbulb className="h-4 w-4" />
      case 'discussion':
      default:
        return <MessageSquare className="h-4 w-4" />
    }
  }

  const getCategoryColor = (category) => {
    switch (category) {
      case 'question':
        return 'bg-blue-100 text-blue-800'
      case 'tutorial':
        return 'bg-green-100 text-green-800'
      case 'showcase':
        return 'bg-purple-100 text-purple-800'
      case 'discussion':
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="space-y-8">
      <Routes>
        <Route path="/" element={
          <div className="space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <h1 className="text-4xl font-bold">Community Forum</h1>
                <p className="text-xl text-muted-foreground">
                  Connect with fellow AIGo developers, ask questions, and share knowledge
                </p>
              </div>
              <Button size="lg" className="flex items-center space-x-2">
                <Plus className="h-5 w-5" />
                <span>New Post</span>
              </Button>
            </div>

            {/* Filters and Sorting */}
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4" />
                  <select 
                    value={category} 
                    onChange={(e) => setCategory(e.target.value)}
                    className="border rounded-md px-3 py-2 text-sm"
                  >
                    <option value="">All Categories</option>
                    <option value="discussion">Discussions</option>
                    <option value="question">Questions</option>
                    <option value="tutorial">Tutorials</option>
                    <option value="showcase">Showcase</option>
                  </select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Sort className="h-4 w-4" />
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="border rounded-md px-3 py-2 text-sm"
                  >
                    <option value="created_at">Latest</option>
                    <option value="upvotes">Most Upvoted</option>
                    <option value="views">Most Viewed</option>
                    <option value="comments">Most Discussed</option>
                  </select>
                </div>
              </div>

              <div className="text-sm text-muted-foreground">
                {posts.length} posts found
              </div>
            </div>

            {/* Posts List */}
            <div className="space-y-4">
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-4 text-muted-foreground">Loading discussions...</p>
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center py-12">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No posts found</h3>
                  <p className="text-muted-foreground">Try adjusting your search or filters</p>
                </div>
              ) : (
                posts.map((post) => (
                  <Card key={post.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        {/* Vote Section */}
                        <div className="flex flex-col items-center space-y-2 min-w-[60px]">
                          <Button variant="ghost" size="sm" className="p-1">
                            <ThumbsUp className="h-4 w-4" />
                          </Button>
                          <span className="text-sm font-medium">{post.upvotes - post.downvotes}</span>
                          <Button variant="ghost" size="sm" className="p-1">
                            <ThumbsDown className="h-4 w-4" />
                          </Button>
                        </div>

                        {/* Content Section */}
                        <div className="flex-1 space-y-3">
                          {/* Post Header */}
                          <div className="flex items-start justify-between">
                            <div className="space-y-2">
                              <div className="flex items-center space-x-2">
                                {post.is_pinned && (
                                  <Pin className="h-4 w-4 text-orange-500" />
                                )}
                                <Badge className={`${getCategoryColor(post.category)} flex items-center space-x-1`}>
                                  {getCategoryIcon(post.category)}
                                  <span>{post.category}</span>
                                </Badge>
                                {post.is_solved && (
                                  <Badge className="bg-green-100 text-green-800 flex items-center space-x-1">
                                    <CheckCircle className="h-3 w-3" />
                                    <span>Solved</span>
                                  </Badge>
                                )}
                              </div>
                              <h3 className="text-lg font-semibold hover:text-blue-600 cursor-pointer">
                                {post.title}
                              </h3>
                            </div>
                          </div>

                          {/* Post Content Preview */}
                          <p className="text-muted-foreground text-sm line-clamp-2">
                            {post.content}
                          </p>

                          {/* Tags */}
                          <div className="flex flex-wrap gap-2">
                            {post.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                <Tag className="h-3 w-3 mr-1" />
                                {tag}
                              </Badge>
                            ))}
                          </div>

                          {/* Post Meta */}
                          <div className="flex items-center justify-between text-sm text-muted-foreground">
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-1">
                                <User className="h-4 w-4" />
                                <span>{post.author_name}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Clock className="h-4 w-4" />
                                <span>{formatDate(post.created_at)}</span>
                              </div>
                            </div>

                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-1">
                                <Eye className="h-4 w-4" />
                                <span>{post.views}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <MessageSquare className="h-4 w-4" />
                                <span>{post.comments_count}</span>
                              </div>
                              <Button variant="outline" size="sm">
                                View Discussion
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Load More */}
            {posts.length > 0 && (
              <div className="text-center">
                <Button variant="outline" size="lg">
                  Load More Posts
                </Button>
              </div>
            )}
          </div>
        } />
        
        <Route path="/questions" element={
          <div className="text-center py-16">
            <h1 className="text-4xl font-bold mb-4">Questions</h1>
            <p className="text-xl text-muted-foreground">Get help from the community</p>
          </div>
        } />
        
        <Route path="/tutorials" element={
          <div className="text-center py-16">
            <h1 className="text-4xl font-bold mb-4">Tutorials</h1>
            <p className="text-xl text-muted-foreground">Learn from community tutorials</p>
          </div>
        } />
        
        <Route path="/showcase" element={
          <div className="text-center py-16">
            <h1 className="text-4xl font-bold mb-4">Showcase</h1>
            <p className="text-xl text-muted-foreground">Show off your AIGo projects</p>
          </div>
        } />
      </Routes>
    </div>
  )
}

export default CommunityForum

