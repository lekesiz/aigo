import * as vscode from 'vscode';
import { AIGoLanguageClient } from './languageClient';
import { AIGoDebugAdapterFactory } from './debugAdapter';
import { AIGoFormatter } from './formatter';
import { AIGoCodeLensProvider } from './codeLens';
import { AIGoHoverProvider } from './hoverProvider';
import { AIGoCompletionProvider } from './completionProvider';

let client: AIGoLanguageClient;

export function activate(context: vscode.ExtensionContext) {
    console.log('AIGo extension is now active!');

    // Initialize language client
    client = new AIGoLanguageClient(context);
    client.start();

    // Register debug adapter
    const debugAdapterFactory = new AIGoDebugAdapterFactory();
    context.subscriptions.push(
        vscode.debug.registerDebugAdapterDescriptorFactory('aigo', debugAdapterFactory)
    );

    // Register formatter
    const formatter = new AIGoFormatter();
    context.subscriptions.push(
        vscode.languages.registerDocumentFormattingEditProvider('aigo', formatter)
    );

    // Register code lens provider
    const codeLensProvider = new AIGoCodeLensProvider();
    context.subscriptions.push(
        vscode.languages.registerCodeLensProvider('aigo', codeLensProvider)
    );

    // Register hover provider
    const hoverProvider = new AIGoHoverProvider();
    context.subscriptions.push(
        vscode.languages.registerHoverProvider('aigo', hoverProvider)
    );

    // Register completion provider
    const completionProvider = new AIGoCompletionProvider();
    context.subscriptions.push(
        vscode.languages.registerCompletionItemProvider('aigo', completionProvider, '.', '(', ' ')
    );

    // Register commands
    registerCommands(context);

    // Setup file watchers
    setupFileWatchers(context);

    // Show welcome message
    showWelcomeMessage(context);
}

export function deactivate(): Thenable<void> | undefined {
    if (!client) {
        return undefined;
    }
    return client.stop();
}

function registerCommands(context: vscode.ExtensionContext) {
    // Run AIGo file command
    const runFileCommand = vscode.commands.registerCommand('aigo.runFile', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        if (!activeEditor || activeEditor.document.languageId !== 'aigo') {
            vscode.window.showErrorMessage('Please open an AIGo file first.');
            return;
        }

        const filePath = activeEditor.document.fileName;
        const config = vscode.workspace.getConfiguration('aigo');
        const interpreterPath = config.get<string>('interpreterPath', 'python');

        const terminal = vscode.window.createTerminal('AIGo');
        terminal.sendText(`${interpreterPath} aigo_interpreter.py "${filePath}"`);
        terminal.show();
    });

    // Format document command
    const formatCommand = vscode.commands.registerCommand('aigo.formatDocument', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        if (!activeEditor || activeEditor.document.languageId !== 'aigo') {
            vscode.window.showErrorMessage('Please open an AIGo file first.');
            return;
        }

        await vscode.commands.executeCommand('editor.action.formatDocument');
    });

    // Debug file command
    const debugCommand = vscode.commands.registerCommand('aigo.debugFile', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        if (!activeEditor || activeEditor.document.languageId !== 'aigo') {
            vscode.window.showErrorMessage('Please open an AIGo file first.');
            return;
        }

        const filePath = activeEditor.document.fileName;
        const debugConfig = {
            type: 'aigo',
            request: 'launch',
            name: 'Debug AIGo File',
            program: filePath,
            console: 'integratedTerminal'
        };

        await vscode.debug.startDebugging(undefined, debugConfig);
    });

    // Show documentation command
    const docsCommand = vscode.commands.registerCommand('aigo.showDocumentation', () => {
        vscode.env.openExternal(vscode.Uri.parse('https://aigo-lang.org/docs'));
    });

    // Create new AIGo file command
    const newFileCommand = vscode.commands.registerCommand('aigo.newFile', async () => {
        const fileName = await vscode.window.showInputBox({
            prompt: 'Enter file name',
            placeHolder: 'example.aigo'
        });

        if (fileName) {
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
            if (workspaceFolder) {
                const filePath = vscode.Uri.joinPath(workspaceFolder.uri, fileName);
                const template = getFileTemplate();
                
                await vscode.workspace.fs.writeFile(filePath, Buffer.from(template));
                const document = await vscode.workspace.openTextDocument(filePath);
                await vscode.window.showTextDocument(document);
            }
        }
    });

    // Insert code snippet command
    const snippetCommand = vscode.commands.registerCommand('aigo.insertSnippet', async () => {
        const snippets = [
            { label: 'Function', value: 'func ${1:name}(${2:params}) {\n\t${3:// body}\n}' },
            { label: 'If Statement', value: 'if (${1:condition}) {\n\t${2:// body}\n}' },
            { label: 'For Loop', value: 'for (${1:i} = 0; ${1:i} < ${2:length}; ${1:i}++) {\n\t${3:// body}\n}' },
            { label: 'Try-Catch', value: 'try {\n\t${1:// risky code}\n} catch (${2:Error} e) {\n\t${3:// handle error}\n}' }
        ];

        const selected = await vscode.window.showQuickPick(snippets, {
            placeHolder: 'Select a code snippet'
        });

        if (selected) {
            const activeEditor = vscode.window.activeTextEditor;
            if (activeEditor) {
                const snippet = new vscode.SnippetString(selected.value);
                await activeEditor.insertSnippet(snippet);
            }
        }
    });

    context.subscriptions.push(
        runFileCommand,
        formatCommand,
        debugCommand,
        docsCommand,
        newFileCommand,
        snippetCommand
    );
}

function setupFileWatchers(context: vscode.ExtensionContext) {
    // Watch for AIGo file changes
    const watcher = vscode.workspace.createFileSystemWatcher('**/*.aigo');
    
    watcher.onDidCreate((uri) => {
        console.log(`AIGo file created: ${uri.fsPath}`);
    });

    watcher.onDidChange((uri) => {
        console.log(`AIGo file changed: ${uri.fsPath}`);
        // Trigger re-analysis if needed
    });

    watcher.onDidDelete((uri) => {
        console.log(`AIGo file deleted: ${uri.fsPath}`);
    });

    context.subscriptions.push(watcher);
}

function showWelcomeMessage(context: vscode.ExtensionContext) {
    const hasShownWelcome = context.globalState.get('aigo.hasShownWelcome', false);
    
    if (!hasShownWelcome) {
        vscode.window.showInformationMessage(
            'Welcome to AIGo! Get started with our interactive tutorials.',
            'Open Tutorial',
            'View Documentation'
        ).then(selection => {
            if (selection === 'Open Tutorial') {
                vscode.env.openExternal(vscode.Uri.parse('https://aigo-lang.org/tutorial'));
            } else if (selection === 'View Documentation') {
                vscode.env.openExternal(vscode.Uri.parse('https://aigo-lang.org/docs'));
            }
        });

        context.globalState.update('aigo.hasShownWelcome', true);
    }
}

function getFileTemplate(): string {
    return `// AIGo Program
// Generated by AIGo VS Code Extension

func main() {
    println("Hello, AIGo!");
}

// Example function
func greet(name: string) -> string {
    return "Hello, " + name + "!";
}

// Example with error handling
func safe_divide(a: int, b: int) -> Result<int, string> {
    if (b == 0) {
        return Err("Division by zero");
    }
    return Ok(a / b);
}

// Call main function
main();
`;
}

