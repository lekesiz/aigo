import { useState } from 'react'
import { Textarea } from '@/components/ui/textarea.jsx'

const CodeEditor = ({ value, onChange, language = 'aigo' }) => {
  const [lineNumbers, setLineNumbers] = useState([])

  const updateLineNumbers = (text) => {
    const lines = text.split('\n').length
    setLineNumbers(Array.from({ length: lines }, (_, i) => i + 1))
  }

  const handleChange = (e) => {
    const newValue = e.target.value
    onChange(newValue)
    updateLineNumbers(newValue)
  }

  // Initialize line numbers
  useState(() => {
    updateLineNumbers(value)
  }, [value])

  const highlightSyntax = (code) => {
    // Simple syntax highlighting for AIGo
    const keywords = ['func', 'let', 'const', 'if', 'else', 'for', 'while', 'return', 'try', 'catch', 'finally', 'throw', 'true', 'false', 'null']
    const types = ['int', 'float', 'string', 'bool', 'Array', 'Map']
    
    let highlighted = code
    
    // Highlight keywords
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'g')
      highlighted = highlighted.replace(regex, `<span class="text-blue-600 font-semibold">${keyword}</span>`)
    })
    
    // Highlight types
    types.forEach(type => {
      const regex = new RegExp(`\\b${type}\\b`, 'g')
      highlighted = highlighted.replace(regex, `<span class="text-purple-600 font-semibold">${type}</span>`)
    })
    
    // Highlight strings
    highlighted = highlighted.replace(/"([^"]*)"/g, '<span class="text-green-600">"$1"</span>')
    highlighted = highlighted.replace(/'([^']*)'/g, '<span class="text-green-600">\'$1\'</span>')
    
    // Highlight comments
    highlighted = highlighted.replace(/\/\/.*$/gm, '<span class="text-gray-500 italic">$&</span>')
    highlighted = highlighted.replace(/\/\*[\s\S]*?\*\//g, '<span class="text-gray-500 italic">$&</span>')
    
    // Highlight numbers
    highlighted = highlighted.replace(/\b\d+\.?\d*\b/g, '<span class="text-orange-600">$&</span>')
    
    return highlighted
  }

  return (
    <div className="relative border rounded-lg overflow-hidden bg-white">
      {/* Line numbers */}
      <div className="flex">
        <div className="bg-gray-50 px-3 py-2 text-sm text-gray-500 font-mono select-none border-r">
          {lineNumbers.map(num => (
            <div key={num} className="leading-6">
              {num}
            </div>
          ))}
        </div>
        
        {/* Code area */}
        <div className="flex-1 relative">
          {/* Syntax highlighted overlay */}
          <div 
            className="absolute inset-0 p-3 font-mono text-sm leading-6 pointer-events-none whitespace-pre-wrap break-words"
            dangerouslySetInnerHTML={{ __html: highlightSyntax(value) }}
          />
          
          {/* Actual textarea */}
          <Textarea
            value={value}
            onChange={handleChange}
            className="w-full h-[400px] p-3 font-mono text-sm leading-6 resize-none border-0 bg-transparent text-transparent caret-black focus:ring-0 focus:outline-none"
            placeholder="Write your AIGo code here..."
            spellCheck={false}
          />
        </div>
      </div>
    </div>
  )
}

export default CodeEditor

