# Contributing to AIGo

Thank you for your interest in contributing to AIGo! We welcome contributions from developers of all skill levels.

## 🌟 Ways to Contribute

### 🐛 Bug Reports
- Use the [GitHub Issues](https://github.com/aigo-dev/aigo/issues) page
- Search existing issues before creating a new one
- Include detailed reproduction steps
- Provide system information and AIGo version

### 💡 Feature Requests
- Discuss new features in [GitHub Discussions](https://github.com/aigo-dev/aigo/discussions)
- Explain the use case and benefits
- Consider implementation complexity
- Be open to feedback and iteration

### 📝 Documentation
- Fix typos and improve clarity
- Add examples and tutorials
- Translate documentation
- Update outdated information

### 🔧 Code Contributions
- Bug fixes and improvements
- New language features
- Standard library additions
- Tool and IDE enhancements

## 🚀 Getting Started

### Development Environment Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/aigo-dev/aigo.git
   cd aigo
   ```

2. **Install dependencies**
   ```bash
   # Install Rust (for compiler development)
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   
   # Install Node.js (for web tools)
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Install Python (for tooling)
   sudo apt-get install python3 python3-pip
   ```

3. **Build the project**
   ```bash
   # Build the compiler
   cd compiler && cargo build --release
   
   # Build web platforms
   cd ../web-platforms/playground && npm install && npm run build
   ```

4. **Run tests**
   ```bash
   # Run compiler tests
   cd compiler && cargo test
   
   # Run integration tests
   cd ../tests && python3 run_tests.py
   ```

## 📋 Development Guidelines

### Code Style

#### AIGo Code
- Use 4 spaces for indentation
- Follow naming conventions:
  - Functions: `snake_case`
  - Types: `PascalCase`
  - Variables: `snake_case`
  - Constants: `SCREAMING_SNAKE_CASE`
- Maximum line length: 100 characters
- Add documentation for public APIs

#### Rust Code (Compiler)
- Follow standard Rust formatting (`cargo fmt`)
- Use `clippy` for linting (`cargo clippy`)
- Write comprehensive tests
- Document public APIs with `///` comments

#### JavaScript/TypeScript (Web Tools)
- Use Prettier for formatting
- Follow ESLint rules
- Use TypeScript for type safety
- Write unit tests with Jest

### Commit Messages
Follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```
<type>[optional scope]: <description>

[optional body]

[optional footer(s)]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

Examples:
```
feat(compiler): add pattern matching for enums
fix(parser): handle nested function calls correctly
docs(readme): update installation instructions
```

### Pull Request Process

1. **Fork and Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make Changes**
   - Write clean, well-documented code
   - Add tests for new functionality
   - Update documentation as needed

3. **Test Your Changes**
   ```bash
   # Run all tests
   make test
   
   # Run specific test suites
   make test-compiler
   make test-web
   ```

4. **Commit and Push**
   ```bash
   git add .
   git commit -m "feat: add your feature description"
   git push origin feature/your-feature-name
   ```

5. **Create Pull Request**
   - Use the PR template
   - Link related issues
   - Provide clear description
   - Request review from maintainers

### Code Review Guidelines

#### For Contributors
- Be responsive to feedback
- Make requested changes promptly
- Ask questions if feedback is unclear
- Keep PRs focused and reasonably sized

#### For Reviewers
- Be constructive and respectful
- Explain reasoning behind suggestions
- Approve when ready, request changes when needed
- Focus on code quality, correctness, and maintainability

## 🏗️ Project Structure

```
aigo/
├── compiler/           # Rust-based AIGo compiler
│   ├── src/
│   │   ├── lexer/     # Tokenization
│   │   ├── parser/    # AST generation
│   │   ├── analyzer/  # Semantic analysis
│   │   ├── codegen/   # Code generation
│   │   └── main.rs    # Compiler entry point
│   ├── tests/         # Compiler tests
│   └── Cargo.toml     # Rust dependencies
├── runtime/           # Runtime system and standard library
├── tools/             # Development tools
├── examples/          # Example programs
├── docs/              # Documentation source
├── tests/             # Integration tests
├── benchmarks/        # Performance benchmarks
├── ide-plugins/       # IDE extensions
├── web-platforms/     # Web-based tools
└── deployment/        # Deployment configurations
```

## 🧪 Testing

### Test Categories

1. **Unit Tests**: Test individual components
2. **Integration Tests**: Test component interactions
3. **End-to-End Tests**: Test complete workflows
4. **Performance Tests**: Benchmark performance
5. **Compatibility Tests**: Test across platforms

### Running Tests

```bash
# All tests
make test

# Specific test suites
make test-compiler      # Compiler tests
make test-runtime       # Runtime tests
make test-tools         # Tool tests
make test-web          # Web platform tests
make test-integration  # Integration tests
make test-performance  # Performance benchmarks
```

### Writing Tests

#### Compiler Tests (Rust)
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_lexer_tokenizes_keywords() {
        let input = "func main() {}";
        let tokens = tokenize(input);
        assert_eq!(tokens[0].kind, TokenKind::Func);
    }
}
```

#### Web Platform Tests (JavaScript)
```javascript
describe('AIGo Playground', () => {
  test('should execute simple program', async () => {
    const code = 'println("Hello, World!");';
    const result = await executeCode(code);
    expect(result.output).toBe('Hello, World!\n');
  });
});
```

## 📚 Documentation

### Types of Documentation

1. **API Documentation**: Generated from code comments
2. **User Guides**: Step-by-step tutorials
3. **Reference Manual**: Comprehensive language reference
4. **Developer Docs**: Internal architecture and design

### Writing Documentation

- Use clear, concise language
- Include practical examples
- Keep documentation up-to-date with code changes
- Use proper markdown formatting
- Add diagrams and illustrations when helpful

## 🏷️ Release Process

### Version Numbering
We follow [Semantic Versioning](https://semver.org/):
- `MAJOR.MINOR.PATCH`
- Major: Breaking changes
- Minor: New features (backward compatible)
- Patch: Bug fixes (backward compatible)

### Release Checklist
- [ ] Update version numbers
- [ ] Update CHANGELOG.md
- [ ] Run full test suite
- [ ] Update documentation
- [ ] Create release notes
- [ ] Tag release in Git
- [ ] Deploy to package registries
- [ ] Announce release

## 🤝 Community Guidelines

### Code of Conduct
We are committed to providing a welcoming and inclusive environment. Please read our [Code of Conduct](CODE_OF_CONDUCT.md).

### Communication Channels
- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: General discussions and questions
- **Discord**: Real-time chat and community support
- **Twitter**: Announcements and updates

### Getting Help
- Check existing documentation
- Search GitHub issues
- Ask in GitHub Discussions
- Join our Discord community
- Contact maintainers directly for sensitive issues

## 🎯 Contribution Areas

### High Priority
- Performance optimizations
- Bug fixes and stability improvements
- Documentation improvements
- Test coverage expansion

### Medium Priority
- New language features
- Standard library additions
- Tool enhancements
- Platform support

### Low Priority
- Code refactoring
- Style improvements
- Minor feature additions

## 🏆 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Annual contributor highlights
- Special badges and mentions

## 📞 Contact

For questions about contributing:
- **Email**: contributors@aigo.dev
- **Discord**: [Join our server](https://discord.gg/aigo)
- **GitHub**: [@aigo-dev](https://github.com/aigo-dev)

Thank you for helping make AIGo better! 🚀

