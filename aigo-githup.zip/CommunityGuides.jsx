import { Routes, Route } from 'react-router-dom'

const CommunityGuides = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center py-16">
        <h1 className="text-4xl font-bold mb-4">Community Guides</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Contributing guidelines, best practices, and community resources
        </p>
        <div className="text-muted-foreground">
          Community guides coming soon...
        </div>
      </div>
    </div>
  )
}

export default CommunityGuides

