import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Target, 
  Trophy, 
  BookOpen, 
  Star, 
  TrendingUp, 
  Calendar,
  Award,
  Zap,
  CheckCircle,
  Clock
} from 'lucide-react'

const ProgressTracker = ({ userProgress }) => {
  const achievements = [
    {
      id: 1,
      title: "First Steps",
      description: "Complete your first tutorial",
      icon: <BookOpen className="h-6 w-6" />,
      earned: true,
      points: 50
    },
    {
      id: 2,
      title: "Problem Solver",
      description: "Solve 5 coding challenges",
      icon: <Trophy className="h-6 w-6" />,
      earned: true,
      points: 200
    },
    {
      id: 3,
      title: "Streak Master",
      description: "Maintain a 7-day learning streak",
      icon: <Zap className="h-6 w-6" />,
      earned: true,
      points: 150
    },
    {
      id: 4,
      title: "Code Warrior",
      description: "Complete 10 challenges",
      icon: <Award className="h-6 w-6" />,
      earned: false,
      points: 300
    },
    {
      id: 5,
      title: "AIGo Expert",
      description: "Complete all tutorials",
      icon: <Star className="h-6 w-6" />,
      earned: false,
      points: 500
    }
  ]

  const weeklyActivity = [
    { day: 'Mon', lessons: 2, challenges: 1 },
    { day: 'Tue', lessons: 1, challenges: 2 },
    { day: 'Wed', lessons: 3, challenges: 0 },
    { day: 'Thu', lessons: 1, challenges: 1 },
    { day: 'Fri', lessons: 2, challenges: 2 },
    { day: 'Sat', lessons: 1, challenges: 1 },
    { day: 'Sun', lessons: 0, challenges: 1 }
  ]

  const skillLevels = [
    { skill: 'Syntax & Basics', level: 85, maxLevel: 100 },
    { skill: 'Functions & Control Flow', level: 70, maxLevel: 100 },
    { skill: 'Error Handling', level: 45, maxLevel: 100 },
    { skill: 'Data Structures', level: 30, maxLevel: 100 },
    { skill: 'Advanced Features', level: 15, maxLevel: 100 }
  ]

  const getSkillColor = (level) => {
    if (level >= 80) return 'bg-green-500'
    if (level >= 60) return 'bg-blue-500'
    if (level >= 40) return 'bg-yellow-500'
    return 'bg-gray-400'
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold">Your Learning Progress</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Track your AIGo learning journey, achievements, and skill development.
        </p>
      </div>

      {/* Overall Progress */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <BookOpen className="h-6 w-6" />
            </div>
            <div className="text-2xl font-bold">{userProgress.completedLessons}/{userProgress.totalLessons}</div>
            <div className="text-sm text-muted-foreground">Lessons Completed</div>
            <Progress 
              value={(userProgress.completedLessons / userProgress.totalLessons) * 100} 
              className="mt-2" 
            />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Trophy className="h-6 w-6" />
            </div>
            <div className="text-2xl font-bold">{userProgress.completedChallenges}/{userProgress.totalChallenges}</div>
            <div className="text-sm text-muted-foreground">Challenges Solved</div>
            <Progress 
              value={(userProgress.completedChallenges / userProgress.totalChallenges) * 100} 
              className="mt-2" 
            />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Star className="h-6 w-6" />
            </div>
            <div className="text-2xl font-bold">{userProgress.totalPoints}</div>
            <div className="text-sm text-muted-foreground">Total Points</div>
            <Badge className="mt-2 bg-purple-100 text-purple-800">
              Level {Math.floor(userProgress.totalPoints / 500) + 1}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Zap className="h-6 w-6" />
            </div>
            <div className="text-2xl font-bold">{userProgress.currentStreak}</div>
            <div className="text-sm text-muted-foreground">Day Streak</div>
            <div className="text-xs text-muted-foreground mt-1">Keep it up!</div>
          </CardContent>
        </Card>
      </div>

      {/* Skill Levels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5" />
            <span>Skill Levels</span>
          </CardTitle>
          <CardDescription>
            Your proficiency in different AIGo concepts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {skillLevels.map((skill, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{skill.skill}</span>
                  <span className="text-sm text-muted-foreground">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${getSkillColor(skill.level)}`}
                    style={{ width: `${skill.level}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Weekly Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Weekly Activity</span>
          </CardTitle>
          <CardDescription>
            Your learning activity over the past week
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-4">
            {weeklyActivity.map((day, index) => (
              <div key={index} className="text-center space-y-2">
                <div className="text-sm font-medium">{day.day}</div>
                <div className="space-y-1">
                  <div className="w-full bg-blue-100 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full"
                      style={{ width: `${Math.min(day.lessons * 33, 100)}%` }}
                    />
                  </div>
                  <div className="w-full bg-green-100 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full"
                      style={{ width: `${Math.min(day.challenges * 50, 100)}%` }}
                    />
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {day.lessons}L {day.challenges}C
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center space-x-6 mt-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full" />
              <span>Lessons</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span>Challenges</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Award className="h-5 w-5" />
            <span>Achievements</span>
          </CardTitle>
          <CardDescription>
            Unlock badges as you progress through your AIGo journey
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement) => (
              <Card 
                key={achievement.id} 
                className={`${achievement.earned ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200' : 'bg-gray-50'}`}
              >
                <CardContent className="p-4 text-center">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3 ${
                    achievement.earned 
                      ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-white' 
                      : 'bg-gray-200 text-gray-400'
                  }`}>
                    {achievement.icon}
                  </div>
                  <h4 className="font-semibold mb-1">{achievement.title}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{achievement.description}</p>
                  <div className="flex items-center justify-center space-x-2">
                    {achievement.earned ? (
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Earned
                      </Badge>
                    ) : (
                      <Badge variant="outline">
                        <Clock className="h-3 w-3 mr-1" />
                        Locked
                      </Badge>
                    )}
                    <Badge variant="secondary">
                      {achievement.points} pts
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Next Goals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Next Goals</span>
          </CardTitle>
          <CardDescription>
            Recommended next steps to continue your learning journey
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
              <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm font-semibold">
                1
              </div>
              <div>
                <h4 className="font-semibold">Complete Error Handling Tutorial</h4>
                <p className="text-sm text-muted-foreground">Learn how to handle errors gracefully in AIGo</p>
                <Badge className="mt-2 bg-blue-100 text-blue-800">+200 points</Badge>
              </div>
            </div>
            
            <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-lg">
              <div className="w-8 h-8 bg-green-100 text-green-600 rounded-lg flex items-center justify-center text-sm font-semibold">
                2
              </div>
              <div>
                <h4 className="font-semibold">Solve Binary Search Challenge</h4>
                <p className="text-sm text-muted-foreground">Practice algorithm implementation skills</p>
                <Badge className="mt-2 bg-green-100 text-green-800">+250 points</Badge>
              </div>
            </div>
            
            <div className="flex items-start space-x-3 p-4 bg-purple-50 rounded-lg">
              <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center text-sm font-semibold">
                3
              </div>
              <div>
                <h4 className="font-semibold">Maintain 10-Day Streak</h4>
                <p className="text-sm text-muted-foreground">Keep up your daily learning habit</p>
                <Badge className="mt-2 bg-purple-100 text-purple-800">+300 points</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default ProgressTracker

