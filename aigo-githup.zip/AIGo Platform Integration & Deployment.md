# AIGo Platform Integration & Deployment

## Docker Configuration

### Learning Platform Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY aigo-learning-platform/package*.json ./
RUN npm install
COPY aigo-learning-platform/ .
RUN npm run build
EXPOSE 5174
CMD ["npm", "run", "preview", "--", "--host", "0.0.0.0"]

### Documentation Portal Dockerfile  
FROM node:20-alpine
WORKDIR /app
COPY aigo-documentation-portal/package*.json ./
RUN npm install
COPY aigo-documentation-portal/ .
RUN npm run build
EXPOSE 5175
CMD ["npm", "run", "preview", "--", "--host", "0.0.0.0"]

### Community Platform Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY aigo-community-platform/package*.json ./
RUN npm install
COPY aigo-community-platform/ .
RUN npm run build
EXPOSE 5176
CMD ["npm", "run", "preview", "--", "--host", "0.0.0.0"]

### Debugging Tools Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY aigo-debugging-tools/package*.json ./
RUN npm install
COPY aigo-debugging-tools/ .
RUN npm run build
EXPOSE 5177
CMD ["npm", "run", "preview", "--", "--host", "0.0.0.0"]

### Package Manager Backend Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY aigo-package-manager/requirements.txt .
RUN pip install -r requirements.txt
COPY aigo-package-manager/ .
EXPOSE 5000
CMD ["python", "src/main.py"]

