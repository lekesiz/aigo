import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  BookOpen, 
  Play, 
  CheckCircle, 
  Clock, 
  ChevronRight,
  Code,
  Lightbulb,
  Target,
  Zap
} from 'lucide-react'

const TutorialSection = ({ userProgress }) => {
  const [selectedTutorial, setSelectedTutorial] = useState(null)

  const tutorials = [
    {
      id: 1,
      title: "Getting Started with AIGo",
      description: "Learn the basics of AIGo syntax and your first program",
      difficulty: "Beginner",
      duration: "15 min",
      completed: true,
      lessons: [
        { title: "What is AIGo?", completed: true },
        { title: "Your First Program", completed: true },
        { title: "Variables and Types", completed: true }
      ],
      code: `// Welcome to AIGo!
// This is your first program

func main() {
    println("Hello, AIGo World!");
    
    // Variables in AIGo
    let name = "Alice";
    let age = 25;
    let isStudent = true;
    
    println("Name: " + name);
    println("Age: " + age);
    println("Is student: " + isStudent);
}

main();`
    },
    {
      id: 2,
      title: "Functions and Control Flow",
      description: "Master functions, conditionals, and loops in AIGo",
      difficulty: "Beginner",
      duration: "25 min",
      completed: true,
      lessons: [
        { title: "Creating Functions", completed: true },
        { title: "If-Else Statements", completed: true },
        { title: "Loops and Iteration", completed: false }
      ],
      code: `// Functions and Control Flow

func greet(name, age) {
    if (age >= 18) {
        return "Hello, " + name + "! You are an adult.";
    } else {
        return "Hi, " + name + "! You are a minor.";
    }
}

func countToN(n) {
    println("Counting to " + n + ":");
    for (i = 1; i <= n; i++) {
        println(i);
    }
}

func main() {
    let message = greet("Bob", 20);
    println(message);
    
    countToN(5);
}

main();`
    },
    {
      id: 3,
      title: "Error Handling",
      description: "Learn to handle errors gracefully with try-catch",
      difficulty: "Intermediate",
      duration: "20 min",
      completed: false,
      lessons: [
        { title: "Understanding Errors", completed: false },
        { title: "Try-Catch Blocks", completed: false },
        { title: "Custom Error Types", completed: false }
      ],
      code: `// Error Handling in AIGo

func safeDivide(a, b) {
    if (b == 0) {
        throw "Division by zero error!";
    }
    return a / b;
}

func parseNumber(str) {
    // Simulate parsing that might fail
    if (str == "invalid") {
        throw "Invalid number format";
    }
    return 42; // Simplified parsing
}

func main() {
    // Example 1: Division
    try {
        let result = safeDivide(10, 2);
        println("10 / 2 = " + result);
        
        let badResult = safeDivide(10, 0);
        println("This won't print");
    } catch (error) {
        println("Caught error: " + error);
    }
    
    // Example 2: Parsing
    try {
        let num = parseNumber("valid");
        println("Parsed number: " + num);
    } catch (error) {
        println("Parse error: " + error);
    }
}

main();`
    },
    {
      id: 4,
      title: "Data Structures",
      description: "Work with arrays, maps, and custom data structures",
      difficulty: "Intermediate",
      duration: "30 min",
      completed: false,
      lessons: [
        { title: "Arrays and Lists", completed: false },
        { title: "Maps and Dictionaries", completed: false },
        { title: "Structs and Objects", completed: false }
      ],
      code: `// Data Structures in AIGo

struct Person {
    name: string;
    age: int;
    email: string;
}

func main() {
    // Arrays
    let numbers = [1, 2, 3, 4, 5];
    println("Numbers: " + numbers);
    
    // Adding to array
    push(numbers, 6);
    println("After push: " + numbers);
    
    // Maps
    let scores = {
        "Alice": 95,
        "Bob": 87,
        "Charlie": 92
    };
    
    println("Alice's score: " + scores["Alice"]);
    
    // Structs
    let person = Person {
        name: "Alice",
        age: 30,
        email: "alice@example.com"
    };
    
    println("Person: " + person.name + " (" + person.age + ")");
}

main();`
    },
    {
      id: 5,
      title: "Advanced Features",
      description: "Explore advanced AIGo features like async programming",
      difficulty: "Advanced",
      duration: "45 min",
      completed: false,
      lessons: [
        { title: "Async Functions", completed: false },
        { title: "Memory Management", completed: false },
        { title: "Performance Optimization", completed: false }
      ],
      code: `// Advanced AIGo Features

async func fetchData(url) {
    // Simulate async operation
    await sleep(1000);
    return "Data from " + url;
}

func fibonacci(n) {
    if (n <= 1) return n;
    return fibonacci(n-1) + fibonacci(n-2);
}

async func main() {
    println("Starting advanced examples...");
    
    // Async example
    let data = await fetchData("https://api.example.com");
    println("Received: " + data);
    
    // Performance example
    let start = now();
    let result = fibonacci(30);
    let end = now();
    
    println("Fibonacci(30) = " + result);
    println("Computed in " + (end - start) + "ms");
}

main();`
    }
  ]

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800'
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800'
      case 'Advanced': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold">Interactive Tutorials</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Learn AIGo step by step with our comprehensive tutorials. Each tutorial includes theory, examples, and hands-on practice.
        </p>
      </div>

      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Your Learning Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{userProgress.completedLessons}</div>
              <div className="text-sm text-muted-foreground">Lessons Completed</div>
              <Progress value={(userProgress.completedLessons / userProgress.totalLessons) * 100} className="mt-2" />
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{tutorials.filter(t => t.completed).length}</div>
              <div className="text-sm text-muted-foreground">Tutorials Finished</div>
              <Progress value={(tutorials.filter(t => t.completed).length / tutorials.length) * 100} className="mt-2" />
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{userProgress.currentStreak}</div>
              <div className="text-sm text-muted-foreground">Day Learning Streak</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tutorial List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Available Tutorials</h3>
          {tutorials.map((tutorial) => (
            <Card 
              key={tutorial.id} 
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedTutorial?.id === tutorial.id ? 'ring-2 ring-blue-500' : ''
              }`}
              onClick={() => setSelectedTutorial(tutorial)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-lg flex items-center space-x-2">
                      {tutorial.completed ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <BookOpen className="h-5 w-5 text-blue-600" />
                      )}
                      <span>{tutorial.title}</span>
                    </CardTitle>
                    <CardDescription>{tutorial.description}</CardDescription>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className={getDifficultyColor(tutorial.difficulty)}>
                    {tutorial.difficulty}
                  </Badge>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{tutorial.duration}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <div className="text-sm font-medium">Lessons:</div>
                  <div className="space-y-1">
                    {tutorial.lessons.map((lesson, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        {lesson.completed ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <div className="h-4 w-4 rounded-full border-2 border-gray-300" />
                        )}
                        <span className={lesson.completed ? 'text-green-600' : 'text-muted-foreground'}>
                          {lesson.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tutorial Content */}
        <div className="space-y-4">
          {selectedTutorial ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Code className="h-5 w-5" />
                    <span>{selectedTutorial.title}</span>
                  </CardTitle>
                  <CardDescription>
                    Practice the concepts with this interactive example
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                    <pre>{selectedTutorial.code}</pre>
                  </div>
                  <div className="mt-4 flex space-x-2">
                    <Button className="flex items-center space-x-2">
                      <Play className="h-4 w-4" />
                      <span>Run Example</span>
                    </Button>
                    <Button variant="outline" className="flex items-center space-x-2">
                      <Code className="h-4 w-4" />
                      <span>Edit in Playground</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lightbulb className="h-5 w-5" />
                    <span>Key Concepts</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selectedTutorial.lessons.map((lesson, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">
                          {index + 1}
                        </div>
                        <div>
                          <div className="font-medium">{lesson.title}</div>
                          <div className="text-sm text-muted-foreground mt-1">
                            Learn about {lesson.title.toLowerCase()} and how to use it effectively in AIGo.
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Select a Tutorial</h3>
                <p className="text-muted-foreground">
                  Choose a tutorial from the list to see the content and start learning.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

export default TutorialSection

