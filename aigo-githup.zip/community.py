from flask import Blueprint, request, jsonify
from src.models.user import db, User
from datetime import datetime
import hashlib

community_bp = Blueprint('community', __name__)

class CommunityPost(db.Model):
    __tablename__ = 'community_posts'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category = db.Column(db.String(50), nullable=False)  # discussion, question, showcase, tutorial
    tags = db.Column(db.Text, nullable=True)  # JSON string
    upvotes = db.Column(db.Integer, default=0)
    downvotes = db.Column(db.Integer, default=0)
    views = db.Column(db.Integer, default=0)
    is_pinned = db.Column(db.Boolean, default=False)
    is_solved = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    author = db.relationship('User', backref=db.backref('posts', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'author_id': self.author_id,
            'author_name': self.author.username if self.author else 'Unknown',
            'category': self.category,
            'tags': self.tags,
            'upvotes': self.upvotes,
            'downvotes': self.downvotes,
            'views': self.views,
            'is_pinned': self.is_pinned,
            'is_solved': self.is_solved,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CommunityComment(db.Model):
    __tablename__ = 'community_comments'
    
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('community_posts.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey('community_comments.id'), nullable=True)
    upvotes = db.Column(db.Integer, default=0)
    downvotes = db.Column(db.Integer, default=0)
    is_solution = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    post = db.relationship('CommunityPost', backref=db.backref('comments', lazy=True))
    author = db.relationship('User', backref=db.backref('comments', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'post_id': self.post_id,
            'author_id': self.author_id,
            'author_name': self.author.username if self.author else 'Unknown',
            'content': self.content,
            'parent_id': self.parent_id,
            'upvotes': self.upvotes,
            'downvotes': self.downvotes,
            'is_solution': self.is_solution,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

@community_bp.route('/posts', methods=['GET'])
def list_posts():
    """List community posts with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        category = request.args.get('category', '')
        search = request.args.get('search', '')
        sort_by = request.args.get('sort_by', 'created_at')  # created_at, upvotes, views
        
        query = CommunityPost.query
        
        # Apply category filter
        if category:
            query = query.filter(CommunityPost.category == category)
        
        # Apply search filter
        if search:
            query = query.filter(
                db.or_(
                    CommunityPost.title.contains(search),
                    CommunityPost.content.contains(search),
                    CommunityPost.tags.contains(search)
                )
            )
        
        # Apply sorting
        if sort_by == 'upvotes':
            query = query.order_by(CommunityPost.upvotes.desc())
        elif sort_by == 'views':
            query = query.order_by(CommunityPost.views.desc())
        else:
            query = query.order_by(CommunityPost.created_at.desc())
        
        # Pinned posts first
        query = query.order_by(CommunityPost.is_pinned.desc(), query.order_by)
        
        # Paginate results
        posts = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'posts': [post.to_dict() for post in posts.items],
            'total': posts.total,
            'pages': posts.pages,
            'current_page': page,
            'per_page': per_page
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@community_bp.route('/posts', methods=['POST'])
def create_post():
    """Create a new community post"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'content', 'author_id', 'category']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate category
        valid_categories = ['discussion', 'question', 'showcase', 'tutorial']
        if data['category'] not in valid_categories:
            return jsonify({'error': f'Invalid category. Must be one of: {valid_categories}'}), 400
        
        # Create new post
        post = CommunityPost(
            title=data['title'],
            content=data['content'],
            author_id=data['author_id'],
            category=data['category'],
            tags=data.get('tags', '[]')
        )
        
        db.session.add(post)
        db.session.commit()
        
        return jsonify(post.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@community_bp.route('/posts/<int:post_id>', methods=['GET'])
def get_post(post_id):
    """Get a specific post with comments"""
    try:
        post = CommunityPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post not found'}), 404
        
        # Increment view count
        post.views += 1
        db.session.commit()
        
        # Get comments
        comments = CommunityComment.query.filter_by(post_id=post_id).order_by(CommunityComment.created_at.asc()).all()
        
        post_data = post.to_dict()
        post_data['comments'] = [comment.to_dict() for comment in comments]
        
        return jsonify(post_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@community_bp.route('/posts/<int:post_id>/comments', methods=['POST'])
def add_comment(post_id):
    """Add a comment to a post"""
    try:
        post = CommunityPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['content', 'author_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create new comment
        comment = CommunityComment(
            post_id=post_id,
            author_id=data['author_id'],
            content=data['content'],
            parent_id=data.get('parent_id')
        )
        
        db.session.add(comment)
        db.session.commit()
        
        return jsonify(comment.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@community_bp.route('/posts/<int:post_id>/vote', methods=['POST'])
def vote_post(post_id):
    """Vote on a post"""
    try:
        post = CommunityPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Post not found'}), 404
        
        data = request.get_json()
        vote_type = data.get('type')  # 'up' or 'down'
        
        if vote_type == 'up':
            post.upvotes += 1
        elif vote_type == 'down':
            post.downvotes += 1
        else:
            return jsonify({'error': 'Invalid vote type. Must be "up" or "down"'}), 400
        
        db.session.commit()
        
        return jsonify({
            'message': f'Vote recorded',
            'upvotes': post.upvotes,
            'downvotes': post.downvotes
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@community_bp.route('/comments/<int:comment_id>/vote', methods=['POST'])
def vote_comment(comment_id):
    """Vote on a comment"""
    try:
        comment = CommunityComment.query.get(comment_id)
        if not comment:
            return jsonify({'error': 'Comment not found'}), 404
        
        data = request.get_json()
        vote_type = data.get('type')  # 'up' or 'down'
        
        if vote_type == 'up':
            comment.upvotes += 1
        elif vote_type == 'down':
            comment.downvotes += 1
        else:
            return jsonify({'error': 'Invalid vote type. Must be "up" or "down"'}), 400
        
        db.session.commit()
        
        return jsonify({
            'message': f'Vote recorded',
            'upvotes': comment.upvotes,
            'downvotes': comment.downvotes
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@community_bp.route('/stats', methods=['GET'])
def get_community_stats():
    """Get community statistics"""
    try:
        total_posts = CommunityPost.query.count()
        total_comments = CommunityComment.query.count()
        total_users = User.query.count()
        
        # Category breakdown
        categories = db.session.query(
            CommunityPost.category,
            db.func.count(CommunityPost.id).label('count')
        ).group_by(CommunityPost.category).all()
        
        category_stats = {cat: count for cat, count in categories}
        
        return jsonify({
            'total_posts': total_posts,
            'total_comments': total_comments,
            'total_users': total_users,
            'categories': category_stats
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

