import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card.jsx'
import { Button } from './ui/button.jsx'
import { Badge } from './ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.jsx'
import { Progress } from './ui/progress.jsx'
import { 
  MemoryStick, 
  Database, 
  Trash2,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Search,
  Filter,
  Download,
  Eye,
  Layers,
  Package,
  Zap,
  Clock,
  BarChart3
} from 'lucide-react'
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, BarChart, Bar, TreeMap, Cell } from 'recharts'

const MemoryAnalyzer = ({ isConnected }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [selectedObject, setSelectedObject] = useState(null)
  const [memorySnapshot, setMemorySnapshot] = useState(null)

  // Mock memory data
  const [heapData, setHeapData] = useState([])
  const [gcData, setGcData] = useState([])
  const [leakData, setLeakData] = useState([])

  useEffect(() => {
    // Generate mock memory data
    const generateData = () => {
      const now = Date.now()
      const heap = []
      const gc = []
      const leaks = []

      for (let i = 0; i < 60; i++) {
        const timestamp = now - (59 - i) * 1000
        heap.push({
          time: new Date(timestamp).toLocaleTimeString(),
          used: Math.random() * 200 + 100,
          allocated: Math.random() * 300 + 200,
          free: Math.random() * 100 + 50
        })

        if (i % 10 === 0) {
          gc.push({
            time: new Date(timestamp).toLocaleTimeString(),
            duration: Math.random() * 50 + 10,
            collected: Math.random() * 30 + 5,
            generation: Math.floor(Math.random() * 3)
          })
        }

        if (Math.random() > 0.8) {
          leaks.push({
            time: new Date(timestamp).toLocaleTimeString(),
            size: Math.random() * 10 + 1,
            type: ['String', 'Array', 'Object', 'Function'][Math.floor(Math.random() * 4)]
          })
        }
      }

      setHeapData(heap)
      setGcData(gc)
      setLeakData(leaks)
    }

    generateData()
    const interval = setInterval(generateData, 3000)
    return () => clearInterval(interval)
  }, [])

  const memoryStats = {
    totalHeap: 512.8,
    usedHeap: 245.6,
    freeHeap: 267.2,
    gcCount: 156,
    gcTime: 234.5,
    leakCount: 3
  }

  const objectTypes = [
    { type: 'String', count: 15420, size: 45.6, percentage: 18.5 },
    { type: 'Array', count: 8934, size: 67.2, percentage: 27.3 },
    { type: 'Object', count: 12456, size: 89.4, percentage: 36.4 },
    { type: 'Function', count: 2341, size: 23.1, percentage: 9.4 },
    { type: 'Number', count: 5678, size: 12.3, percentage: 5.0 },
    { type: 'Boolean', count: 3456, size: 8.4, percentage: 3.4 }
  ]

  const memoryLeaks = [
    {
      id: 1,
      type: 'Array',
      size: 15.6,
      location: 'fibonacci.aigo:line 12',
      severity: 'high',
      description: 'Growing array not being cleaned up in loop',
      firstSeen: '2 hours ago',
      lastSeen: '30 seconds ago'
    },
    {
      id: 2,
      type: 'String',
      size: 8.2,
      location: 'main.aigo:line 25',
      severity: 'medium',
      description: 'String concatenation creating unreferenced objects',
      firstSeen: '45 minutes ago',
      lastSeen: '1 minute ago'
    },
    {
      id: 3,
      type: 'Object',
      size: 3.4,
      location: 'utils.aigo:line 8',
      severity: 'low',
      description: 'Temporary objects not being garbage collected',
      firstSeen: '15 minutes ago',
      lastSeen: '5 minutes ago'
    }
  ]

  const heapSnapshot = [
    { name: 'Strings', size: 45600, children: [
      { name: 'Short strings (<50 chars)', size: 23400 },
      { name: 'Medium strings (50-200 chars)', size: 15600 },
      { name: 'Long strings (>200 chars)', size: 6600 }
    ]},
    { name: 'Arrays', size: 67200, children: [
      { name: 'Number arrays', size: 34500 },
      { name: 'String arrays', size: 21300 },
      { name: 'Object arrays', size: 11400 }
    ]},
    { name: 'Objects', size: 89400, children: [
      { name: 'User objects', size: 56700 },
      { name: 'System objects', size: 32700 }
    ]},
    { name: 'Functions', size: 23100, children: [
      { name: 'User functions', size: 18900 },
      { name: 'Built-in functions', size: 4200 }
    ]}
  ]

  const handleTakeSnapshot = () => {
    setIsAnalyzing(true)
    setTimeout(() => {
      setMemorySnapshot({
        timestamp: new Date().toLocaleString(),
        totalSize: memoryStats.usedHeap,
        objectCount: objectTypes.reduce((sum, obj) => sum + obj.count, 0)
      })
      setIsAnalyzing(false)
    }, 2000)
  }

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200'
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200'
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200'
      default: return 'text-gray-600 bg-gray-50 border-gray-200'
    }
  }

  return (
    <div className="space-y-6">
      <Routes>
        <Route path="/" element={
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold">Memory Analyzer</h1>
                <p className="text-muted-foreground">
                  Advanced memory analysis with heap inspection and leak detection
                </p>
              </div>
              
              {/* Analysis Controls */}
              <div className="flex items-center space-x-4">
                <Button 
                  onClick={handleTakeSnapshot}
                  disabled={!isConnected || isAnalyzing}
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Database className="h-4 w-4 mr-2" />
                      Take Snapshot
                    </>
                  )}
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export Report
                </Button>
              </div>
            </div>

            {/* Connection Status */}
            {!isConnected && (
              <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5 text-orange-600" />
                    <span className="text-orange-800 dark:text-orange-200">
                      Not connected to application. Connect to start memory analysis.
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Memory Overview */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <MemoryStick className="h-5 w-5 text-blue-600" />
                    <div>
                      <div className="text-2xl font-bold">{memoryStats.totalHeap}MB</div>
                      <div className="text-xs text-muted-foreground">Total Heap</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Database className="h-5 w-5 text-green-600" />
                    <div>
                      <div className="text-2xl font-bold">{memoryStats.usedHeap}MB</div>
                      <div className="text-xs text-muted-foreground">Used Heap</div>
                    </div>
                  </div>
                  <Progress value={(memoryStats.usedHeap / memoryStats.totalHeap) * 100} className="mt-2 h-1" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Package className="h-5 w-5 text-purple-600" />
                    <div>
                      <div className="text-2xl font-bold">{memoryStats.freeHeap}MB</div>
                      <div className="text-xs text-muted-foreground">Free Heap</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Trash2 className="h-5 w-5 text-orange-600" />
                    <div>
                      <div className="text-2xl font-bold">{memoryStats.gcCount}</div>
                      <div className="text-xs text-muted-foreground">GC Runs</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5 text-yellow-600" />
                    <div>
                      <div className="text-2xl font-bold">{memoryStats.gcTime}ms</div>
                      <div className="text-xs text-muted-foreground">GC Time</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    <div>
                      <div className="text-2xl font-bold">{memoryStats.leakCount}</div>
                      <div className="text-xs text-muted-foreground">Leaks Found</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Memory Analysis Tabs */}
            <Tabs defaultValue="heap" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="heap">Heap Analysis</TabsTrigger>
                <TabsTrigger value="objects">Object Types</TabsTrigger>
                <TabsTrigger value="leaks">Memory Leaks</TabsTrigger>
                <TabsTrigger value="gc">Garbage Collection</TabsTrigger>
              </TabsList>

              <TabsContent value="heap" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Heap Usage Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Heap Usage Over Time</CardTitle>
                      <CardDescription>Memory allocation and usage patterns</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={heapData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area type="monotone" dataKey="allocated" stackId="1" stroke="#8884d8" fill="#8884d8" name="Allocated MB" />
                          <Area type="monotone" dataKey="used" stackId="2" stroke="#82ca9d" fill="#82ca9d" name="Used MB" />
                          <Area type="monotone" dataKey="free" stackId="3" stroke="#ffc658" fill="#ffc658" name="Free MB" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  {/* Memory Snapshot */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Latest Snapshot</CardTitle>
                      <CardDescription>
                        {memorySnapshot ? `Taken at ${memorySnapshot.timestamp}` : 'No snapshot available'}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {memorySnapshot ? (
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <div className="text-2xl font-bold">{memorySnapshot.totalSize}MB</div>
                              <div className="text-sm text-muted-foreground">Total Size</div>
                            </div>
                            <div>
                              <div className="text-2xl font-bold">{memorySnapshot.objectCount.toLocaleString()}</div>
                              <div className="text-sm text-muted-foreground">Objects</div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            {heapSnapshot.map((item, index) => (
                              <div key={index} className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="font-medium">{item.name}</span>
                                  <span className="text-sm text-muted-foreground">
                                    {(item.size / 1024).toFixed(1)}KB
                                  </span>
                                </div>
                                <Progress value={(item.size / 100000) * 100} className="h-1" />
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <Database className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                          <p className="text-muted-foreground">Take a snapshot to analyze memory usage</p>
                          <Button className="mt-4" onClick={handleTakeSnapshot} disabled={!isConnected}>
                            Take Snapshot
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="objects" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Object Type Distribution</CardTitle>
                    <CardDescription>Memory usage breakdown by object type</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {objectTypes.map((obj, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{obj.type}</span>
                              <Badge variant="outline">{obj.count.toLocaleString()} objects</Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {obj.size}MB • {obj.percentage}%
                            </div>
                          </div>
                          <Progress value={obj.percentage} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="leaks" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Memory Leaks Detection</CardTitle>
                    <CardDescription>Potential memory leaks and growing objects</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {memoryLeaks.length === 0 ? (
                      <div className="text-center py-8">
                        <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                        <p className="text-muted-foreground">No memory leaks detected</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {memoryLeaks.map((leak) => (
                          <Card key={leak.id} className={`border ${getSeverityColor(leak.severity)}`}>
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between">
                                <div className="space-y-2">
                                  <div className="flex items-center space-x-2">
                                    <AlertTriangle className="h-5 w-5" />
                                    <span className="font-medium">{leak.type} Leak</span>
                                    <Badge variant={leak.severity === 'high' ? 'destructive' : 
                                                  leak.severity === 'medium' ? 'secondary' : 'outline'}>
                                      {leak.severity}
                                    </Badge>
                                  </div>
                                  <p className="text-sm">{leak.description}</p>
                                  <div className="text-xs text-muted-foreground">
                                    Location: {leak.location} • Size: {leak.size}MB
                                  </div>
                                  <div className="text-xs text-muted-foreground">
                                    First seen: {leak.firstSeen} • Last seen: {leak.lastSeen}
                                  </div>
                                </div>
                                <Button variant="outline" size="sm">
                                  <Eye className="h-4 w-4 mr-2" />
                                  Inspect
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="gc" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Garbage Collection Activity</CardTitle>
                    <CardDescription>GC performance and collection patterns</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={gcData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="duration" fill="#8884d8" name="Duration (ms)" />
                        <Bar dataKey="collected" fill="#82ca9d" name="Collected (MB)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        } />
      </Routes>
    </div>
  )
}

export default MemoryAnalyzer

