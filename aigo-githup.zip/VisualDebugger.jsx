import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card.jsx'
import { Button } from './ui/button.jsx'
import { Badge } from './ui/badge.jsx'
import { Input } from './ui/input.jsx'
import { Textarea } from './ui/textarea.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.jsx'
import { Progress } from './ui/progress.jsx'
import { 
  Play, 
  Pause, 
  Square, 
  StepForward,
  SkipForward,
  Bug,
  Code,
  FileText,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  Terminal,
  Settings,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  ArrowRight,
  ArrowDown,
  Folder,
  File,
  Variable,
  Zap,
  Circle
} from 'lucide-react'

const VisualDebugger = ({ isConnected, debugSession, setDebugSession }) => {
  const [isRunning, setIsRunning] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [currentLine, setCurrentLine] = useState(15)
  const [breakpoints, setBreakpoints] = useState([10, 15, 23, 35])
  const [variables, setVariables] = useState([])
  const [callStack, setCallStack] = useState([])
  const [watchExpressions, setWatchExpressions] = useState([])

  // Mock code for demonstration
  const mockCode = `func fibonacci(n) {
    if (n <= 1) {
        return n;
    }
    
    let a = 0;
    let b = 1;
    let result = 0;
    
    for (let i = 2; i <= n; i++) {
        result = a + b;  // <- Breakpoint here
        a = b;
        b = result;
        
        // Debug: Print intermediate values
        println("Step " + i + ": " + result);
    }
    
    return result;
}

func main() {
    let input = 10;
    let fib_result = fibonacci(input);  // <- Breakpoint here
    
    println("Fibonacci of " + input + " is: " + fib_result);
    
    // Test with different values
    for (let test = 1; test <= 5; test++) {
        let value = fibonacci(test);  // <- Breakpoint here
        println("F(" + test + ") = " + value);
    }
}

main();`

  // Mock debugging data
  useEffect(() => {
    if (isConnected && isPaused) {
      setVariables([
        { name: 'n', value: '10', type: 'int', scope: 'local' },
        { name: 'a', value: '5', type: 'int', scope: 'local' },
        { name: 'b', value: '8', type: 'int', scope: 'local' },
        { name: 'result', value: '13', type: 'int', scope: 'local' },
        { name: 'i', value: '7', type: 'int', scope: 'local' },
        { name: 'input', value: '10', type: 'int', scope: 'global' },
        { name: 'fib_result', value: 'undefined', type: 'undefined', scope: 'global' }
      ])

      setCallStack([
        { function: 'fibonacci', file: 'main.aigo', line: 15, args: ['n=10'] },
        { function: 'main', file: 'main.aigo', line: 25, args: [] },
        { function: '<global>', file: 'main.aigo', line: 35, args: [] }
      ])

      setWatchExpressions([
        { expression: 'n * 2', value: '20', type: 'int' },
        { expression: 'a + b', value: '13', type: 'int' },
        { expression: 'result > 10', value: 'true', type: 'bool' }
      ])
    }
  }, [isConnected, isPaused])

  const handlePlay = () => {
    setIsRunning(true)
    setIsPaused(false)
  }

  const handlePause = () => {
    setIsRunning(false)
    setIsPaused(true)
  }

  const handleStop = () => {
    setIsRunning(false)
    setIsPaused(false)
    setCurrentLine(1)
  }

  const handleStepOver = () => {
    if (isPaused) {
      setCurrentLine(prev => Math.min(prev + 1, 35))
    }
  }

  const handleStepInto = () => {
    if (isPaused) {
      setCurrentLine(prev => Math.min(prev + 1, 35))
    }
  }

  const toggleBreakpoint = (lineNumber) => {
    setBreakpoints(prev => 
      prev.includes(lineNumber) 
        ? prev.filter(bp => bp !== lineNumber)
        : [...prev, lineNumber].sort((a, b) => a - b)
    )
  }

  const renderCodeLine = (line, index) => {
    const lineNumber = index + 1
    const isCurrentLine = lineNumber === currentLine && isPaused
    const hasBreakpoint = breakpoints.includes(lineNumber)

    return (
      <div 
        key={index}
        className={`flex items-center group hover:bg-muted/50 ${
          isCurrentLine ? 'bg-yellow-100 dark:bg-yellow-900/20' : ''
        }`}
      >
        <div 
          className="w-12 text-center text-sm text-muted-foreground cursor-pointer hover:text-foreground flex items-center justify-center"
          onClick={() => toggleBreakpoint(lineNumber)}
        >
          {hasBreakpoint && (
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          )}
          {!hasBreakpoint && (
            <span className="opacity-0 group-hover:opacity-100">{lineNumber}</span>
          )}
          {!hasBreakpoint && !isCurrentLine && (
            <span className="opacity-100 group-hover:opacity-0">{lineNumber}</span>
          )}
        </div>
        {isCurrentLine && (
          <ArrowRight className="w-4 h-4 text-yellow-600 mr-2" />
        )}
        <pre className="flex-1 text-sm font-mono py-1 px-2">
          <code>{line}</code>
        </pre>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Routes>
        <Route path="/" element={
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold">Visual Debugger</h1>
                <p className="text-muted-foreground">
                  Interactive debugging with breakpoints and step-through execution
                </p>
              </div>
              
              {/* Debug Controls */}
              <div className="flex items-center space-x-2">
                <Button 
                  variant={isRunning ? "secondary" : "default"}
                  size="sm"
                  onClick={handlePlay}
                  disabled={!isConnected || isRunning}
                >
                  <Play className="h-4 w-4 mr-2" />
                  Run
                </Button>
                <Button 
                  variant="secondary"
                  size="sm"
                  onClick={handlePause}
                  disabled={!isConnected || !isRunning}
                >
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </Button>
                <Button 
                  variant="destructive"
                  size="sm"
                  onClick={handleStop}
                  disabled={!isConnected}
                >
                  <Square className="h-4 w-4 mr-2" />
                  Stop
                </Button>
                <div className="w-px h-6 bg-border mx-2"></div>
                <Button 
                  variant="outline"
                  size="sm"
                  onClick={handleStepOver}
                  disabled={!isConnected || !isPaused}
                >
                  <StepForward className="h-4 w-4 mr-2" />
                  Step Over
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  onClick={handleStepInto}
                  disabled={!isConnected || !isPaused}
                >
                  <SkipForward className="h-4 w-4 mr-2" />
                  Step Into
                </Button>
              </div>
            </div>

            {/* Connection Status */}
            {!isConnected && (
              <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5 text-orange-600" />
                    <span className="text-orange-800 dark:text-orange-200">
                      Not connected to debugger. Click "Connect" to start debugging.
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Main Debugging Interface */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Code Editor */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-2">
                        <Code className="h-5 w-5" />
                        <span>main.aigo</span>
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge variant={isPaused ? "secondary" : isRunning ? "default" : "outline"}>
                          {isPaused ? "Paused" : isRunning ? "Running" : "Stopped"}
                        </Badge>
                        {isPaused && (
                          <Badge variant="outline">Line {currentLine}</Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="border rounded-lg bg-muted/20 font-mono text-sm overflow-auto max-h-96">
                      {mockCode.split('\n').map((line, index) => renderCodeLine(line, index))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Debug Panels */}
              <div className="space-y-6">
                {/* Variables */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Variable className="h-5 w-5" />
                      <span>Variables</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    {variables.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No variables available</p>
                    ) : (
                      <div className="space-y-2">
                        {variables.map((variable, index) => (
                          <div key={index} className="flex items-center justify-between text-sm">
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{variable.name}</span>
                              <Badge variant="outline" className="text-xs">
                                {variable.type}
                              </Badge>
                            </div>
                            <span className="text-muted-foreground font-mono">
                              {variable.value}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Call Stack */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Function className="h-5 w-5" />
                      <span>Call Stack</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    {callStack.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No call stack available</p>
                    ) : (
                      <div className="space-y-2">
                        {callStack.map((frame, index) => (
                          <div key={index} className="text-sm">
                            <div className="font-medium">{frame.function}</div>
                            <div className="text-muted-foreground">
                              {frame.file}:{frame.line}
                            </div>
                            {frame.args.length > 0 && (
                              <div className="text-xs text-muted-foreground font-mono">
                                {frame.args.join(', ')}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Watch Expressions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Eye className="h-5 w-5" />
                      <span>Watch</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <Input placeholder="Add watch expression..." className="text-sm" />
                      {watchExpressions.map((watch, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span className="font-mono">{watch.expression}</span>
                          <span className="text-muted-foreground font-mono">
                            {watch.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Breakpoints Panel */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Breakpoint className="h-5 w-5" />
                  <span>Breakpoints</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {breakpoints.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No breakpoints set. Click on line numbers in the code editor to add breakpoints.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {breakpoints.map((bp, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span className="text-sm">main.aigo:Line {bp}</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => toggleBreakpoint(bp)}
                        >
                          Remove
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        } />
      </Routes>
    </div>
  )
}

export default VisualDebugger

