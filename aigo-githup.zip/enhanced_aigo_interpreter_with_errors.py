#!/usr/bin/env python3
"""
Enhanced AIGo Interpreter with Comprehensive Error Handling

This module extends the AIGo interpreter with robust error handling,
exception management, and debugging capabilities.

Author: Manus AI
Version: 2.0.0
Date: June 4, 2025
"""

import sys
import os
import traceback
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass

# Import our error handling system
from aigo_error_handling_system import (
    AIGoError, AIGoLexicalError, AIGoSyntaxError, AIGoSemanticError,
    AIGoTypeError, AIGoRuntimeError, AIGoMemoryError,
    ErrorLocation, ErrorContext, ErrorSeverity, ErrorCategory,
    ResultType, global_error_handler, handle_aigo_error
)

# Import original interpreter components
try:
    from enhanced_aigo_interpreter import (
        AIGoInterpreter, Token, TokenType, ASTNode, 
        NumberValue, StringValue, BooleanValue, ArrayValue, VoidValue
    )
except ImportError:
    print("Warning: Could not import enhanced_aigo_interpreter. Creating minimal implementation.")
    
    class Token:
        def __init__(self, type_name, value, line=1, column=1):
            self.type = type_name
            self.value = value
            self.line = line
            self.column = column
    
    class TokenType:
        NUMBER = "NUMBER"
        STRING = "STRING"
        IDENTIFIER = "IDENTIFIER"
        KEYWORD = "KEYWORD"
        OPERATOR = "OPERATOR"
        DELIMITER = "DELIMITER"
        EOF = "EOF"
    
    class ASTNode:
        def __init__(self, node_type, **kwargs):
            self.type = node_type
            for key, value in kwargs.items():
                setattr(self, key, value)
    
    class NumberValue:
        def __init__(self, value):
            self.value = float(value)
    
    class StringValue:
        def __init__(self, value):
            self.value = str(value)
    
    class BooleanValue:
        def __init__(self, value):
            self.value = bool(value)
    
    class ArrayValue:
        def __init__(self, elements=None):
            self.elements = elements or []
    
    class VoidValue:
        def __init__(self):
            self.value = None

class EnhancedAIGoLexer:
    """Enhanced lexer with comprehensive error handling"""
    
    def __init__(self, source_code: str, file_path: str = "<stdin>"):
        self.source = source_code
        self.file_path = file_path
        self.position = 0
        self.line = 1
        self.column = 1
        self.tokens = []
        self.errors = []
    
    def current_location(self) -> ErrorLocation:
        """Get current location in source code"""
        return ErrorLocation(self.file_path, self.line, self.column)
    
    def peek(self, offset: int = 0) -> str:
        """Peek at character at current position + offset"""
        pos = self.position + offset
        if pos >= len(self.source):
            return '\0'
        return self.source[pos]
    
    def advance(self) -> str:
        """Advance to next character"""
        if self.position >= len(self.source):
            return '\0'
        
        char = self.source[self.position]
        self.position += 1
        
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        
        return char
    
    def skip_whitespace(self):
        """Skip whitespace characters"""
        while self.peek().isspace():
            self.advance()
    
    def read_number(self) -> ResultType:
        """Read a number token with error handling"""
        start_pos = self.position
        start_col = self.column
        number_str = ""
        has_dot = False
        
        try:
            while self.peek().isdigit() or (self.peek() == '.' and not has_dot):
                char = self.advance()
                if char == '.':
                    has_dot = True
                number_str += char
            
            if not number_str or number_str == '.':
                error = AIGoLexicalError(
                    f"Invalid number format: '{number_str}'",
                    location=ErrorLocation(self.file_path, self.line, start_col),
                    suggestions=["Check number format", "Ensure digits are present"]
                )
                return ResultType.err(error)
            
            token = Token(TokenType.NUMBER, float(number_str), self.line, start_col)
            return ResultType.ok(token)
            
        except ValueError as e:
            error = AIGoLexicalError(
                f"Cannot parse number '{number_str}': {e}",
                location=ErrorLocation(self.file_path, self.line, start_col),
                cause=e
            )
            return ResultType.err(error)
    
    def read_string(self) -> ResultType:
        """Read a string token with error handling"""
        start_col = self.column
        quote_char = self.advance()  # Skip opening quote
        string_value = ""
        
        while self.peek() != quote_char and self.peek() != '\0':
            char = self.advance()
            if char == '\\':
                # Handle escape sequences
                next_char = self.advance()
                if next_char == 'n':
                    string_value += '\n'
                elif next_char == 't':
                    string_value += '\t'
                elif next_char == 'r':
                    string_value += '\r'
                elif next_char == '\\':
                    string_value += '\\'
                elif next_char == quote_char:
                    string_value += quote_char
                else:
                    string_value += next_char
            else:
                string_value += char
        
        if self.peek() != quote_char:
            error = AIGoLexicalError(
                f"Unterminated string literal",
                location=ErrorLocation(self.file_path, self.line, start_col),
                suggestions=["Add closing quote", "Check for escaped quotes"]
            )
            return ResultType.err(error)
        
        self.advance()  # Skip closing quote
        token = Token(TokenType.STRING, string_value, self.line, start_col)
        return ResultType.ok(token)
    
    def read_identifier(self) -> ResultType:
        """Read an identifier or keyword token"""
        start_col = self.column
        identifier = ""
        
        while self.peek().isalnum() or self.peek() == '_':
            identifier += self.advance()
        
        if not identifier:
            error = AIGoLexicalError(
                "Empty identifier",
                location=ErrorLocation(self.file_path, self.line, start_col)
            )
            return ResultType.err(error)
        
        # Check if it's a keyword
        keywords = {
            'fn', 'let', 'if', 'else', 'while', 'for', 'return', 'true', 'false',
            'module', 'import', 'struct', 'enum', 'trait', 'impl', 'pub', 'mut',
            'i32', 'i64', 'f32', 'f64', 'bool', 'str', 'void'
        }
        
        token_type = TokenType.KEYWORD if identifier in keywords else TokenType.IDENTIFIER
        token = Token(token_type, identifier, self.line, start_col)
        return ResultType.ok(token)
    
    @handle_aigo_error
    def tokenize(self) -> ResultType:
        """Tokenize the source code with comprehensive error handling"""
        tokens = []
        
        while self.position < len(self.source):
            self.skip_whitespace()
            
            if self.position >= len(self.source):
                break
            
            char = self.peek()
            
            # Numbers
            if char.isdigit():
                result = self.read_number()
                if result.is_ok:
                    tokens.append(result.value)
                else:
                    self.errors.append(result.error)
                    # Skip invalid character and continue
                    self.advance()
            
            # Strings
            elif char in ['"', "'"]:
                result = self.read_string()
                if result.is_ok:
                    tokens.append(result.value)
                else:
                    self.errors.append(result.error)
                    # Skip to next quote or end of line
                    while self.peek() not in [char, '\n', '\0']:
                        self.advance()
                    if self.peek() == char:
                        self.advance()
            
            # Identifiers and keywords
            elif char.isalpha() or char == '_':
                result = self.read_identifier()
                if result.is_ok:
                    tokens.append(result.value)
                else:
                    self.errors.append(result.error)
                    self.advance()
            
            # Operators and delimiters
            elif char in '+-*/=<>!&|':
                start_col = self.column
                op = self.advance()
                
                # Handle multi-character operators
                if char == '=' and self.peek() == '=':
                    op += self.advance()
                elif char == '!' and self.peek() == '=':
                    op += self.advance()
                elif char == '<' and self.peek() == '=':
                    op += self.advance()
                elif char == '>' and self.peek() == '=':
                    op += self.advance()
                elif char == '&' and self.peek() == '&':
                    op += self.advance()
                elif char == '|' and self.peek() == '|':
                    op += self.advance()
                
                tokens.append(Token(TokenType.OPERATOR, op, self.line, start_col))
            
            # Delimiters
            elif char in '(){}[];,.:':
                start_col = self.column
                delimiter = self.advance()
                tokens.append(Token(TokenType.DELIMITER, delimiter, self.line, start_col))
            
            # Unknown character
            else:
                error = AIGoLexicalError(
                    f"Unexpected character: '{char}'",
                    location=self.current_location(),
                    suggestions=["Check for typos", "Verify character encoding"]
                )
                self.errors.append(error)
                self.advance()
        
        # Add EOF token
        tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        
        if self.errors:
            # Return first error
            return ResultType.err(self.errors[0])
        
        return ResultType.ok(tokens)

class EnhancedAIGoParser:
    """Enhanced parser with comprehensive error handling"""
    
    def __init__(self, tokens: List[Token], file_path: str = "<stdin>"):
        self.tokens = tokens
        self.file_path = file_path
        self.position = 0
        self.errors = []
    
    def current_token(self) -> Token:
        """Get current token"""
        if self.position >= len(self.tokens):
            return self.tokens[-1]  # EOF token
        return self.tokens[self.position]
    
    def peek_token(self, offset: int = 1) -> Token:
        """Peek at token at current position + offset"""
        pos = self.position + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]  # EOF token
        return self.tokens[pos]
    
    def advance_token(self) -> Token:
        """Advance to next token"""
        token = self.current_token()
        if self.position < len(self.tokens) - 1:
            self.position += 1
        return token
    
    def expect_token(self, expected_type: str, expected_value: str = None) -> ResultType:
        """Expect a specific token type/value"""
        token = self.current_token()
        
        if token.type != expected_type:
            error = AIGoSyntaxError(
                f"Expected {expected_type}, got {token.type}",
                location=ErrorLocation(self.file_path, token.line, token.column),
                suggestions=[f"Add {expected_type} token", "Check syntax structure"]
            )
            return ResultType.err(error)
        
        if expected_value and token.value != expected_value:
            error = AIGoSyntaxError(
                f"Expected '{expected_value}', got '{token.value}'",
                location=ErrorLocation(self.file_path, token.line, token.column),
                suggestions=[f"Use '{expected_value}' instead", "Check spelling"]
            )
            return ResultType.err(error)
        
        self.advance_token()
        return ResultType.ok(token)
    
    def parse_expression(self) -> ResultType:
        """Parse an expression with error handling"""
        try:
            return self.parse_logical_or()
        except Exception as e:
            error = AIGoSyntaxError(
                f"Error parsing expression: {e}",
                location=ErrorLocation(self.file_path, self.current_token().line, self.current_token().column),
                cause=e
            )
            return ResultType.err(error)
    
    def parse_logical_or(self) -> ResultType:
        """Parse logical OR expression"""
        left_result = self.parse_logical_and()
        if not left_result.is_ok:
            return left_result
        
        left = left_result.value
        
        while self.current_token().value == "||":
            op_token = self.advance_token()
            right_result = self.parse_logical_and()
            if not right_result.is_ok:
                return right_result
            
            left = ASTNode("binary_op", left=left, operator=op_token.value, right=right_result.value)
        
        return ResultType.ok(left)
    
    def parse_logical_and(self) -> ResultType:
        """Parse logical AND expression"""
        left_result = self.parse_equality()
        if not left_result.is_ok:
            return left_result
        
        left = left_result.value
        
        while self.current_token().value == "&&":
            op_token = self.advance_token()
            right_result = self.parse_equality()
            if not right_result.is_ok:
                return right_result
            
            left = ASTNode("binary_op", left=left, operator=op_token.value, right=right_result.value)
        
        return ResultType.ok(left)
    
    def parse_equality(self) -> ResultType:
        """Parse equality expression"""
        left_result = self.parse_comparison()
        if not left_result.is_ok:
            return left_result
        
        left = left_result.value
        
        while self.current_token().value in ["==", "!="]:
            op_token = self.advance_token()
            right_result = self.parse_comparison()
            if not right_result.is_ok:
                return right_result
            
            left = ASTNode("binary_op", left=left, operator=op_token.value, right=right_result.value)
        
        return ResultType.ok(left)
    
    def parse_comparison(self) -> ResultType:
        """Parse comparison expression"""
        left_result = self.parse_addition()
        if not left_result.is_ok:
            return left_result
        
        left = left_result.value
        
        while self.current_token().value in ["<", ">", "<=", ">="]:
            op_token = self.advance_token()
            right_result = self.parse_addition()
            if not right_result.is_ok:
                return right_result
            
            left = ASTNode("binary_op", left=left, operator=op_token.value, right=right_result.value)
        
        return ResultType.ok(left)
    
    def parse_addition(self) -> ResultType:
        """Parse addition/subtraction expression"""
        left_result = self.parse_multiplication()
        if not left_result.is_ok:
            return left_result
        
        left = left_result.value
        
        while self.current_token().value in ["+", "-"]:
            op_token = self.advance_token()
            right_result = self.parse_multiplication()
            if not right_result.is_ok:
                return right_result
            
            left = ASTNode("binary_op", left=left, operator=op_token.value, right=right_result.value)
        
        return ResultType.ok(left)
    
    def parse_multiplication(self) -> ResultType:
        """Parse multiplication/division expression"""
        left_result = self.parse_primary()
        if not left_result.is_ok:
            return left_result
        
        left = left_result.value
        
        while self.current_token().value in ["*", "/", "%"]:
            op_token = self.advance_token()
            right_result = self.parse_primary()
            if not right_result.is_ok:
                return right_result
            
            left = ASTNode("binary_op", left=left, operator=op_token.value, right=right_result.value)
        
        return ResultType.ok(left)
    
    def parse_primary(self) -> ResultType:
        """Parse primary expression"""
        token = self.current_token()
        
        if token.type == TokenType.NUMBER:
            self.advance_token()
            return ResultType.ok(ASTNode("literal", value=NumberValue(token.value)))
        
        elif token.type == TokenType.STRING:
            self.advance_token()
            return ResultType.ok(ASTNode("literal", value=StringValue(token.value)))
        
        elif token.type == TokenType.KEYWORD and token.value in ["true", "false"]:
            self.advance_token()
            return ResultType.ok(ASTNode("literal", value=BooleanValue(token.value == "true")))
        
        elif token.type == TokenType.IDENTIFIER:
            self.advance_token()
            return ResultType.ok(ASTNode("identifier", name=token.value))
        
        elif token.value == "(":
            self.advance_token()
            expr_result = self.parse_expression()
            if not expr_result.is_ok:
                return expr_result
            
            close_result = self.expect_token(TokenType.DELIMITER, ")")
            if not close_result.is_ok:
                return close_result
            
            return expr_result
        
        else:
            error = AIGoSyntaxError(
                f"Unexpected token in expression: {token.value}",
                location=ErrorLocation(self.file_path, token.line, token.column),
                suggestions=["Check expression syntax", "Verify token placement"]
            )
            return ResultType.err(error)

class EnhancedAIGoInterpreter:
    """Enhanced interpreter with comprehensive error handling and debugging"""
    
    def __init__(self, debug_mode: bool = False):
        self.debug_mode = debug_mode
        self.variables = {}
        self.functions = {}
        self.call_stack = []
        self.execution_stats = {
            "operations": 0,
            "function_calls": 0,
            "errors": 0,
            "warnings": 0
        }
    
    def create_context(self, function_name: str = None) -> ErrorContext:
        """Create error context for current execution state"""
        return ErrorContext(
            function_name=function_name,
            module_name="main",
            variable_scope=dict(self.variables),
            call_stack=list(self.call_stack)
        )
    
    @handle_aigo_error
    def execute_code(self, source_code: str, file_path: str = "<stdin>") -> ResultType:
        """Execute AIGo source code with comprehensive error handling"""
        try:
            # Lexical analysis
            lexer = EnhancedAIGoLexer(source_code, file_path)
            tokens_result = lexer.tokenize()
            
            if not tokens_result.is_ok:
                self.execution_stats["errors"] += 1
                return tokens_result
            
            tokens = tokens_result.value
            
            # Syntax analysis
            parser = EnhancedAIGoParser(tokens, file_path)
            
            # For now, just parse expressions
            # In a full implementation, this would parse the entire program
            if tokens and tokens[0].type != TokenType.EOF:
                expr_result = parser.parse_expression()
                if not expr_result.is_ok:
                    self.execution_stats["errors"] += 1
                    return expr_result
                
                # Evaluate the expression
                result = self.evaluate_expression(expr_result.value)
                self.execution_stats["operations"] += 1
                return result
            
            return ResultType.ok(VoidValue())
            
        except Exception as e:
            error = AIGoRuntimeError(
                f"Unexpected error during execution: {e}",
                location=ErrorLocation(file_path, 1, 1),
                context=self.create_context(),
                cause=e
            )
            self.execution_stats["errors"] += 1
            return ResultType.err(error)
    
    def evaluate_expression(self, node: ASTNode) -> ResultType:
        """Evaluate an AST node with error handling"""
        try:
            if node.type == "literal":
                return ResultType.ok(node.value)
            
            elif node.type == "identifier":
                if node.name not in self.variables:
                    error = AIGoRuntimeError(
                        f"Undefined variable: {node.name}",
                        context=self.create_context(),
                        suggestions=[f"Define variable '{node.name}'", "Check variable name spelling"]
                    )
                    return ResultType.err(error)
                
                return ResultType.ok(self.variables[node.name])
            
            elif node.type == "binary_op":
                left_result = self.evaluate_expression(node.left)
                if not left_result.is_ok:
                    return left_result
                
                right_result = self.evaluate_expression(node.right)
                if not right_result.is_ok:
                    return right_result
                
                return self.apply_binary_operator(
                    node.operator, 
                    left_result.value, 
                    right_result.value
                )
            
            else:
                error = AIGoRuntimeError(
                    f"Unknown AST node type: {node.type}",
                    context=self.create_context()
                )
                return ResultType.err(error)
                
        except Exception as e:
            error = AIGoRuntimeError(
                f"Error evaluating expression: {e}",
                context=self.create_context(),
                cause=e
            )
            return ResultType.err(error)
    
    def apply_binary_operator(self, operator: str, left: Any, right: Any) -> ResultType:
        """Apply binary operator with type checking and error handling"""
        try:
            # Arithmetic operators
            if operator == "+":
                if isinstance(left, NumberValue) and isinstance(right, NumberValue):
                    return ResultType.ok(NumberValue(left.value + right.value))
                elif isinstance(left, StringValue) and isinstance(right, StringValue):
                    return ResultType.ok(StringValue(left.value + right.value))
                else:
                    error = AIGoTypeError(
                        f"Cannot add {type(left).__name__} and {type(right).__name__}",
                        context=self.create_context(),
                        suggestions=["Check operand types", "Use type conversion if needed"]
                    )
                    return ResultType.err(error)
            
            elif operator == "-":
                if isinstance(left, NumberValue) and isinstance(right, NumberValue):
                    return ResultType.ok(NumberValue(left.value - right.value))
                else:
                    error = AIGoTypeError(
                        f"Cannot subtract {type(right).__name__} from {type(left).__name__}",
                        context=self.create_context()
                    )
                    return ResultType.err(error)
            
            elif operator == "*":
                if isinstance(left, NumberValue) and isinstance(right, NumberValue):
                    return ResultType.ok(NumberValue(left.value * right.value))
                else:
                    error = AIGoTypeError(
                        f"Cannot multiply {type(left).__name__} and {type(right).__name__}",
                        context=self.create_context()
                    )
                    return ResultType.err(error)
            
            elif operator == "/":
                if isinstance(left, NumberValue) and isinstance(right, NumberValue):
                    if right.value == 0:
                        error = AIGoRuntimeError(
                            "Division by zero",
                            context=self.create_context(),
                            suggestions=["Add zero check before division", "Use conditional logic"]
                        )
                        return ResultType.err(error)
                    return ResultType.ok(NumberValue(left.value / right.value))
                else:
                    error = AIGoTypeError(
                        f"Cannot divide {type(left).__name__} by {type(right).__name__}",
                        context=self.create_context()
                    )
                    return ResultType.err(error)
            
            # Comparison operators
            elif operator == "==":
                if type(left) == type(right):
                    return ResultType.ok(BooleanValue(left.value == right.value))
                else:
                    return ResultType.ok(BooleanValue(False))
            
            elif operator == "!=":
                if type(left) == type(right):
                    return ResultType.ok(BooleanValue(left.value != right.value))
                else:
                    return ResultType.ok(BooleanValue(True))
            
            elif operator in ["<", ">", "<=", ">="]:
                if isinstance(left, NumberValue) and isinstance(right, NumberValue):
                    if operator == "<":
                        result = left.value < right.value
                    elif operator == ">":
                        result = left.value > right.value
                    elif operator == "<=":
                        result = left.value <= right.value
                    else:  # ">="
                        result = left.value >= right.value
                    
                    return ResultType.ok(BooleanValue(result))
                else:
                    error = AIGoTypeError(
                        f"Cannot compare {type(left).__name__} and {type(right).__name__}",
                        context=self.create_context()
                    )
                    return ResultType.err(error)
            
            else:
                error = AIGoRuntimeError(
                    f"Unknown binary operator: {operator}",
                    context=self.create_context()
                )
                return ResultType.err(error)
                
        except Exception as e:
            error = AIGoRuntimeError(
                f"Error applying operator '{operator}': {e}",
                context=self.create_context(),
                cause=e
            )
            return ResultType.err(error)
    
    def get_execution_report(self) -> Dict[str, Any]:
        """Get execution statistics and error report"""
        return {
            "execution_stats": self.execution_stats,
            "error_stats": global_error_handler.get_error_statistics(),
            "variables": {name: str(value.value) for name, value in self.variables.items()},
            "functions": list(self.functions.keys())
        }

# Testing and demonstration
if __name__ == "__main__":
    print("Enhanced AIGo Interpreter with Error Handling - Testing")
    
    interpreter = EnhancedAIGoInterpreter(debug_mode=True)
    
    # Test cases with various error scenarios
    test_cases = [
        # Valid expressions
        ("5 + 3", "Valid arithmetic"),
        ("10 * 2.5", "Valid multiplication"),
        ("true == false", "Valid boolean comparison"),
        
        # Error cases
        ("5 / 0", "Division by zero"),
        ("5 + 'hello'", "Type mismatch"),
        ("undefined_var", "Undefined variable"),
        ("5 +", "Incomplete expression"),
        ("'unterminated string", "Unterminated string"),
        ("5 & 3", "Unknown operator"),
    ]
    
    print(f"\n{'='*60}")
    print("Testing Enhanced AIGo Interpreter")
    print(f"{'='*60}")
    
    for code, description in test_cases:
        print(f"\nTest: {description}")
        print(f"Code: {code}")
        print("-" * 40)
        
        result = interpreter.execute_code(code)
        
        if result.is_ok:
            value = result.value
            if hasattr(value, 'value'):
                print(f"Result: {value.value} ({type(value).__name__})")
            else:
                print(f"Result: {value}")
        else:
            print("Error occurred:")
            print(result.error.format_error())
    
    # Print execution report
    print(f"\n{'='*60}")
    print("Execution Report")
    print(f"{'='*60}")
    
    report = interpreter.get_execution_report()
    print(f"Operations executed: {report['execution_stats']['operations']}")
    print(f"Errors encountered: {report['execution_stats']['errors']}")
    print(f"Total errors in system: {report['error_stats']['total_errors']}")
    
    # Export detailed error report
    global_error_handler.export_error_report("enhanced_interpreter_errors.json")
    print(f"\nDetailed error report exported to: enhanced_interpreter_errors.json")

