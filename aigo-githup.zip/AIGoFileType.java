package dev.aigo.intellij;

import com.intellij.openapi.fileTypes.LanguageFileType;
import com.intellij.openapi.util.IconLoader;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * AIGo file type definition for IntelliJ IDEA
 */
public class AIGoFileType extends LanguageFileType {
    public static final AIGoFileType INSTANCE = new AIGoFileType();
    
    private AIGoFileType() {
        super(AIGoLanguage.INSTANCE);
    }
    
    @NotNull
    @Override
    public String getName() {
        return "AIGo";
    }
    
    @NotNull
    @Override
    public String getDescription() {
        return "AIGo programming language file";
    }
    
    @NotNull
    @Override
    public String getDefaultExtension() {
        return "aigo";
    }
    
    @Nullable
    @Override
    public Icon getIcon() {
        return IconLoader.getIcon("/icons/aigo.png", AIGoFileType.class);
    }
}

