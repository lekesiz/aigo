#!/usr/bin/env python3
"""
AIGo Integration Testing Suite

Comprehensive integration tests for the AIGo programming language interpreter,
including cross-platform compatibility, performance regression, memory leak detection,
and end-to-end testing scenarios.

Author: Manus AI
Version: 1.0.0
Date: June 5, 2025
"""

import os
import sys
import time
import json
import psutil
import platform
import subprocess
import tempfile
import threading
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from pathlib import Path

# Import AIGo components
from aigo_test_adapter import AIGoTestAdapter
from aigo_unit_test_framework import (
    TestCase, TestSuite, TestRunner, AIGoAssertions, TestResult
)
from aigo_error_handling_system import AIGoError, global_error_handler

@dataclass
class PerformanceMetrics:
    """Performance metrics for integration tests"""
    execution_time: float
    memory_usage: float
    cpu_usage: float
    operations_count: int
    function_calls: int

@dataclass
class CompatibilityResult:
    """Cross-platform compatibility test result"""
    platform_name: str
    python_version: str
    test_passed: bool
    error_message: Optional[str] = None
    performance_metrics: Optional[PerformanceMetrics] = None

class AIGoIntegrationTester:
    """Main integration testing class"""
    
    def __init__(self):
        self.interpreter = AIGoTestAdapter()
        self.test_results = []
        self.performance_baseline = {}
        
    def setup_test_environment(self):
        """Setup test environment"""
        # Create temporary directory for test files
        self.test_dir = tempfile.mkdtemp(prefix="aigo_integration_")
        
        # Initialize performance baseline
        self.establish_performance_baseline()
        
    def cleanup_test_environment(self):
        """Cleanup test environment"""
        import shutil
        if hasattr(self, 'test_dir') and os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
    
    def establish_performance_baseline(self):
        """Establish performance baseline for regression testing"""
        baseline_tests = [
            ("simple_arithmetic", "let x = 10 + 20; println(x);"),
            ("loop_execution", "for i in range(100) { let x = i * 2; }"),
            ("function_calls", "func test() { return 42; } for i in range(50) { test(); }"),
            ("array_operations", "let arr = array_new(100); for i in range(100) { array_push(arr, i); }"),
        ]
        
        for test_name, code in baseline_tests:
            metrics = self.measure_performance(code)
            self.performance_baseline[test_name] = metrics
    
    def measure_performance(self, code: str) -> PerformanceMetrics:
        """Measure performance metrics for code execution"""
        process = psutil.Process()
        
        # Measure initial state
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        initial_cpu = process.cpu_percent()
        
        # Execute code and measure
        start_time = time.time()
        
        try:
            result = self.interpreter.execute_code(code)
            execution_time = time.time() - start_time
            
            # Measure final state
            final_memory = process.memory_info().rss / 1024 / 1024  # MB
            final_cpu = process.cpu_percent()
            
            # Get execution stats if available
            stats = getattr(self.interpreter, 'execution_stats', {})
            operations_count = stats.get('operations', 0)
            function_calls = stats.get('function_calls', 0)
            
            return PerformanceMetrics(
                execution_time=execution_time,
                memory_usage=final_memory - initial_memory,
                cpu_usage=final_cpu - initial_cpu,
                operations_count=operations_count,
                function_calls=function_calls
            )
            
        except Exception as e:
            return PerformanceMetrics(
                execution_time=time.time() - start_time,
                memory_usage=0,
                cpu_usage=0,
                operations_count=0,
                function_calls=0
            )
    
    def test_interpreter_integration(self) -> bool:
        """Test complete interpreter integration"""
        test_cases = [
            # Basic functionality
            ("variable_declaration", "let x = 42; println(x);", "42"),
            ("arithmetic_operations", "let result = 10 + 5 * 2; println(result);", "20"),
            ("string_operations", 'let msg = "Hello" + " " + "World"; println(msg);', "Hello World"),
            ("boolean_operations", "let flag = true && false; println(flag);", "false"),
            
            # Control flow
            ("if_statement", "if (true) { println('yes'); } else { println('no'); }", "yes"),
            ("for_loop", "for i in range(3) { println(i); }", "0\n1\n2"),
            ("while_loop", "let i = 0; while (i < 3) { println(i); i = i + 1; }", "0\n1\n2"),
            
            # Functions
            ("function_definition", "func add(a, b) { return a + b; } println(add(3, 4));", "7"),
            ("recursive_function", "func fib(n) { if (n <= 1) return n; return fib(n-1) + fib(n-2); } println(fib(5));", "5"),
            
            # Arrays
            ("array_creation", "let arr = [1, 2, 3]; println(array_len(arr));", "3"),
            ("array_manipulation", "let arr = array_new(); array_push(arr, 42); println(array_get(arr, 0));", "42"),
            
            # Error handling
            ("try_catch", "try { let x = 10 / 0; } catch (e) { println('caught error'); }", "caught error"),
            ("throw_exception", "try { throw RuntimeError('test'); } catch (e) { println('exception caught'); }", "exception caught"),
        ]
        
        passed_tests = 0
        total_tests = len(test_cases)
        
        for test_name, code, expected_output in test_cases:
            try:
                # Capture output
                import io
                import contextlib
                
                output_buffer = io.StringIO()
                with contextlib.redirect_stdout(output_buffer):
                    self.interpreter.execute_code(code)
                
                actual_output = output_buffer.getvalue().strip()
                
                if actual_output == expected_output:
                    passed_tests += 1
                    print(f"✓ {test_name}: PASSED")
                else:
                    print(f"✗ {test_name}: FAILED")
                    print(f"  Expected: {expected_output}")
                    print(f"  Actual: {actual_output}")
                    
            except Exception as e:
                print(f"✗ {test_name}: ERROR - {e}")
        
        success_rate = passed_tests / total_tests
        print(f"\nInterpreter Integration Test Results: {passed_tests}/{total_tests} passed ({success_rate:.1%})")
        
        return success_rate >= 0.8  # 80% success rate required
    
    def test_cross_platform_compatibility(self) -> List[CompatibilityResult]:
        """Test cross-platform compatibility"""
        results = []
        
        # Get current platform info
        platform_info = {
            'system': platform.system(),
            'release': platform.release(),
            'machine': platform.machine(),
            'python_version': platform.python_version()
        }
        
        print(f"Testing on: {platform_info['system']} {platform_info['release']} ({platform_info['machine']})")
        print(f"Python version: {platform_info['python_version']}")
        
        # Test basic functionality on current platform
        test_code = """
        func test_platform() {
            let x = 10;
            let y = 20;
            let result = x + y;
            println("Platform test result: " + result);
            return result;
        }
        
        test_platform();
        """
        
        try:
            metrics = self.measure_performance(test_code)
            result = CompatibilityResult(
                platform_name=f"{platform_info['system']} {platform_info['release']}",
                python_version=platform_info['python_version'],
                test_passed=True,
                performance_metrics=metrics
            )
            print("✓ Platform compatibility test: PASSED")
            
        except Exception as e:
            result = CompatibilityResult(
                platform_name=f"{platform_info['system']} {platform_info['release']}",
                python_version=platform_info['python_version'],
                test_passed=False,
                error_message=str(e)
            )
            print(f"✗ Platform compatibility test: FAILED - {e}")
        
        results.append(result)
        return results
    
    def test_performance_regression(self) -> Dict[str, bool]:
        """Test for performance regressions"""
        regression_results = {}
        tolerance = 0.2  # 20% performance degradation tolerance
        
        print("Running performance regression tests...")
        
        for test_name, baseline_metrics in self.performance_baseline.items():
            # Re-run the test
            if test_name == "simple_arithmetic":
                code = "let x = 10 + 20; println(x);"
            elif test_name == "loop_execution":
                code = "for i in range(100) { let x = i * 2; }"
            elif test_name == "function_calls":
                code = "func test() { return 42; } for i in range(50) { test(); }"
            elif test_name == "array_operations":
                code = "let arr = array_new(100); for i in range(100) { array_push(arr, i); }"
            else:
                continue
            
            current_metrics = self.measure_performance(code)
            
            # Check for regression
            time_regression = (current_metrics.execution_time - baseline_metrics.execution_time) / baseline_metrics.execution_time
            memory_regression = (current_metrics.memory_usage - baseline_metrics.memory_usage) / max(baseline_metrics.memory_usage, 0.1)
            
            is_regression = time_regression > tolerance or memory_regression > tolerance
            regression_results[test_name] = not is_regression
            
            if is_regression:
                print(f"✗ {test_name}: REGRESSION DETECTED")
                print(f"  Time: {time_regression:.1%} change")
                print(f"  Memory: {memory_regression:.1%} change")
            else:
                print(f"✓ {test_name}: NO REGRESSION")
        
        return regression_results
    
    def test_memory_leaks(self) -> bool:
        """Test for memory leaks"""
        print("Running memory leak detection...")
        
        # Test code that could potentially leak memory
        test_code = """
        func memory_test() {
            for i in range(1000) {
                let arr = array_new(100);
                for j in range(100) {
                    array_push(arr, j);
                }
            }
        }
        
        memory_test();
        """
        
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Run test multiple times
        for i in range(5):
            try:
                self.interpreter.execute_code(test_code)
            except Exception as e:
                print(f"Error in memory test iteration {i}: {e}")
        
        # Force garbage collection
        import gc
        gc.collect()
        time.sleep(1)  # Allow time for cleanup
        
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory
        
        # Consider it a leak if memory increased by more than 50MB
        has_leak = memory_increase > 50
        
        if has_leak:
            print(f"✗ Memory leak detected: {memory_increase:.1f}MB increase")
        else:
            print(f"✓ No significant memory leak: {memory_increase:.1f}MB increase")
        
        return not has_leak
    
    def test_concurrent_execution(self) -> bool:
        """Test concurrent execution scenarios"""
        print("Running concurrent execution tests...")
        
        def worker_function(worker_id: int, results: List):
            """Worker function for concurrent testing"""
            try:
                code = f"""
                func worker_{worker_id}() {{
                    let result = 0;
                    for i in range(100) {{
                        result = result + i;
                    }}
                    return result;
                }}
                
                worker_{worker_id}();
                """
                
                # Create separate interpreter instance for each worker
                worker_interpreter = AIGoTestAdapter()
                result = worker_interpreter.execute_code(code)
                results.append((worker_id, True, None))
                
            except Exception as e:
                results.append((worker_id, False, str(e)))
        
        # Run multiple workers concurrently
        threads = []
        results = []
        num_workers = 5
        
        for i in range(num_workers):
            thread = threading.Thread(target=worker_function, args=(i, results))
            threads.append(thread)
            thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join(timeout=10)  # 10 second timeout
        
        # Check results
        successful_workers = sum(1 for _, success, _ in results if success)
        success_rate = successful_workers / num_workers
        
        if success_rate >= 0.8:  # 80% success rate required
            print(f"✓ Concurrent execution test: {successful_workers}/{num_workers} workers succeeded")
            return True
        else:
            print(f"✗ Concurrent execution test: Only {successful_workers}/{num_workers} workers succeeded")
            for worker_id, success, error in results:
                if not success:
                    print(f"  Worker {worker_id} failed: {error}")
            return False
    
    def test_error_recovery(self) -> bool:
        """Test error recovery mechanisms"""
        print("Running error recovery tests...")
        
        recovery_tests = [
            ("division_by_zero", "try { let x = 10 / 0; } catch (e) { println('recovered'); }"),
            ("undefined_variable", "try { println(undefined_var); } catch (e) { println('recovered'); }"),
            ("array_index_error", "try { let arr = [1, 2]; println(arr[10]); } catch (e) { println('recovered'); }"),
            ("type_error", "try { let x = 'string' + 42; } catch (e) { println('recovered'); }"),
        ]
        
        successful_recoveries = 0
        
        for test_name, code in recovery_tests:
            try:
                import io
                import contextlib
                
                output_buffer = io.StringIO()
                with contextlib.redirect_stdout(output_buffer):
                    self.interpreter.execute_code(code)
                
                output = output_buffer.getvalue().strip()
                
                if "recovered" in output:
                    successful_recoveries += 1
                    print(f"✓ {test_name}: Error recovered successfully")
                else:
                    print(f"✗ {test_name}: Error recovery failed")
                    
            except Exception as e:
                print(f"✗ {test_name}: Unexpected error - {e}")
        
        success_rate = successful_recoveries / len(recovery_tests)
        print(f"Error recovery test results: {successful_recoveries}/{len(recovery_tests)} recovered ({success_rate:.1%})")
        
        return success_rate >= 0.75  # 75% success rate required
    
    def run_full_integration_suite(self) -> Dict[str, Any]:
        """Run the complete integration test suite"""
        print("=" * 60)
        print("AIGo Integration Testing Suite")
        print("=" * 60)
        
        start_time = time.time()
        
        # Setup test environment
        self.setup_test_environment()
        
        try:
            # Run all integration tests
            results = {
                'interpreter_integration': self.test_interpreter_integration(),
                'cross_platform_compatibility': self.test_cross_platform_compatibility(),
                'performance_regression': self.test_performance_regression(),
                'memory_leaks': self.test_memory_leaks(),
                'concurrent_execution': self.test_concurrent_execution(),
                'error_recovery': self.test_error_recovery(),
            }
            
            # Calculate overall success
            test_scores = [
                results['interpreter_integration'],
                len([r for r in results['cross_platform_compatibility'] if r.test_passed]) > 0,
                all(results['performance_regression'].values()) if results['performance_regression'] else True,
                results['memory_leaks'],
                results['concurrent_execution'],
                results['error_recovery'],
            ]
            
            overall_success = sum(test_scores) / len(test_scores)
            
            # Generate summary
            total_duration = time.time() - start_time
            
            summary = {
                'overall_success_rate': overall_success,
                'total_duration': total_duration,
                'test_results': results,
                'platform_info': {
                    'system': platform.system(),
                    'release': platform.release(),
                    'python_version': platform.python_version()
                },
                'timestamp': time.time()
            }
            
            print("\n" + "=" * 60)
            print("INTEGRATION TEST SUMMARY")
            print("=" * 60)
            print(f"Overall Success Rate: {overall_success:.1%}")
            print(f"Total Duration: {total_duration:.3f}s")
            print(f"Platform: {platform.system()} {platform.release()}")
            print(f"Python Version: {platform.python_version()}")
            
            # Print individual test results
            print("\nIndividual Test Results:")
            print(f"  Interpreter Integration: {'✓' if results['interpreter_integration'] else '✗'}")
            print(f"  Cross-Platform Compatibility: {'✓' if any(r.test_passed for r in results['cross_platform_compatibility']) else '✗'}")
            print(f"  Performance Regression: {'✓' if all(results['performance_regression'].values()) else '✗'}")
            print(f"  Memory Leaks: {'✓' if results['memory_leaks'] else '✗'}")
            print(f"  Concurrent Execution: {'✓' if results['concurrent_execution'] else '✗'}")
            print(f"  Error Recovery: {'✓' if results['error_recovery'] else '✗'}")
            
            return summary
            
        finally:
            # Cleanup test environment
            self.cleanup_test_environment()

# Example usage and testing
if __name__ == "__main__":
    print("AIGo Integration Testing Suite - Starting Tests")
    
    # Create and run integration tester
    tester = AIGoIntegrationTester()
    summary = tester.run_full_integration_suite()
    
    # Export results
    with open("aigo_integration_test_results.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)
    
    print(f"\nIntegration test results exported to aigo_integration_test_results.json")
    
    # Determine exit code based on success rate
    if summary['overall_success_rate'] >= 0.8:
        print("\n🎉 Integration tests PASSED! AIGo is ready for production.")
        sys.exit(0)
    else:
        print("\n❌ Integration tests FAILED! Issues need to be addressed.")
        sys.exit(1)

