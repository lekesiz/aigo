import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card.jsx'
import { Button } from './ui/button.jsx'
import { Badge } from './ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs.jsx'
import { Progress } from './ui/progress.jsx'
import { 
  Activity, 
  Cpu, 
  MemoryStick, 
  HardDrive,
  Network,
  Clock,
  Zap,
  TrendingUp,
  TrendingDown,
  BarChart3,
  LineChart,
  PieChart,
  Gauge,
  RefreshCw,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle,
  Settings,
  Filter,
  Calendar,
  Timer
} from 'lucide-react'
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Cell } from 'recharts'

const PerformanceProfiler = ({ isConnected }) => {
  const [isRecording, setIsRecording] = useState(false)
  const [recordingDuration, setRecordingDuration] = useState(0)
  const [selectedTimeRange, setSelectedTimeRange] = useState('1m')

  // Mock performance data
  const [performanceData, setPerformanceData] = useState([])
  const [memoryData, setMemoryData] = useState([])
  const [networkData, setNetworkData] = useState([])

  useEffect(() => {
    // Generate mock performance data
    const generateData = () => {
      const now = Date.now()
      const data = []
      const memData = []
      const netData = []

      for (let i = 0; i < 60; i++) {
        const timestamp = now - (59 - i) * 1000
        data.push({
          time: new Date(timestamp).toLocaleTimeString(),
          cpu: Math.random() * 80 + 10,
          memory: Math.random() * 512 + 256,
          disk: Math.random() * 50 + 5,
          network: Math.random() * 100 + 10
        })

        memData.push({
          time: new Date(timestamp).toLocaleTimeString(),
          heap: Math.random() * 200 + 100,
          stack: Math.random() * 50 + 20,
          gc: Math.random() * 30 + 5
        })

        netData.push({
          time: new Date(timestamp).toLocaleTimeString(),
          incoming: Math.random() * 50 + 10,
          outgoing: Math.random() * 30 + 5
        })
      }

      setPerformanceData(data)
      setMemoryData(memData)
      setNetworkData(netData)
    }

    generateData()
    const interval = setInterval(generateData, 2000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    let interval
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingDuration(prev => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isRecording])

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const currentMetrics = {
    cpu: 34.2,
    memory: 245.6,
    disk: 12.8,
    network: 8.4,
    fps: 60,
    latency: 15.2
  }

  const functionProfileData = [
    { name: 'fibonacci', calls: 1247, totalTime: 245.6, avgTime: 0.197, percentage: 45.2 },
    { name: 'main', calls: 1, totalTime: 543.2, avgTime: 543.2, percentage: 100.0 },
    { name: 'println', calls: 156, totalTime: 23.4, avgTime: 0.150, percentage: 4.3 },
    { name: 'string_concat', calls: 89, totalTime: 12.7, avgTime: 0.143, percentage: 2.3 },
    { name: 'memory_alloc', calls: 234, totalTime: 34.5, avgTime: 0.147, percentage: 6.3 }
  ]

  const memoryBreakdown = [
    { name: 'Heap', value: 156.8, color: '#8884d8' },
    { name: 'Stack', value: 23.4, color: '#82ca9d' },
    { name: 'Code', value: 45.2, color: '#ffc658' },
    { name: 'Static', value: 20.2, color: '#ff7300' }
  ]

  const handleStartRecording = () => {
    setIsRecording(true)
    setRecordingDuration(0)
  }

  const handleStopRecording = () => {
    setIsRecording(false)
  }

  return (
    <div className="space-y-6">
      <Routes>
        <Route path="/" element={
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold">Performance Profiler</h1>
                <p className="text-muted-foreground">
                  Real-time performance monitoring and analysis
                </p>
              </div>
              
              {/* Recording Controls */}
              <div className="flex items-center space-x-4">
                {isRecording && (
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-sm font-mono">{formatDuration(recordingDuration)}</span>
                  </div>
                )}
                <Button 
                  variant={isRecording ? "destructive" : "default"}
                  onClick={isRecording ? handleStopRecording : handleStartRecording}
                  disabled={!isConnected}
                >
                  {isRecording ? (
                    <>
                      <Square className="h-4 w-4 mr-2" />
                      Stop Recording
                    </>
                  ) : (
                    <>
                      <Activity className="h-4 w-4 mr-2" />
                      Start Profiling
                    </>
                  )}
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>

            {/* Connection Status */}
            {!isConnected && (
              <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5 text-orange-600" />
                    <span className="text-orange-800 dark:text-orange-200">
                      Not connected to application. Connect to start profiling.
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Real-time Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Cpu className="h-5 w-5 text-blue-600" />
                    <div>
                      <div className="text-2xl font-bold">{currentMetrics.cpu}%</div>
                      <div className="text-xs text-muted-foreground">CPU Usage</div>
                    </div>
                  </div>
                  <Progress value={currentMetrics.cpu} className="mt-2 h-1" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <MemoryStick className="h-5 w-5 text-green-600" />
                    <div>
                      <div className="text-2xl font-bold">{currentMetrics.memory}MB</div>
                      <div className="text-xs text-muted-foreground">Memory</div>
                    </div>
                  </div>
                  <Progress value={(currentMetrics.memory / 1024) * 100} className="mt-2 h-1" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <HardDrive className="h-5 w-5 text-purple-600" />
                    <div>
                      <div className="text-2xl font-bold">{currentMetrics.disk}MB/s</div>
                      <div className="text-xs text-muted-foreground">Disk I/O</div>
                    </div>
                  </div>
                  <Progress value={currentMetrics.disk * 2} className="mt-2 h-1" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Network className="h-5 w-5 text-orange-600" />
                    <div>
                      <div className="text-2xl font-bold">{currentMetrics.network}MB/s</div>
                      <div className="text-xs text-muted-foreground">Network</div>
                    </div>
                  </div>
                  <Progress value={currentMetrics.network * 3} className="mt-2 h-1" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Gauge className="h-5 w-5 text-red-600" />
                    <div>
                      <div className="text-2xl font-bold">{currentMetrics.fps}</div>
                      <div className="text-xs text-muted-foreground">FPS</div>
                    </div>
                  </div>
                  <Progress value={currentMetrics.fps} className="mt-2 h-1" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5 text-yellow-600" />
                    <div>
                      <div className="text-2xl font-bold">{currentMetrics.latency}ms</div>
                      <div className="text-xs text-muted-foreground">Latency</div>
                    </div>
                  </div>
                  <Progress value={currentMetrics.latency * 2} className="mt-2 h-1" />
                </CardContent>
              </Card>
            </div>

            {/* Performance Charts */}
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="functions">Functions</TabsTrigger>
                <TabsTrigger value="memory">Memory</TabsTrigger>
                <TabsTrigger value="network">Network</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* CPU & Memory Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>System Performance</CardTitle>
                      <CardDescription>CPU and Memory usage over time</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <RechartsLineChart data={performanceData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="cpu" stroke="#8884d8" name="CPU %" />
                          <Line type="monotone" dataKey="memory" stroke="#82ca9d" name="Memory MB" />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  {/* Disk & Network Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>I/O Performance</CardTitle>
                      <CardDescription>Disk and Network throughput</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={performanceData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area type="monotone" dataKey="disk" stackId="1" stroke="#ffc658" fill="#ffc658" name="Disk MB/s" />
                          <Area type="monotone" dataKey="network" stackId="1" stroke="#ff7300" fill="#ff7300" name="Network MB/s" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="functions" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Function Profiling</CardTitle>
                    <CardDescription>Performance breakdown by function</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {functionProfileData.map((func, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{func.name}</span>
                              <Badge variant="outline">{func.calls} calls</Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {func.totalTime}ms total • {func.avgTime}ms avg
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Progress value={func.percentage} className="flex-1 h-2" />
                            <span className="text-sm font-medium w-12">{func.percentage}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="memory" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Memory Usage Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Memory Usage</CardTitle>
                      <CardDescription>Heap, Stack, and GC activity</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <RechartsLineChart data={memoryData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="heap" stroke="#8884d8" name="Heap MB" />
                          <Line type="monotone" dataKey="stack" stroke="#82ca9d" name="Stack MB" />
                          <Line type="monotone" dataKey="gc" stroke="#ffc658" name="GC MB" />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  {/* Memory Breakdown */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Memory Breakdown</CardTitle>
                      <CardDescription>Current memory allocation</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <RechartsPieChart>
                          <Pie
                            data={memoryBreakdown}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, value }) => `${name}: ${value}MB`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {memoryBreakdown.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="network" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Network Activity</CardTitle>
                    <CardDescription>Incoming and outgoing network traffic</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={networkData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="incoming" fill="#8884d8" name="Incoming MB/s" />
                        <Bar dataKey="outgoing" fill="#82ca9d" name="Outgoing MB/s" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        } />
      </Routes>
    </div>
  )
}

export default PerformanceProfiler

