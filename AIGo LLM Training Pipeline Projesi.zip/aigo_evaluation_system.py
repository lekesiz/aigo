#!/usr/bin/env python3
"""
AIGo Model Evaluation and Benchmarking System
Comprehensive evaluation framework for AIGo-trained LLMs
"""

import json
import re
import ast
import subprocess
import tempfile
import os
import time
from typing import Dict, List, Any, Tuple, Optional
import logging
from dataclasses import dataclass
from enum import Enum
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EvaluationMetric(Enum):
    """Evaluation metrics for AIGo code generation"""
    SYNTAX_CORRECTNESS = "syntax_correctness"
    SEMANTIC_CORRECTNESS = "semantic_correctness"
    COMPILATION_SUCCESS = "compilation_success"
    EXECUTION_SUCCESS = "execution_success"
    PERFORMANCE_EFFICIENCY = "performance_efficiency"
    AIGO_IDIOM_USAGE = "aigo_idiom_usage"
    CODE_QUALITY = "code_quality"
    INSTRUCTION_FOLLOWING = "instruction_following"

@dataclass
class EvaluationResult:
    """Result of a single evaluation"""
    prompt: str
    generated_code: str
    expected_output: Optional[str]
    metrics: Dict[str, float]
    errors: List[str]
    execution_time: Optional[float]
    memory_usage: Optional[float]

class AIGoSyntaxChecker:
    """Syntax checker for AIGo code"""
    
    def __init__(self):
        self.aigo_keywords = {
            "module", "import", "fn", "let", "return", "if", "else", "while",
            "true", "false", "void"
        }
        self.aigo_types = {
            "i32", "f64", "string", "bool", "void", "Array", "Result", "Error"
        }
        self.aigo_builtins = {
            "println", "print", "input", "Ok", "Err", "array_new", "array_push",
            "array_pop", "array_len", "array_get", "array_set", "abs", "min",
            "max", "sqrt", "time", "random", "range"
        }
    
    def check_syntax(self, code: str) -> Tuple[bool, List[str]]:
        """Check if AIGo code has correct syntax"""
        errors = []
        
        # Basic syntax checks
        if not code.strip():
            errors.append("Empty code")
            return False, errors
        
        # Check for balanced braces
        brace_count = code.count('{') - code.count('}')
        if brace_count != 0:
            errors.append(f"Unbalanced braces: {brace_count}")
        
        # Check for balanced parentheses
        paren_count = code.count('(') - code.count(')')
        if paren_count != 0:
            errors.append(f"Unbalanced parentheses: {paren_count}")
        
        # Check function declarations
        fn_pattern = r'fn\s+(\w+)\s*\([^)]*\)\s*(?:->\s*[\w<>,\s]+)?\s*\{'
        functions = re.findall(fn_pattern, code)
        
        # Check for proper module declaration
        if not re.search(r'module\s+\w+', code):
            errors.append("Missing module declaration")
        
        # Check for proper variable declarations
        let_pattern = r'let\s+\w+(?:\s*:\s*[\w<>,\s]+)?(?:\s*=\s*[^;]+)?'
        
        # Check for return statements in functions
        for func in functions:
            func_body_pattern = rf'fn\s+{func}\s*\([^)]*\)[^{{]*\{{([^}}]*)\}}'
            func_match = re.search(func_body_pattern, code, re.DOTALL)
            if func_match:
                func_body = func_match.group(1)
                if 'return' not in func_body and '->' in code:
                    # Only check for return if function has return type
                    if re.search(rf'fn\s+{func}\s*\([^)]*\)\s*->', code):
                        errors.append(f"Function '{func}' missing return statement")
        
        return len(errors) == 0, errors
    
    def check_aigo_idioms(self, code: str) -> float:
        """Check usage of AIGo-specific idioms and patterns"""
        score = 0.0
        total_checks = 0
        
        # Check for proper error handling with Result<T, E>
        total_checks += 1
        if 'Result<' in code and ('Ok(' in code or 'Err(' in code):
            score += 1
        
        # Check for proper array usage
        total_checks += 1
        if 'Array<' in code and any(builtin in code for builtin in ['array_new', 'array_push', 'array_get']):
            score += 1
        
        # Check for proper type annotations
        total_checks += 1
        if re.search(r'let\s+\w+\s*:\s*\w+', code):
            score += 1
        
        # Check for proper function signatures
        total_checks += 1
        if re.search(r'fn\s+\w+\([^)]*\)\s*->\s*\w+', code):
            score += 1
        
        # Check for memory-safe patterns
        total_checks += 1
        if '?' in code:  # Error propagation operator
            score += 1
        
        return score / total_checks if total_checks > 0 else 0.0

class AIGoCodeExecutor:
    """Execute AIGo code using the interpreter"""
    
    def __init__(self, interpreter_path: str = "./enhanced_aigo_interpreter.py"):
        self.interpreter_path = interpreter_path
    
    def execute_code(self, code: str, timeout: int = 10) -> Tuple[bool, str, float]:
        """Execute AIGo code and return success, output, and execution time"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.aigo', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            # Execute using Python subprocess
            start_time = time.time()
            result = subprocess.run(
                ['python3', '-c', f'''
from enhanced_aigo_interpreter import run_aigo_code
with open("{temp_file}", "r") as f:
    code = f.read()
run_aigo_code(code, show_stats=False)
                '''],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=os.path.dirname(os.path.abspath(self.interpreter_path))
            )
            execution_time = time.time() - start_time
            
            # Clean up
            os.unlink(temp_file)
            
            success = result.returncode == 0
            output = result.stdout if success else result.stderr
            
            return success, output, execution_time
            
        except subprocess.TimeoutExpired:
            return False, "Execution timeout", timeout
        except Exception as e:
            return False, f"Execution error: {str(e)}", 0.0

class AIGoEvaluator:
    """Main evaluation system for AIGo-trained models"""
    
    def __init__(self, interpreter_path: str = "./enhanced_aigo_interpreter.py"):
        self.syntax_checker = AIGoSyntaxChecker()
        self.code_executor = AIGoCodeExecutor(interpreter_path)
        self.evaluation_results = []
    
    def evaluate_single_generation(self, prompt: str, generated_code: str, 
                                 expected_output: Optional[str] = None) -> EvaluationResult:
        """Evaluate a single code generation"""
        metrics = {}
        errors = []
        execution_time = None
        memory_usage = None
        
        # 1. Syntax Correctness
        syntax_ok, syntax_errors = self.syntax_checker.check_syntax(generated_code)
        metrics[EvaluationMetric.SYNTAX_CORRECTNESS.value] = 1.0 if syntax_ok else 0.0
        errors.extend(syntax_errors)
        
        # 2. AIGo Idiom Usage
        idiom_score = self.syntax_checker.check_aigo_idioms(generated_code)
        metrics[EvaluationMetric.AIGO_IDIOM_USAGE.value] = idiom_score
        
        # 3. Compilation Success (same as syntax for interpreted language)
        metrics[EvaluationMetric.COMPILATION_SUCCESS.value] = metrics[EvaluationMetric.SYNTAX_CORRECTNESS.value]
        
        # 4. Execution Success
        if syntax_ok:
            exec_success, exec_output, exec_time = self.code_executor.execute_code(generated_code)
            metrics[EvaluationMetric.EXECUTION_SUCCESS.value] = 1.0 if exec_success else 0.0
            execution_time = exec_time
            if not exec_success:
                errors.append(f"Execution failed: {exec_output}")
        else:
            metrics[EvaluationMetric.EXECUTION_SUCCESS.value] = 0.0
        
        # 5. Instruction Following
        instruction_score = self._evaluate_instruction_following(prompt, generated_code)
        metrics[EvaluationMetric.INSTRUCTION_FOLLOWING.value] = instruction_score
        
        # 6. Code Quality
        quality_score = self._evaluate_code_quality(generated_code)
        metrics[EvaluationMetric.CODE_QUALITY.value] = quality_score
        
        # 7. Performance Efficiency (basic heuristic)
        perf_score = self._evaluate_performance(generated_code, execution_time)
        metrics[EvaluationMetric.PERFORMANCE_EFFICIENCY.value] = perf_score
        
        # 8. Semantic Correctness (heuristic based on execution and expected output)
        semantic_score = self._evaluate_semantic_correctness(generated_code, expected_output, exec_output if syntax_ok else None)
        metrics[EvaluationMetric.SEMANTIC_CORRECTNESS.value] = semantic_score
        
        return EvaluationResult(
            prompt=prompt,
            generated_code=generated_code,
            expected_output=expected_output,
            metrics=metrics,
            errors=errors,
            execution_time=execution_time,
            memory_usage=memory_usage
        )
    
    def _evaluate_instruction_following(self, prompt: str, code: str) -> float:
        """Evaluate how well the code follows the instruction"""
        score = 0.0
        total_checks = 0
        
        prompt_lower = prompt.lower()
        code_lower = code.lower()
        
        # Check for specific function names mentioned in prompt
        if 'factorial' in prompt_lower:
            total_checks += 1
            if 'factorial' in code_lower:
                score += 1
        
        if 'sort' in prompt_lower:
            total_checks += 1
            if 'sort' in code_lower or 'bubble' in code_lower:
                score += 1
        
        if 'search' in prompt_lower:
            total_checks += 1
            if 'search' in code_lower or 'binary' in code_lower:
                score += 1
        
        if 'maximum' in prompt_lower or 'max' in prompt_lower:
            total_checks += 1
            if 'max' in code_lower:
                score += 1
        
        # Check for function declaration if prompt asks for function
        if 'function' in prompt_lower:
            total_checks += 1
            if 'fn ' in code:
                score += 1
        
        # Default check: code is not empty and has some structure
        if total_checks == 0:
            total_checks = 1
            if len(code.strip()) > 10 and 'fn ' in code:
                score = 1
        
        return score / total_checks if total_checks > 0 else 0.0
    
    def _evaluate_code_quality(self, code: str) -> float:
        """Evaluate overall code quality"""
        score = 0.0
        total_checks = 5
        
        # Check for proper indentation
        lines = code.split('\n')
        indented_lines = [line for line in lines if line.strip() and line.startswith('    ')]
        if len(indented_lines) > 0:
            score += 1
        
        # Check for meaningful variable names (not single letters)
        var_pattern = r'let\s+(\w+)'
        variables = re.findall(var_pattern, code)
        meaningful_vars = [var for var in variables if len(var) > 2]
        if len(meaningful_vars) >= len(variables) * 0.7:
            score += 1
        
        # Check for proper function structure
        if re.search(r'fn\s+\w+\([^)]*\)[^{]*\{[^}]+\}', code, re.DOTALL):
            score += 1
        
        # Check for error handling
        if '?' in code or 'Result<' in code:
            score += 1
        
        # Check for type annotations
        if re.search(r':\s*\w+', code):
            score += 1
        
        return score / total_checks
    
    def _evaluate_performance(self, code: str, execution_time: Optional[float]) -> float:
        """Evaluate performance efficiency"""
        if execution_time is None:
            return 0.5  # Neutral score if no execution time
        
        # Simple heuristic: faster is better, but also consider code complexity
        lines_of_code = len([line for line in code.split('\n') if line.strip()])
        
        # Normalize execution time (assuming good performance is < 1 second)
        time_score = max(0, 1 - execution_time) if execution_time < 1 else 0
        
        # Consider algorithmic efficiency based on code patterns
        efficiency_score = 0.5  # Default
        if 'while' in code and 'while' in code:  # Nested loops might be less efficient
            nested_loops = len(re.findall(r'while[^{]*\{[^}]*while', code, re.DOTALL))
            if nested_loops > 0:
                efficiency_score = 0.3
        elif 'while' in code:
            efficiency_score = 0.7
        else:
            efficiency_score = 0.8
        
        return (time_score + efficiency_score) / 2
    
    def _evaluate_semantic_correctness(self, code: str, expected_output: Optional[str], 
                                     actual_output: Optional[str]) -> float:
        """Evaluate semantic correctness"""
        if expected_output is None:
            # Heuristic evaluation based on code structure
            if actual_output is not None and "error" not in actual_output.lower():
                return 0.8  # Assume correct if no errors
            return 0.5
        
        if actual_output is None:
            return 0.0
        
        # Simple string comparison (could be enhanced with more sophisticated matching)
        if expected_output.strip() == actual_output.strip():
            return 1.0
        
        # Partial matching
        expected_lines = expected_output.strip().split('\n')
        actual_lines = actual_output.strip().split('\n')
        
        matching_lines = 0
        for exp_line in expected_lines:
            if any(exp_line.strip() in act_line for act_line in actual_lines):
                matching_lines += 1
        
        return matching_lines / len(expected_lines) if expected_lines else 0.0
    
    def evaluate_dataset(self, test_cases: List[Dict[str, str]]) -> Dict[str, Any]:
        """Evaluate a complete dataset of test cases"""
        logger.info(f"Evaluating {len(test_cases)} test cases...")
        
        self.evaluation_results = []
        
        for i, test_case in enumerate(test_cases):
            logger.info(f"Evaluating test case {i+1}/{len(test_cases)}")
            
            prompt = test_case.get("instruction", "")
            generated_code = test_case.get("output", "")
            expected_output = test_case.get("expected_output")
            
            result = self.evaluate_single_generation(prompt, generated_code, expected_output)
            self.evaluation_results.append(result)
        
        # Aggregate results
        return self._aggregate_results()
    
    def _aggregate_results(self) -> Dict[str, Any]:
        """Aggregate evaluation results"""
        if not self.evaluation_results:
            return {}
        
        # Calculate average metrics
        metric_sums = {}
        metric_counts = {}
        
        for result in self.evaluation_results:
            for metric, value in result.metrics.items():
                metric_sums[metric] = metric_sums.get(metric, 0) + value
                metric_counts[metric] = metric_counts.get(metric, 0) + 1
        
        avg_metrics = {
            metric: metric_sums[metric] / metric_counts[metric]
            for metric in metric_sums
        }
        
        # Calculate overall score
        overall_score = sum(avg_metrics.values()) / len(avg_metrics)
        
        # Count successful cases
        successful_syntax = sum(1 for r in self.evaluation_results if r.metrics.get(EvaluationMetric.SYNTAX_CORRECTNESS.value, 0) > 0.5)
        successful_execution = sum(1 for r in self.evaluation_results if r.metrics.get(EvaluationMetric.EXECUTION_SUCCESS.value, 0) > 0.5)
        
        # Calculate execution time statistics
        execution_times = [r.execution_time for r in self.evaluation_results if r.execution_time is not None]
        avg_execution_time = sum(execution_times) / len(execution_times) if execution_times else 0
        
        return {
            "total_test_cases": len(self.evaluation_results),
            "overall_score": overall_score,
            "average_metrics": avg_metrics,
            "success_rates": {
                "syntax_correctness": successful_syntax / len(self.evaluation_results),
                "execution_success": successful_execution / len(self.evaluation_results)
            },
            "performance_stats": {
                "average_execution_time": avg_execution_time,
                "total_execution_time": sum(execution_times) if execution_times else 0
            },
            "detailed_results": [
                {
                    "prompt": r.prompt[:100] + "..." if len(r.prompt) > 100 else r.prompt,
                    "metrics": r.metrics,
                    "errors": r.errors,
                    "execution_time": r.execution_time
                }
                for r in self.evaluation_results
            ]
        }
    
    def generate_evaluation_report(self, output_path: str = "aigo_evaluation_report.json"):
        """Generate comprehensive evaluation report"""
        if not self.evaluation_results:
            logger.error("No evaluation results to report")
            return
        
        aggregated = self._aggregate_results()
        
        # Save to JSON
        with open(output_path, 'w') as f:
            json.dump(aggregated, f, indent=2)
        
        logger.info(f"Evaluation report saved to {output_path}")
        
        # Print summary
        print("\n" + "="*60)
        print("AIGo Model Evaluation Report")
        print("="*60)
        print(f"Total test cases: {aggregated['total_test_cases']}")
        print(f"Overall score: {aggregated['overall_score']:.3f}")
        print("\nAverage Metrics:")
        for metric, value in aggregated['average_metrics'].items():
            print(f"  {metric}: {value:.3f}")
        print("\nSuccess Rates:")
        for metric, value in aggregated['success_rates'].items():
            print(f"  {metric}: {value:.1%}")
        print(f"\nAverage execution time: {aggregated['performance_stats']['average_execution_time']:.3f}s")
        print("="*60)

def main():
    """Main function to run evaluation"""
    import time
    
    # Load test dataset
    with open("aigo_synthetic_dataset.json", "r") as f:
        test_cases = json.load(f)
    
    # Initialize evaluator
    evaluator = AIGoEvaluator()
    
    # Run evaluation
    results = evaluator.evaluate_dataset(test_cases)
    
    # Generate report
    evaluator.generate_evaluation_report()

if __name__ == "__main__":
    main()

