#!/usr/bin/env python3
"""
AI-to-Machine Code Paradigması Karşılaştırmalı Analiz ve Görselleştirme
"""

import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Rectangle
import pandas as pd

# Set style for better looking plots
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

def load_simulation_results():
    """Simülasyon sonuçlarını yükler"""
    with open('/home/ubuntu/simulation_results.json', 'r') as f:
        return json.load(f)

def create_performance_comparison():
    """Performans karşılaştırma grafikleri oluşturur"""
    results = load_simulation_results()
    
    # Architecture comparison
    architectures = list(results.keys())
    scenarios = ['scenario_1', 'scenario_2', 'scenario_3']
    scenario_names = ['Sort 10K integers', 'Matrix 500x500', 'Binary Search 1M']
    
    # Performance metrics
    metrics = ['execution_time', 'instructions_per_second', 'cache_miss_rate', 
               'branch_prediction_accuracy', 'energy_consumption']
    
    # Create subplots
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    fig.suptitle('AI-to-Machine Code Paradigması: Performans Karşılaştırması', fontsize=16, fontweight='bold')
    
    # Execution Time Comparison
    ax = axes[0, 0]
    exec_times = []
    for arch in architectures:
        arch_times = []
        for scenario in scenarios:
            arch_times.append(results[arch][scenario]['performance']['execution_time'] * 1000)  # Convert to ms
        exec_times.append(arch_times)
    
    x = np.arange(len(scenario_names))
    width = 0.25
    
    for i, (arch, times) in enumerate(zip(architectures, exec_times)):
        ax.bar(x + i*width, times, width, label=arch.upper(), alpha=0.8)
    
    ax.set_xlabel('Senaryolar')
    ax.set_ylabel('Çalışma Süresi (ms)')
    ax.set_title('Çalışma Süresi Karşılaştırması')
    ax.set_xticks(x + width)
    ax.set_xticklabels(scenario_names, rotation=45, ha='right')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Instructions Per Second
    ax = axes[0, 1]
    ips_data = []
    for arch in architectures:
        arch_ips = []
        for scenario in scenarios:
            arch_ips.append(results[arch][scenario]['performance']['instructions_per_second'] / 1e9)  # Convert to GIPS
        ips_data.append(arch_ips)
    
    for i, (arch, ips) in enumerate(zip(architectures, ips_data)):
        ax.bar(x + i*width, ips, width, label=arch.upper(), alpha=0.8)
    
    ax.set_xlabel('Senaryolar')
    ax.set_ylabel('Milyar Instruction/Saniye')
    ax.set_title('Instruction Throughput')
    ax.set_xticks(x + width)
    ax.set_xticklabels(scenario_names, rotation=45, ha='right')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Cache Miss Rate
    ax = axes[0, 2]
    cache_data = []
    for arch in architectures:
        arch_cache = []
        for scenario in scenarios:
            arch_cache.append(results[arch][scenario]['performance']['cache_miss_rate'] * 100)
        cache_data.append(arch_cache)
    
    for i, (arch, cache) in enumerate(zip(architectures, cache_data)):
        ax.bar(x + i*width, cache, width, label=arch.upper(), alpha=0.8)
    
    ax.set_xlabel('Senaryolar')
    ax.set_ylabel('Cache Miss Oranı (%)')
    ax.set_title('Cache Miss Oranları')
    ax.set_xticks(x + width)
    ax.set_xticklabels(scenario_names, rotation=45, ha='right')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Branch Prediction Accuracy
    ax = axes[1, 0]
    branch_data = []
    for arch in architectures:
        arch_branch = []
        for scenario in scenarios:
            arch_branch.append(results[arch][scenario]['performance']['branch_prediction_accuracy'] * 100)
        branch_data.append(arch_branch)
    
    for i, (arch, branch) in enumerate(zip(architectures, branch_data)):
        ax.bar(x + i*width, branch, width, label=arch.upper(), alpha=0.8)
    
    ax.set_xlabel('Senaryolar')
    ax.set_ylabel('Branch Prediction Doğruluğu (%)')
    ax.set_title('Branch Prediction Performansı')
    ax.set_xticks(x + width)
    ax.set_xticklabels(scenario_names, rotation=45, ha='right')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Energy Consumption
    ax = axes[1, 1]
    energy_data = []
    for arch in architectures:
        arch_energy = []
        for scenario in scenarios:
            arch_energy.append(results[arch][scenario]['performance']['energy_consumption'])
        energy_data.append(arch_energy)
    
    for i, (arch, energy) in enumerate(zip(architectures, energy_data)):
        ax.bar(x + i*width, energy, width, label=arch.upper(), alpha=0.8)
    
    ax.set_xlabel('Senaryolar')
    ax.set_ylabel('Enerji Tüketimi (J)')
    ax.set_title('Enerji Verimliliği')
    ax.set_xticks(x + width)
    ax.set_xticklabels(scenario_names, rotation=45, ha='right')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Error Detection and Fixing
    ax = axes[1, 2]
    error_detected = []
    error_fixed = []
    
    for arch in architectures:
        detected = sum(results[arch][scenario]['errors_detected'] for scenario in scenarios)
        fixed = sum(results[arch][scenario]['errors_fixed'] for scenario in scenarios)
        error_detected.append(detected)
        error_fixed.append(fixed)
    
    x_arch = np.arange(len(architectures))
    ax.bar(x_arch - 0.2, error_detected, 0.4, label='Tespit Edilen', alpha=0.8)
    ax.bar(x_arch + 0.2, error_fixed, 0.4, label='Düzeltilen', alpha=0.8)
    
    ax.set_xlabel('Mimariler')
    ax.set_ylabel('Hata Sayısı')
    ax.set_title('Hata Tespit ve Düzeltme')
    ax.set_xticks(x_arch)
    ax.set_xticklabels([arch.upper() for arch in architectures])
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/performance_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_paradigm_comparison():
    """Geleneksel vs AI-to-Machine Code paradigması karşılaştırması"""
    
    # Comparison metrics
    metrics = [
        'Geliştirme Hızı',
        'Çalışma Performansı', 
        'Bellek Verimliliği',
        'Enerji Verimliliği',
        'Hata Oranı',
        'Debugging Kolaylığı',
        'Maintenance',
        'Güvenlik',
        'Portability',
        'Learning Curve'
    ]
    
    # Scores (1-10 scale)
    traditional_scores = [6, 7, 6, 6, 7, 9, 8, 8, 9, 8]
    ai_machine_scores = [10, 9, 9, 8, 9, 3, 4, 5, 6, 3]
    
    # Create radar chart
    angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
    angles += angles[:1]  # Complete the circle
    
    traditional_scores += traditional_scores[:1]
    ai_machine_scores += ai_machine_scores[:1]
    
    fig, ax = plt.subplots(figsize=(12, 10), subplot_kw=dict(projection='polar'))
    
    # Plot traditional paradigm
    ax.plot(angles, traditional_scores, 'o-', linewidth=2, label='Geleneksel Paradigma', color='blue')
    ax.fill(angles, traditional_scores, alpha=0.25, color='blue')
    
    # Plot AI-to-Machine paradigm
    ax.plot(angles, ai_machine_scores, 'o-', linewidth=2, label='AI-to-Machine Code', color='red')
    ax.fill(angles, ai_machine_scores, alpha=0.25, color='red')
    
    # Customize the chart
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics, fontsize=10)
    ax.set_ylim(0, 10)
    ax.set_yticks(range(0, 11, 2))
    ax.set_yticklabels(range(0, 11, 2))
    ax.grid(True)
    
    plt.title('Programlama Paradigmaları Karşılaştırması\n(Ölçek: 1-10)', 
              size=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/paradigm_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_timeline_projection():
    """AI-to-Machine Code paradigmasının gelişim timeline'ı"""
    
    years = np.array([2025, 2027, 2030, 2035, 2040])
    
    # Different adoption scenarios
    conservative = np.array([5, 15, 30, 50, 70])
    moderate = np.array([10, 25, 45, 70, 85])
    aggressive = np.array([15, 35, 60, 80, 95])
    
    plt.figure(figsize=(14, 8))
    
    plt.plot(years, conservative, 'o-', linewidth=3, label='Muhafazakar Senaryo', color='blue')
    plt.plot(years, moderate, 's-', linewidth=3, label='Orta Senaryo', color='green')
    plt.plot(years, aggressive, '^-', linewidth=3, label='Agresif Senaryo', color='red')
    
    # Fill areas
    plt.fill_between(years, conservative, alpha=0.3, color='blue')
    plt.fill_between(years, moderate, alpha=0.3, color='green')
    plt.fill_between(years, aggressive, alpha=0.3, color='red')
    
    # Add milestone annotations
    milestones = {
        2025: 'Proof of Concept\nDemonstrations',
        2027: 'First Commercial\nApplications',
        2030: 'Enterprise\nAdoption Begins',
        2035: 'Mainstream\nIntegration',
        2040: 'Industry\nStandard'
    }
    
    for year, milestone in milestones.items():
        plt.annotate(milestone, xy=(year, 50), xytext=(year, 80),
                    arrowprops=dict(arrowstyle='->', color='black', alpha=0.7),
                    ha='center', fontsize=9, bbox=dict(boxstyle="round,pad=0.3", 
                    facecolor='yellow', alpha=0.7))
    
    plt.xlabel('Yıl', fontsize=12)
    plt.ylabel('Benimsenme Oranı (%)', fontsize=12)
    plt.title('AI-to-Machine Code Paradigması Benimsenme Projeksiyonu', 
              fontsize=16, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=12)
    plt.xlim(2024, 2041)
    plt.ylim(0, 100)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/timeline_projection.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_architecture_efficiency_heatmap():
    """Mimari verimliliği heatmap'i"""
    results = load_simulation_results()
    
    # Create efficiency matrix
    architectures = ['X86_64', 'ARM64', 'RISC_V']
    scenarios = ['Sort', 'Matrix', 'Search']
    
    # Calculate efficiency scores (normalized)
    efficiency_matrix = []
    
    for arch in ['x86_64', 'arm64', 'risc_v']:
        arch_scores = []
        for i, scenario in enumerate(['scenario_1', 'scenario_2', 'scenario_3']):
            # Composite efficiency score
            perf = results[arch][scenario]['performance']
            
            # Normalize metrics (higher is better)
            ips_score = min(100, perf['instructions_per_second'] / 1e7)  # Scale to 0-100
            cache_score = (1 - perf['cache_miss_rate']) * 100
            branch_score = perf['branch_prediction_accuracy'] * 100
            energy_score = max(0, 100 - perf['energy_consumption'] * 10)  # Lower energy is better
            
            # Weighted average
            efficiency = (ips_score * 0.4 + cache_score * 0.2 + 
                         branch_score * 0.2 + energy_score * 0.2)
            arch_scores.append(efficiency)
        
        efficiency_matrix.append(arch_scores)
    
    # Create heatmap
    plt.figure(figsize=(10, 8))
    
    sns.heatmap(efficiency_matrix, 
                xticklabels=scenarios,
                yticklabels=architectures,
                annot=True, 
                fmt='.1f',
                cmap='RdYlGn',
                center=50,
                square=True,
                linewidths=0.5,
                cbar_kws={'label': 'Verimlilik Skoru'})
    
    plt.title('CPU Mimarisi Verimlilik Analizi\n(AI-to-Machine Code Paradigması)', 
              fontsize=14, fontweight='bold')
    plt.xlabel('Senaryolar', fontsize=12)
    plt.ylabel('CPU Mimarileri', fontsize=12)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/architecture_efficiency.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_cost_benefit_analysis():
    """Maliyet-fayda analizi"""
    
    categories = ['Geliştirme\nMaliyeti', 'Donanım\nMaliyeti', 'Maintenance\nMaliyeti', 
                  'Training\nMaliyeti', 'Migration\nMaliyeti']
    
    traditional_costs = [100, 100, 100, 100, 0]  # Baseline
    ai_machine_costs = [150, 80, 60, 200, 300]  # AI paradigm costs
    
    benefits = ['Performans\nArtışı', 'Enerji\nTasarrufu', 'Hata\nAzalması', 
                'Geliştirme\nHızı', 'Optimizasyon']
    
    benefit_values = [300, 250, 200, 400, 350]  # Percentage improvements
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
    
    # Cost comparison
    x = np.arange(len(categories))
    width = 0.35
    
    ax1.bar(x - width/2, traditional_costs, width, label='Geleneksel', alpha=0.8, color='blue')
    ax1.bar(x + width/2, ai_machine_costs, width, label='AI-to-Machine', alpha=0.8, color='red')
    
    ax1.set_xlabel('Maliyet Kategorileri')
    ax1.set_ylabel('Relatif Maliyet (%)')
    ax1.set_title('Maliyet Karşılaştırması')
    ax1.set_xticks(x)
    ax1.set_xticklabels(categories)
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Benefits
    ax2.bar(benefits, benefit_values, alpha=0.8, color='green')
    ax2.set_xlabel('Fayda Kategorileri')
    ax2.set_ylabel('İyileştirme (%)')
    ax2.set_title('AI-to-Machine Code Faydaları')
    ax2.grid(True, alpha=0.3)
    
    # Add value labels on bars
    for i, v in enumerate(benefit_values):
        ax2.text(i, v + 10, f'{v}%', ha='center', fontweight='bold')
    
    plt.suptitle('AI-to-Machine Code Paradigması: Maliyet-Fayda Analizi', 
                 fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig('/home/ubuntu/cost_benefit_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()

def generate_summary_statistics():
    """Özet istatistikler oluşturur"""
    results = load_simulation_results()
    
    summary = {
        'total_instructions_generated': 0,
        'average_generation_time': 0,
        'total_errors_detected': 0,
        'total_errors_fixed': 0,
        'average_performance_gain': 0,
        'architecture_performance': {}
    }
    
    total_scenarios = 0
    total_gen_time = 0
    
    for arch, scenarios in results.items():
        arch_performance = []
        arch_errors_detected = 0
        arch_errors_fixed = 0
        
        for scenario, data in scenarios.items():
            summary['total_instructions_generated'] += data['instruction_count']
            total_gen_time += data['generation_time']
            summary['total_errors_detected'] += data['errors_detected']
            summary['total_errors_fixed'] += data['errors_fixed']
            
            arch_errors_detected += data['errors_detected']
            arch_errors_fixed += data['errors_fixed']
            
            # Performance score calculation
            perf = data['performance']
            perf_score = (perf['instructions_per_second'] / 1e9 * 10 +
                         (1 - perf['cache_miss_rate']) * 100 +
                         perf['branch_prediction_accuracy'] * 100) / 3
            arch_performance.append(perf_score)
            
            total_scenarios += 1
        
        summary['architecture_performance'][arch] = {
            'average_performance': np.mean(arch_performance),
            'errors_detected': arch_errors_detected,
            'errors_fixed': arch_errors_fixed,
            'fix_rate': arch_errors_fixed / max(arch_errors_detected, 1)
        }
    
    summary['average_generation_time'] = total_gen_time / total_scenarios
    summary['overall_fix_rate'] = summary['total_errors_fixed'] / max(summary['total_errors_detected'], 1)
    
    # Save summary
    with open('/home/ubuntu/analysis_summary.json', 'w') as f:
        json.dump(summary, f, indent=2)
    
    return summary

if __name__ == "__main__":
    print("AI-to-Machine Code Paradigması: Karşılaştırmalı Analiz ve Görselleştirme")
    print("=" * 70)
    
    # Generate all visualizations
    print("Performans karşılaştırma grafikleri oluşturuluyor...")
    create_performance_comparison()
    
    print("Paradigma karşılaştırma radar grafiği oluşturuluyor...")
    create_paradigm_comparison()
    
    print("Gelişim timeline projeksiyonu oluşturuluyor...")
    create_timeline_projection()
    
    print("Mimari verimlilik heatmap'i oluşturuluyor...")
    create_architecture_efficiency_heatmap()
    
    print("Maliyet-fayda analizi oluşturuluyor...")
    create_cost_benefit_analysis()
    
    print("Özet istatistikler hesaplanıyor...")
    summary = generate_summary_statistics()
    
    print("\n--- ÖZET İSTATİSTİKLER ---")
    print(f"Toplam üretilen instruction: {summary['total_instructions_generated']:,}")
    print(f"Ortalama üretim süresi: {summary['average_generation_time']:.4f} saniye")
    print(f"Toplam tespit edilen hata: {summary['total_errors_detected']}")
    print(f"Toplam düzeltilen hata: {summary['total_errors_fixed']}")
    print(f"Genel düzeltme oranı: {summary['overall_fix_rate']:.2%}")
    
    print("\n--- MİMARİ PERFORMANSLARI ---")
    for arch, perf in summary['architecture_performance'].items():
        print(f"{arch.upper()}:")
        print(f"  Ortalama performans skoru: {perf['average_performance']:.1f}")
        print(f"  Hata düzeltme oranı: {perf['fix_rate']:.2%}")
    
    print("\nTüm analizler tamamlandı! Grafikler kaydedildi.")

