#!/usr/bin/env python3
"""
AIGo LLM Training Pipeline
Complete training infrastructure for teaching LLMs the AIGo programming language
"""

import json
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoTokenizer, AutoModelForCausalLM, 
    TrainingArguments, Trainer, 
    DataCollatorForLanguageModeling
)
import numpy as np
from typing import Dict, List, Any, Optional
import logging
import os
from datetime import datetime
import wandb
from sklearn.model_selection import train_test_split

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AIGoDataset(Dataset):
    """Custom dataset for AIGo training data"""
    
    def __init__(self, data: List[Dict], tokenizer, max_length: int = 512):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        # Format the input-output pair for instruction following
        if item.get("input"):
            text = f"### Instruction:\n{item['instruction']}\n\n### Input:\n{item['input']}\n\n### Response:\n{item['output']}"
        else:
            text = f"### Instruction:\n{item['instruction']}\n\n### Response:\n{item['output']}"
        
        # Tokenize
        encoding = self.tokenizer(
            text,
            truncation=True,
            padding="max_length",
            max_length=self.max_length,
            return_tensors="pt"
        )
        
        return {
            "input_ids": encoding["input_ids"].flatten(),
            "attention_mask": encoding["attention_mask"].flatten(),
            "labels": encoding["input_ids"].flatten()
        }

class AIGoTrainingPipeline:
    """Complete training pipeline for AIGo LLM"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model = None
        self.tokenizer = None
        self.train_dataset = None
        self.eval_dataset = None
        self.trainer = None
        
        # Initialize wandb for experiment tracking
        if config.get("use_wandb", False):
            wandb.init(
                project="aigo-llm-training",
                config=config,
                name=f"aigo-training-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            )
    
    def load_model_and_tokenizer(self):
        """Load the base model and tokenizer"""
        model_name = self.config["model_name"]
        logger.info(f"Loading model and tokenizer: {model_name}")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load model
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16 if self.config.get("use_fp16", True) else torch.float32,
            device_map="auto" if torch.cuda.is_available() else None,
            trust_remote_code=True
        )
        
        # Add AIGo-specific tokens to vocabulary
        aigo_tokens = [
            "module", "import", "fn", "let", "return", "if", "else", "while",
            "i32", "f64", "string", "bool", "void", "Array", "Result", "Error",
            "Ok", "Err", "println", "print", "input", "array_new", "array_push",
            "array_pop", "array_len", "array_get", "array_set", "abs", "min",
            "max", "sqrt", "time", "random", "range"
        ]
        
        # Add new tokens
        new_tokens = [token for token in aigo_tokens if token not in self.tokenizer.vocab]
        if new_tokens:
            logger.info(f"Adding {len(new_tokens)} new AIGo tokens to vocabulary")
            self.tokenizer.add_tokens(new_tokens)
            self.model.resize_token_embeddings(len(self.tokenizer))
        
        logger.info("Model and tokenizer loaded successfully")
    
    def load_dataset(self, dataset_path: str):
        """Load and prepare the training dataset"""
        logger.info(f"Loading dataset from {dataset_path}")
        
        with open(dataset_path, 'r') as f:
            data = json.load(f)
        
        # Split into train and validation sets
        train_data, eval_data = train_test_split(
            data, 
            test_size=self.config.get("eval_split", 0.1),
            random_state=42
        )
        
        logger.info(f"Dataset split: {len(train_data)} train, {len(eval_data)} eval samples")
        
        # Create datasets
        self.train_dataset = AIGoDataset(
            train_data, 
            self.tokenizer, 
            max_length=self.config.get("max_length", 512)
        )
        self.eval_dataset = AIGoDataset(
            eval_data, 
            self.tokenizer, 
            max_length=self.config.get("max_length", 512)
        )
        
        logger.info("Dataset loaded and prepared successfully")
    
    def setup_training_arguments(self):
        """Setup training arguments"""
        return TrainingArguments(
            output_dir=self.config.get("output_dir", "./aigo-model-output"),
            overwrite_output_dir=True,
            num_train_epochs=self.config.get("num_epochs", 3),
            per_device_train_batch_size=self.config.get("train_batch_size", 4),
            per_device_eval_batch_size=self.config.get("eval_batch_size", 4),
            gradient_accumulation_steps=self.config.get("gradient_accumulation_steps", 4),
            warmup_steps=self.config.get("warmup_steps", 100),
            learning_rate=self.config.get("learning_rate", 5e-5),
            fp16=self.config.get("use_fp16", True),
            logging_steps=self.config.get("logging_steps", 10),
            evaluation_strategy="steps",
            eval_steps=self.config.get("eval_steps", 100),
            save_steps=self.config.get("save_steps", 500),
            save_total_limit=self.config.get("save_total_limit", 3),
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            report_to="wandb" if self.config.get("use_wandb", False) else None,
            run_name=f"aigo-training-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
            dataloader_num_workers=self.config.get("num_workers", 4),
            remove_unused_columns=False,
        )
    
    def setup_trainer(self):
        """Setup the Hugging Face Trainer"""
        training_args = self.setup_training_arguments()
        
        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False,  # We're doing causal language modeling, not masked LM
        )
        
        # Initialize trainer
        self.trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            data_collator=data_collator,
            tokenizer=self.tokenizer,
        )
        
        logger.info("Trainer setup completed")
    
    def train(self):
        """Start the training process"""
        logger.info("Starting training...")
        
        # Train the model
        self.trainer.train()
        
        # Save the final model
        final_output_dir = os.path.join(self.config.get("output_dir", "./aigo-model-output"), "final")
        self.trainer.save_model(final_output_dir)
        self.tokenizer.save_pretrained(final_output_dir)
        
        logger.info(f"Training completed. Model saved to {final_output_dir}")
    
    def evaluate(self):
        """Evaluate the trained model"""
        logger.info("Evaluating model...")
        
        eval_results = self.trainer.evaluate()
        
        logger.info("Evaluation results:")
        for key, value in eval_results.items():
            logger.info(f"  {key}: {value}")
        
        return eval_results
    
    def generate_sample(self, prompt: str, max_length: int = 200):
        """Generate a sample output for testing"""
        self.model.eval()
        
        inputs = self.tokenizer(prompt, return_tensors="pt")
        if torch.cuda.is_available():
            inputs = {k: v.cuda() for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                num_return_sequences=1,
                temperature=0.7,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return generated_text
    
    def run_full_pipeline(self, dataset_path: str):
        """Run the complete training pipeline"""
        logger.info("Starting AIGo LLM Training Pipeline")
        
        # Load model and tokenizer
        self.load_model_and_tokenizer()
        
        # Load dataset
        self.load_dataset(dataset_path)
        
        # Setup trainer
        self.setup_trainer()
        
        # Train
        self.train()
        
        # Evaluate
        eval_results = self.evaluate()
        
        # Test generation
        test_prompt = "### Instruction:\nWrite a simple AIGo function that calculates the factorial of a number.\n\n### Response:\n"
        generated = self.generate_sample(test_prompt)
        logger.info(f"Sample generation:\n{generated}")
        
        logger.info("Pipeline completed successfully!")
        return eval_results

class AIGoTrainingConfig:
    """Configuration management for AIGo training"""
    
    @staticmethod
    def get_default_config():
        """Get default training configuration"""
        return {
            # Model configuration
            "model_name": "microsoft/DialoGPT-medium",  # Smaller model for testing
            "max_length": 512,
            "use_fp16": True,
            
            # Training configuration
            "num_epochs": 3,
            "train_batch_size": 4,
            "eval_batch_size": 4,
            "gradient_accumulation_steps": 4,
            "learning_rate": 5e-5,
            "warmup_steps": 100,
            
            # Data configuration
            "eval_split": 0.1,
            
            # Logging and saving
            "output_dir": "./aigo-model-output",
            "logging_steps": 10,
            "eval_steps": 100,
            "save_steps": 500,
            "save_total_limit": 3,
            "num_workers": 4,
            
            # Experiment tracking
            "use_wandb": False,  # Set to True if you have wandb configured
        }
    
    @staticmethod
    def get_production_config():
        """Get production-ready training configuration"""
        config = AIGoTrainingConfig.get_default_config()
        config.update({
            "model_name": "codellama/CodeLlama-7b-hf",  # Better for code generation
            "num_epochs": 5,
            "train_batch_size": 8,
            "gradient_accumulation_steps": 2,
            "learning_rate": 2e-5,
            "max_length": 1024,
            "warmup_steps": 500,
            "eval_steps": 200,
            "save_steps": 1000,
            "use_wandb": True,
        })
        return config

def main():
    """Main function to run the training pipeline"""
    # Get configuration
    config = AIGoTrainingConfig.get_default_config()
    
    # Initialize pipeline
    pipeline = AIGoTrainingPipeline(config)
    
    # Run training
    dataset_path = "aigo_synthetic_dataset.json"
    if os.path.exists(dataset_path):
        results = pipeline.run_full_pipeline(dataset_path)
        print("Training completed successfully!")
        print("Evaluation results:", results)
    else:
        print(f"Dataset file {dataset_path} not found. Please run the dataset generator first.")

if __name__ == "__main__":
    main()

