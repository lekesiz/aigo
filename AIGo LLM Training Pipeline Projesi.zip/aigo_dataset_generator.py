#!/usr/bin/env python3
"""
AIGo Synthetic Training Dataset Generator
Generates diverse training data for LLMs to learn AIGo
"""

import random
import json
import string
from typing import List, Dict, Any

class AIGoDatasetGenerator:
    def __init__(self, num_samples: int = 10000):
        self.num_samples = num_samples
        self.dataset = []
        self.primitive_types = ["i32", "f64", "string", "bool", "void"]
        self.complex_types = ["Array<i32>", "Array<string>", "Result<i32, Error>"]
        self.keywords = ["let", "fn", "return", "if", "else", "while", "module", "import"]
        self.operators = ["+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">=", "&&", "||", "!", "?", "="]
        self.builtins = ["println", "print", "input", "Ok", "Err", "array_new", "array_push", "array_pop", "array_len", "array_get", "array_set", "abs", "min", "max", "sqrt", "time", "random", "range"]
    
    def generate_identifier(self, length: int = 5) -> str:
        """Generate a random identifier"""
        return "".join(random.choice(string.ascii_lowercase) for _ in range(length))
    
    def generate_primitive_value(self, type_name: str) -> Any:
        """Generate a random value for a primitive type"""
        if type_name == "i32":
            return random.randint(-1000, 1000)
        elif type_name == "f64":
            return round(random.uniform(-1000.0, 1000.0), 2)
        elif type_name == "string":
            return f"\"{self.generate_identifier(random.randint(3, 10))}\""
        elif type_name == "bool":
            return random.choice(["true", "false"])
        elif type_name == "void":
            return "void"
        return "null" # Should not happen
    
    def generate_expression(self, depth: int = 0) -> str:
        """Generate a random AIGo expression"""
        if depth > 3 or random.random() < 0.3:
            # Base case: literal or identifier
            if random.random() < 0.7:
                ptype = random.choice(self.primitive_types[:-1]) # Exclude void
                return str(self.generate_primitive_value(ptype))
            else:
                return self.generate_identifier()
        
        choice = random.random()
        if choice < 0.4: # Binary operation
            op = random.choice(self.operators[:-3]) # Exclude !, ?, =
            left = self.generate_expression(depth + 1)
            right = self.generate_expression(depth + 1)
            return f"{left} {op} {right}"
        elif choice < 0.6: # Unary operation
            op = random.choice(["-", "!"])
            operand = self.generate_expression(depth + 1)
            return f"{op}{operand}"
        elif choice < 0.8: # Function call
            func_name = random.choice(self.builtins)
            num_args = random.randint(0, 3)
            args = ", ".join([self.generate_expression(depth + 1) for _ in range(num_args)])
            return f"{func_name}({args})"
        else: # Error propagation
            expr = self.generate_expression(depth + 1)
            return f"{expr}?"
    
    def generate_statement(self, depth: int = 0) -> str:
        """Generate a random AIGo statement"""
        choice = random.random()
        indent = "    " * depth
        
        if choice < 0.3: # Variable declaration
            var_name = self.generate_identifier()
            var_type = random.choice(self.primitive_types + self.complex_types)
            if random.random() < 0.7:
                value = self.generate_expression()
                return f"{indent}let {var_name}: {var_type} = {value}"
            else:
                return f"{indent}let {var_name}: {var_type}"
        elif choice < 0.5: # Assignment
            target = self.generate_identifier()
            value = self.generate_expression()
            return f"{indent}{target} = {value}"
        elif choice < 0.7: # Expression statement (usually function call)
            expr = self.generate_expression()
            return f"{indent}{expr}"
        elif choice < 0.8: # Return statement
            if random.random() < 0.8:
                value = self.generate_expression()
                return f"{indent}return {value}"
            else:
                return f"{indent}return"
        elif choice < 0.9 and depth < 2: # If statement
            condition = self.generate_expression()
            then_block = "\n".join([self.generate_statement(depth + 1) for _ in range(random.randint(1, 3))])
            if random.random() < 0.5:
                else_block = "\n".join([self.generate_statement(depth + 1) for _ in range(random.randint(1, 3))])
                return f"{indent}if {condition} {{\n{then_block}\n{indent}}} else {{\n{else_block}\n{indent}}}"
            else:
                return f"{indent}if {condition} {{\n{then_block}\n{indent}}}"
        elif depth < 2: # While statement
            condition = self.generate_expression()
            body = "\n".join([self.generate_statement(depth + 1) for _ in range(random.randint(1, 3))])
            return f"{indent}while {condition} {{\n{body}\n{indent}}}"
        else: # Fallback to simple expression statement
            expr = self.generate_expression()
            return f"{indent}{expr}"
    
    def generate_function(self) -> str:
        """Generate a random AIGo function"""
        func_name = self.generate_identifier()
        num_params = random.randint(0, 4)
        params = []
        for _ in range(num_params):
            param_name = self.generate_identifier()
            param_type = random.choice(self.primitive_types + self.complex_types)
            params.append(f"{param_name}: {param_type}")
        param_str = ", ".join(params)
        
        return_type = random.choice(self.primitive_types + self.complex_types)
        
        body = "\n".join([self.generate_statement(1) for _ in range(random.randint(2, 6))])
        
        return f"fn {func_name}({param_str}) -> {return_type} {{\n{body}\n}}"
    
    def generate_aigo_code_sample(self) -> str:
        """Generate a complete AIGo code sample"""
        code = f"module {self.generate_identifier()}\n\n"
        
        num_imports = random.randint(0, 2)
        for _ in range(num_imports):
            module = random.choice(["io", "math", "time"])
            code += f"import std.{module}\n"
        code += "\n"
        
        num_functions = random.randint(1, 4)
        for _ in range(num_functions):
            code += self.generate_function() + "\n\n"
            
        return code
    
    def generate_instruction_pair(self) -> Dict[str, str]:
        """Generate an instruction-code pair"""
        code = self.generate_aigo_code_sample()
        
        # Simple instruction generation based on code structure
        instruction_type = random.choice(["generate", "explain", "complete", "fix", "translate"])
        
        if instruction_type == "generate":
            # Extract function names and try to create a plausible task description
            func_names = [line.split("(")[0].split(" ")[-1] for line in code.split("\n") if line.strip().startswith("fn ")]
            if func_names:
                instruction = f"Write an AIGo program with functions named {', '.join(func_names)} that performs some calculations."
            else:
                instruction = "Write a simple AIGo program."
        elif instruction_type == "explain":
            instruction = f"Explain the following AIGo code:\n\n```aigo\n{code[:200]}...\n```"
        elif instruction_type == "complete":
            split_point = random.randint(len(code)//3, len(code)//2)
            partial_code = code[:split_point]
            instruction = f"Complete the following AIGo code:\n\n```aigo\n{partial_code}\n```"
        elif instruction_type == "fix":
            # Introduce a simple syntax error (e.g., missing semicolon, wrong keyword)
            lines = code.split("\n")
            if len(lines) > 5:
                line_num = random.randint(2, len(lines) - 2)
                if lines[line_num].strip():
                    original_line = lines[line_num]
                    # Simple error: replace a keyword or remove a character
                    if "let" in original_line:
                        lines[line_num] = original_line.replace("let", "var", 1)
                    elif "=" in original_line:
                        lines[line_num] = original_line.replace("=", ":", 1)
                    else:
                        lines[line_num] = original_line[:-1] # Remove last char
                    buggy_code = "\n".join(lines)
                    instruction = f"Fix the error in the following AIGo code:\n\n```aigo\n{buggy_code}\n```"
                else:
                    instruction = "Fix the error in the provided AIGo code." # Fallback
            else:
                 instruction = "Fix the error in the provided AIGo code." # Fallback
        elif instruction_type == "translate":
            # Placeholder for translation task
            instruction = f"Translate the following concept into AIGo code: [Concept Description Placeholder]"
        else:
            instruction = "Perform a task related to the following AIGo code."

        return {
            "instruction": instruction,
            "input": "", # Input can be empty if instruction contains the code
            "output": code # The generated/correct code is the output
        }

    def generate_dataset(self):
        """Generate the full dataset"""
        print(f"Generating {self.num_samples} synthetic AIGo training samples...")
        for i in range(self.num_samples):
            self.dataset.append(self.generate_instruction_pair())
            if (i + 1) % 1000 == 0:
                print(f"Generated {i + 1}/{self.num_samples} samples...")
        print("Dataset generation complete.")
        return self.dataset

    def save_dataset(self, filename: str = "aigo_synthetic_dataset.json"):
        """Save the generated dataset to a JSON file"""
        if not self.dataset:
            self.generate_dataset()
            
        print(f"Saving dataset to {filename}...")
        with open(filename, "w") as f:
            json.dump(self.dataset, f, indent=2)
        print("Dataset saved successfully.")

if __name__ == "__main__":
    generator = AIGoDatasetGenerator(num_samples=5000) # Generate 5k samples for demonstration
    generator.save_dataset()
    
    # Print a few samples
    print("\n--- Sample Data ---")
    for i in range(3):
        print(json.dumps(generator.dataset[i], indent=2))
        print("---")

