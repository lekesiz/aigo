#!/usr/bin/env python3
"""
Enhanced AIGo Language Interpreter
Advanced interpreter for executing complex AIGo programs with real-world algorithms
"""

from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass
import time
import sys
from aigo_lexer import Lexer
from aigo_parser import *

class AIGoValue:
    """Base class for AIGo runtime values"""
    pass

@dataclass
class IntValue(AIGoValue):
    value: int
    
    def __str__(self):
        return str(self.value)
    
    def to_python(self):
        return self.value

@dataclass
class FloatValue(AIGoValue):
    value: float
    
    def __str__(self):
        return str(self.value)
    
    def to_python(self):
        return self.value

@dataclass
class StringValue(AIGoValue):
    value: str
    
    def __str__(self):
        return self.value
    
    def to_python(self):
        return self.value

@dataclass
class BoolValue(AIGoValue):
    value: bool
    
    def __str__(self):
        return "true" if self.value else "false"
    
    def to_python(self):
        return self.value

@dataclass
class VoidValue(AIGoValue):
    def __str__(self):
        return "void"
    
    def to_python(self):
        return None

@dataclass
class ArrayValue(AIGoValue):
    elements: List[AIGoValue]
    
    def __str__(self):
        return "[" + ", ".join(str(elem) for elem in self.elements) + "]"
    
    def to_python(self):
        return [elem.to_python() for elem in self.elements]

@dataclass
class ResultValue(AIGoValue):
    is_ok: bool
    value: AIGoValue
    
    def __str__(self):
        if self.is_ok:
            return f"Ok({self.value})"
        else:
            return f"Err({self.value})"
    
    def to_python(self):
        return {"ok": self.is_ok, "value": self.value.to_python()}

class AIGoError(Exception):
    def __init__(self, message: str):
        self.message = message
        super().__init__(message)

class Environment:
    """Environment for variable bindings"""
    def __init__(self, parent: Optional['Environment'] = None):
        self.parent = parent
        self.bindings: Dict[str, AIGoValue] = {}
    
    def define(self, name: str, value: AIGoValue):
        self.bindings[name] = value
    
    def get(self, name: str) -> AIGoValue:
        if name in self.bindings:
            return self.bindings[name]
        elif self.parent:
            return self.parent.get(name)
        else:
            raise AIGoError(f"Undefined variable: {name}")
    
    def set(self, name: str, value: AIGoValue):
        if name in self.bindings:
            self.bindings[name] = value
        elif self.parent:
            self.parent.set(name, value)
        else:
            raise AIGoError(f"Undefined variable: {name}")

class ReturnException(Exception):
    """Exception used for return statement control flow"""
    def __init__(self, value: AIGoValue):
        self.value = value

class BreakException(Exception):
    """Exception used for break statement control flow"""
    pass

class ContinueException(Exception):
    """Exception used for continue statement control flow"""
    pass

@dataclass
class Function:
    name: str
    parameters: List[Parameter]
    body: List[Statement]
    closure: Environment

class EnhancedInterpreter:
    def __init__(self):
        self.global_env = Environment()
        self.current_env = self.global_env
        self.setup_builtins()
        self.execution_stats = {
            'operations': 0,
            'function_calls': 0,
            'start_time': None,
            'memory_usage': 0
        }
    
    def setup_builtins(self):
        """Setup built-in functions and values"""
        # I/O functions
        self.global_env.define("println", self.builtin_println)
        self.global_env.define("print", self.builtin_print)
        self.global_env.define("input", self.builtin_input)
        
        # Result constructors
        self.global_env.define("Ok", self.builtin_ok)
        self.global_env.define("Err", self.builtin_err)
        self.global_env.define("void", VoidValue())
        
        # Array functions
        self.global_env.define("array_new", self.builtin_array_new)
        self.global_env.define("array_push", self.builtin_array_push)
        self.global_env.define("array_pop", self.builtin_array_pop)
        self.global_env.define("array_len", self.builtin_array_len)
        self.global_env.define("array_get", self.builtin_array_get)
        self.global_env.define("array_set", self.builtin_array_set)
        
        # Math functions
        self.global_env.define("abs", self.builtin_abs)
        self.global_env.define("min", self.builtin_min)
        self.global_env.define("max", self.builtin_max)
        self.global_env.define("sqrt", self.builtin_sqrt)
        
        # Utility functions
        self.global_env.define("time", self.builtin_time)
        self.global_env.define("random", self.builtin_random)
        self.global_env.define("range", self.builtin_range)
    
    # Built-in I/O functions
    def builtin_println(self, *args):
        """Built-in println function"""
        output = " ".join(str(arg) for arg in args)
        print(output)
        return VoidValue()
    
    def builtin_print(self, *args):
        """Built-in print function (no newline)"""
        output = " ".join(str(arg) for arg in args)
        print(output, end="")
        return VoidValue()
    
    def builtin_input(self, prompt=None):
        """Built-in input function"""
        if prompt:
            result = input(str(prompt))
        else:
            result = input()
        return StringValue(result)
    
    # Result constructors
    def builtin_ok(self, value):
        """Built-in Ok constructor"""
        return ResultValue(True, value)
    
    def builtin_err(self, value):
        """Built-in Err constructor"""
        return ResultValue(False, value)
    
    # Array functions
    def builtin_array_new(self, size=None):
        """Create new array"""
        if size is None:
            return ArrayValue([])
        elif isinstance(size, IntValue):
            return ArrayValue([VoidValue() for _ in range(size.value)])
        else:
            raise AIGoError("Array size must be integer")
    
    def builtin_array_push(self, array, value):
        """Push value to array"""
        if isinstance(array, ArrayValue):
            array.elements.append(value)
            return array
        else:
            raise AIGoError("First argument must be array")
    
    def builtin_array_pop(self, array):
        """Pop value from array"""
        if isinstance(array, ArrayValue):
            if array.elements:
                return array.elements.pop()
            else:
                raise AIGoError("Cannot pop from empty array")
        else:
            raise AIGoError("Argument must be array")
    
    def builtin_array_len(self, array):
        """Get array length"""
        if isinstance(array, ArrayValue):
            return IntValue(len(array.elements))
        else:
            raise AIGoError("Argument must be array")
    
    def builtin_array_get(self, array, index):
        """Get array element"""
        if isinstance(array, ArrayValue) and isinstance(index, IntValue):
            if 0 <= index.value < len(array.elements):
                return array.elements[index.value]
            else:
                raise AIGoError(f"Array index out of bounds: {index.value}")
        else:
            raise AIGoError("Invalid array access")
    
    def builtin_array_set(self, array, index, value):
        """Set array element"""
        if isinstance(array, ArrayValue) and isinstance(index, IntValue):
            if 0 <= index.value < len(array.elements):
                array.elements[index.value] = value
                return array
            else:
                raise AIGoError(f"Array index out of bounds: {index.value}")
        else:
            raise AIGoError("Invalid array assignment")
    
    # Math functions
    def builtin_abs(self, value):
        """Absolute value"""
        if isinstance(value, IntValue):
            return IntValue(abs(value.value))
        elif isinstance(value, FloatValue):
            return FloatValue(abs(value.value))
        else:
            raise AIGoError("abs() requires numeric argument")
    
    def builtin_min(self, a, b):
        """Minimum of two values"""
        if isinstance(a, IntValue) and isinstance(b, IntValue):
            return IntValue(min(a.value, b.value))
        elif isinstance(a, FloatValue) and isinstance(b, FloatValue):
            return FloatValue(min(a.value, b.value))
        else:
            raise AIGoError("min() requires numeric arguments")
    
    def builtin_max(self, a, b):
        """Maximum of two values"""
        if isinstance(a, IntValue) and isinstance(b, IntValue):
            return IntValue(max(a.value, b.value))
        elif isinstance(a, FloatValue) and isinstance(b, FloatValue):
            return FloatValue(max(a.value, b.value))
        else:
            raise AIGoError("max() requires numeric arguments")
    
    def builtin_sqrt(self, value):
        """Square root"""
        import math
        if isinstance(value, IntValue):
            return FloatValue(math.sqrt(value.value))
        elif isinstance(value, FloatValue):
            return FloatValue(math.sqrt(value.value))
        else:
            raise AIGoError("sqrt() requires numeric argument")
    
    # Utility functions
    def builtin_time(self):
        """Get current time"""
        return FloatValue(time.time())
    
    def builtin_random(self, max_val=None):
        """Generate random number"""
        import random
        if max_val is None:
            return FloatValue(random.random())
        elif isinstance(max_val, IntValue):
            return IntValue(random.randint(0, max_val.value - 1))
        else:
            raise AIGoError("random() max value must be integer")
    
    def builtin_range(self, start, end=None, step=None):
        """Generate range of numbers"""
        if end is None:
            # range(n) -> 0 to n-1
            if isinstance(start, IntValue):
                elements = [IntValue(i) for i in range(start.value)]
                return ArrayValue(elements)
        else:
            # range(start, end, step)
            if isinstance(start, IntValue) and isinstance(end, IntValue):
                step_val = 1
                if step and isinstance(step, IntValue):
                    step_val = step.value
                elements = [IntValue(i) for i in range(start.value, end.value, step_val)]
                return ArrayValue(elements)
        
        raise AIGoError("Invalid range arguments")
    
    def evaluate_expression(self, expr: Expression) -> AIGoValue:
        """Evaluate expressions"""
        self.execution_stats['operations'] += 1
        
        if isinstance(expr, IntegerLiteral):
            return IntValue(expr.value)
        
        elif isinstance(expr, FloatLiteral):
            return FloatValue(expr.value)
        
        elif isinstance(expr, StringLiteral):
            return StringValue(expr.value)
        
        elif isinstance(expr, BooleanLiteral):
            return BoolValue(expr.value)
        
        elif isinstance(expr, Identifier):
            return self.current_env.get(expr.name)
        
        elif isinstance(expr, BinaryOperation):
            left = self.evaluate_expression(expr.left)
            right = self.evaluate_expression(expr.right)
            return self.evaluate_binary_operation(left, expr.operator, right)
        
        elif isinstance(expr, UnaryOperation):
            if expr.operator == "?":
                # Error propagation
                operand = self.evaluate_expression(expr.operand)
                if isinstance(operand, ResultValue) and not operand.is_ok:
                    raise ReturnException(operand)
                elif isinstance(operand, ResultValue):
                    return operand.value
                else:
                    return operand
            else:
                operand = self.evaluate_expression(expr.operand)
                return self.evaluate_unary_operation(expr.operator, operand)
        
        elif isinstance(expr, FunctionCall):
            function = self.evaluate_expression(expr.function)
            args = [self.evaluate_expression(arg) for arg in expr.arguments]
            return self.call_function(function, args)
        
        elif isinstance(expr, FieldAccess):
            # For now, treat field access as module access (e.g., io.println)
            obj = self.evaluate_expression(expr.object)
            if isinstance(obj, StringValue) and obj.value == "io":
                if expr.field == "println":
                    return self.global_env.get("println")
                elif expr.field == "print":
                    return self.global_env.get("print")
            raise AIGoError(f"Unknown field access: {expr.object}.{expr.field}")
        
        else:
            raise AIGoError(f"Unknown expression type: {type(expr)}")
    
    def evaluate_binary_operation(self, left: AIGoValue, operator: str, right: AIGoValue) -> AIGoValue:
        """Evaluate binary operations"""
        if operator == "+":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return IntValue(left.value + right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return FloatValue(left.value + right.value)
            elif isinstance(left, StringValue) and isinstance(right, StringValue):
                return StringValue(left.value + right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return FloatValue(left.value + right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return FloatValue(left.value + right.value)
        
        elif operator == "-":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return IntValue(left.value - right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return FloatValue(left.value - right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return FloatValue(left.value - right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return FloatValue(left.value - right.value)
        
        elif operator == "*":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return IntValue(left.value * right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return FloatValue(left.value * right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return FloatValue(left.value * right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return FloatValue(left.value * right.value)
        
        elif operator == "/":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                if right.value == 0:
                    raise AIGoError("Division by zero")
                return IntValue(left.value // right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                if right.value == 0:
                    raise AIGoError("Division by zero")
                return FloatValue(left.value / right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                if right.value == 0:
                    raise AIGoError("Division by zero")
                return FloatValue(left.value / right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                if right.value == 0:
                    raise AIGoError("Division by zero")
                return FloatValue(left.value / right.value)
        
        elif operator == "%":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                if right.value == 0:
                    raise AIGoError("Modulo by zero")
                return IntValue(left.value % right.value)
        
        elif operator == "==":
            return BoolValue(self.values_equal(left, right))
        
        elif operator == "!=":
            return BoolValue(not self.values_equal(left, right))
        
        elif operator == "<":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return BoolValue(left.value < right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return BoolValue(left.value < right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return BoolValue(left.value < right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return BoolValue(left.value < right.value)
        
        elif operator == "<=":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return BoolValue(left.value <= right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return BoolValue(left.value <= right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return BoolValue(left.value <= right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return BoolValue(left.value <= right.value)
        
        elif operator == ">":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return BoolValue(left.value > right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return BoolValue(left.value > right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return BoolValue(left.value > right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return BoolValue(left.value > right.value)
        
        elif operator == ">=":
            if isinstance(left, IntValue) and isinstance(right, IntValue):
                return BoolValue(left.value >= right.value)
            elif isinstance(left, FloatValue) and isinstance(right, FloatValue):
                return BoolValue(left.value >= right.value)
            elif isinstance(left, IntValue) and isinstance(right, FloatValue):
                return BoolValue(left.value >= right.value)
            elif isinstance(left, FloatValue) and isinstance(right, IntValue):
                return BoolValue(left.value >= right.value)
        
        elif operator == "&&":
            if isinstance(left, BoolValue) and isinstance(right, BoolValue):
                return BoolValue(left.value and right.value)
        
        elif operator == "||":
            if isinstance(left, BoolValue) and isinstance(right, BoolValue):
                return BoolValue(left.value or right.value)
        
        raise AIGoError(f"Unsupported binary operation: {left} {operator} {right}")
    
    def evaluate_unary_operation(self, operator: str, operand: AIGoValue) -> AIGoValue:
        """Evaluate unary operations"""
        if operator == "-":
            if isinstance(operand, IntValue):
                return IntValue(-operand.value)
            elif isinstance(operand, FloatValue):
                return FloatValue(-operand.value)
        
        elif operator == "!":
            if isinstance(operand, BoolValue):
                return BoolValue(not operand.value)
        
        raise AIGoError(f"Unsupported unary operation: {operator} {operand}")
    
    def values_equal(self, left: AIGoValue, right: AIGoValue) -> bool:
        """Check if two values are equal"""
        if type(left) != type(right):
            return False
        
        if isinstance(left, IntValue):
            return left.value == right.value
        elif isinstance(left, FloatValue):
            return left.value == right.value
        elif isinstance(left, StringValue):
            return left.value == right.value
        elif isinstance(left, BoolValue):
            return left.value == right.value
        elif isinstance(left, VoidValue):
            return True
        elif isinstance(left, ArrayValue):
            if len(left.elements) != len(right.elements):
                return False
            return all(self.values_equal(a, b) for a, b in zip(left.elements, right.elements))
        
        return False
    
    def call_function(self, function: Any, args: List[AIGoValue]) -> AIGoValue:
        """Call a function"""
        self.execution_stats['function_calls'] += 1
        
        if callable(function):
            # Built-in function
            return function(*args)
        elif isinstance(function, Function):
            # User-defined function
            if len(args) != len(function.parameters):
                raise AIGoError(f"Function {function.name} expects {len(function.parameters)} arguments, got {len(args)}")
            
            # Create new environment for function execution
            func_env = Environment(function.closure)
            
            # Bind parameters
            for param, arg in zip(function.parameters, args):
                func_env.define(param.name, arg)
            
            # Execute function body
            old_env = self.current_env
            self.current_env = func_env
            
            try:
                for stmt in function.body:
                    self.execute_statement(stmt)
                # If no return statement, return void
                return VoidValue()
            except ReturnException as ret:
                return ret.value
            finally:
                self.current_env = old_env
        
        else:
            raise AIGoError(f"Cannot call non-function value: {function}")
    
    def execute_statement(self, stmt: Statement):
        """Execute statements"""
        if isinstance(stmt, VariableDeclaration):
            value = VoidValue()
            if stmt.value:
                value = self.evaluate_expression(stmt.value)
            self.current_env.define(stmt.name, value)
        
        elif isinstance(stmt, Assignment):
            value = self.evaluate_expression(stmt.value)
            if isinstance(stmt.target, Identifier):
                self.current_env.set(stmt.target.name, value)
            else:
                raise AIGoError("Complex assignment targets not supported yet")
        
        elif isinstance(stmt, ExpressionStatement):
            self.evaluate_expression(stmt.expression)
        
        elif isinstance(stmt, ReturnStatement):
            value = VoidValue()
            if stmt.value:
                value = self.evaluate_expression(stmt.value)
            raise ReturnException(value)
        
        elif isinstance(stmt, IfStatement):
            condition = self.evaluate_expression(stmt.condition)
            if isinstance(condition, BoolValue) and condition.value:
                for s in stmt.then_block:
                    self.execute_statement(s)
            elif stmt.else_block:
                for s in stmt.else_block:
                    self.execute_statement(s)
        
        elif isinstance(stmt, WhileStatement):
            try:
                while True:
                    condition = self.evaluate_expression(stmt.condition)
                    if not (isinstance(condition, BoolValue) and condition.value):
                        break
                    try:
                        for s in stmt.body:
                            self.execute_statement(s)
                    except ContinueException:
                        continue
                    except BreakException:
                        break
            except BreakException:
                pass
        
        elif isinstance(stmt, FunctionDeclaration):
            func = Function(stmt.name, stmt.parameters, stmt.body, self.current_env)
            self.current_env.define(stmt.name, func)
        
        elif isinstance(stmt, Block):
            for s in stmt.statements:
                self.execute_statement(s)
        
        else:
            raise AIGoError(f"Unknown statement type: {type(stmt)}")
    
    def interpret_program(self, program: Program):
        """Interpret a complete program"""
        self.execution_stats['start_time'] = time.time()
        
        # Handle imports (simplified)
        for imp in program.imports:
            if imp.module_path == "std.io":
                self.current_env.define("io", StringValue("io"))
        
        # Execute declarations
        for decl in program.declarations:
            self.execute_statement(decl)
        
        # Call main function if it exists
        try:
            main_func = self.current_env.get("main")
            if isinstance(main_func, Function):
                result = self.call_function(main_func, [])
                return result
        except AIGoError as e:
            if "Undefined variable: main" not in str(e):
                raise
        
        return VoidValue()
    
    def get_execution_stats(self):
        """Get execution statistics"""
        if self.execution_stats['start_time']:
            execution_time = time.time() - self.execution_stats['start_time']
        else:
            execution_time = 0
        
        return {
            'operations': self.execution_stats['operations'],
            'function_calls': self.execution_stats['function_calls'],
            'execution_time': execution_time,
            'ops_per_second': self.execution_stats['operations'] / max(execution_time, 0.001)
        }

def run_aigo_code(source_code: str, show_stats: bool = False):
    """Run AIGo source code"""
    try:
        # Tokenize
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        
        # Parse
        parser = Parser(tokens)
        ast = parser.parse_program()
        
        # Interpret
        interpreter = EnhancedInterpreter()
        result = interpreter.interpret_program(ast)
        
        if show_stats:
            stats = interpreter.get_execution_stats()
            print(f"\n--- Execution Statistics ---")
            print(f"Operations: {stats['operations']}")
            print(f"Function calls: {stats['function_calls']}")
            print(f"Execution time: {stats['execution_time']:.6f}s")
            print(f"Operations/second: {stats['ops_per_second']:.0f}")
        
        return result
        
    except (ParseError, AIGoError) as e:
        print(f"Error: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    # Test the enhanced interpreter
    test_code = '''
    module main
    
    import std.io
    
    fn main() -> Result<void, Error> {
        let arr = array_new()
        array_push(arr, 5)
        array_push(arr, 3)
        array_push(arr, 8)
        array_push(arr, 1)
        
        io.println("Original array:", arr)
        io.println("Array length:", array_len(arr))
        
        let first = array_get(arr, 0)
        io.println("First element:", first)
        
        return Ok(void)
    }
    '''
    
    print("Running Enhanced AIGo code:")
    print(test_code)
    print("\nOutput:")
    run_aigo_code(test_code, show_stats=True)

