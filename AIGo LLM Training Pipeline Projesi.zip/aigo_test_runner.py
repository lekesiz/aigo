#!/usr/bin/env python3
"""
AIGo Algorithm Test Runner
Test runner for executing AIGo algorithm implementations
"""

from enhanced_aigo_interpreter import run_aigo_code
import time

def run_algorithm_test(filename, description):
    """Run an AIGo algorithm test"""
    print(f"🚀 Running {description}")
    print("=" * 60)
    
    try:
        with open(filename, 'r') as f:
            code = f.read()
        
        start_time = time.time()
        result = run_aigo_code(code, show_stats=True)
        end_time = time.time()
        
        print(f"\n✅ {description} completed successfully!")
        print(f"Total execution time: {end_time - start_time:.6f} seconds")
        print("\n" + "="*60 + "\n")
        
        return True
        
    except FileNotFoundError:
        print(f"❌ File not found: {filename}")
        return False
    except Exception as e:
        print(f"❌ Error running {description}: {e}")
        return False

def main():
    """Main test runner"""
    print("🎯 AIGo Algorithm Demonstration")
    print("Testing real-world algorithms implemented in AIGo")
    print("\n")
    
    tests = [
        ("aigo_sorting_algorithms.aigo", "Sorting Algorithms (Bubble, Quick, Merge Sort)"),
    ]
    
    passed = 0
    total = len(tests)
    
    for filename, description in tests:
        if run_algorithm_test(filename, description):
            passed += 1
    
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! AIGo is working perfectly!")
    else:
        print("⚠️  Some tests failed. Check the output above for details.")

if __name__ == "__main__":
    main()

